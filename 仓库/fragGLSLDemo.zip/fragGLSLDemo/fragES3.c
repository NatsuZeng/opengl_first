﻿#version 300 es
/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/
precision mediump float;
uniform sampler2D u_sampler0;
uniform vec4 u_param;
//
out vec4 FragColor;
void main()
{
    vec2 coord = gl_FragCoord.xy/u_param.xy;
    coord.y = 1.0 - coord.y;
    vec3 outColor = texture(u_sampler0,coord).rgb;
    FragColor = vec4(outColor,1.0);
}


//##config
{
texture2D:[
    "glsles3.jpg"
    ]
}
//##end