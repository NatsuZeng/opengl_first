/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/

"use strict"

const WEB_GL1 = 10001;
const WEB_GL2 = 10002;
let WEBGL_VER = WEB_GL1;
function isWebGL1(){return WEBGL_VER==WEB_GL1;}
function isWebGL2(){return WEBGL_VER==WEB_GL2;}
function setVersionToGL1(){WEBGL_VER = WEB_GL1;}
function setVersionToGL2(){WEBGL_VER = WEB_GL2;}

// math base value
const MATH_PI = 3.14159265;
const MATH_2PI = MATH_PI * 2;
const MATH_3PER2PI = MATH_PI * 1.5;
const MATH_1PER2PI = MATH_PI * 0.5;
const MATH_1_OVER_PI = 1.0 / MATH_PI;
const MATH_1_OVER_360 = 1.0 / 360.0;
const MATH_1_OVER_180 = 1.0 / 180.0;
const MATH_180_OVER_PI = 180.0 / MATH_PI;
const MATH_PI_OVER_180 = MATH_PI / 180.0;
// glsl name examples:
const SHDER_ATTRI_VTX_POS = "a_vs";
const SHDER_ATTRI_VTX_UV = "a_uvs";
const SHDER_ATTRI_VTX_NV = "a_nvs";
const SHDER_ATTRI_VTX_UVPARAM = "a_puvs";
const SHDER_ATTRI_VTX_UVPARAM2 = "a_p2uvs";
const SHDER_ATTRI_VTX_PARAM = "a_pvs";
const SHDER_ATTRI_VTX_PARAM2 = "a_p2vs";
const SHDER_ATTRI_VTX_COLOR = "a_cvs";
const SHDER_UNIFORM_UV_OFFSET = "u_uvOffset";
const SHDER_UNIFORM_STAGE_SIZE = "u_stageSize";
const SHDER_UNIFORM_OBJECT_MAT = "u_objMat";
const SHDER_UNIFORM_VIEW_MAT = "u_viewMat";
const SHDER_UNIFORM_PROJ_MAT = "u_projMat";
// texture uniforms
const SHDER_UNIFORM_TEX_SAMPLE_0 = "u_sampler0";
const SHDER_UNIFORM_TEX_SAMPLE_1 = "u_sampler1";
const SHDER_UNIFORM_TEX_SAMPLE_2 = "u_sampler2";
const SHDER_UNIFORM_TEX_SAMPLE_3 = "u_sampler3";
const SHDER_UNIFORM_TEX_SAMPLE_4 = "u_sampler4";
const SHDER_UNIFORM_TEX_SAMPLE_5 = "u_sampler5";
const SHDER_UNIFORM_TEX_SAMPLE_6 = "u_sampler6";
const SHDER_UNIFORM_TEX_SAMPLE_7 = "u_sampler7";
const SHDER_UNIFORM_TEX_SAMPLE_LIST = [
    SHDER_UNIFORM_TEX_SAMPLE_0,
    SHDER_UNIFORM_TEX_SAMPLE_1,
    SHDER_UNIFORM_TEX_SAMPLE_2,
    SHDER_UNIFORM_TEX_SAMPLE_3,
    SHDER_UNIFORM_TEX_SAMPLE_4,
    SHDER_UNIFORM_TEX_SAMPLE_5,
    SHDER_UNIFORM_TEX_SAMPLE_6,
    SHDER_UNIFORM_TEX_SAMPLE_7
];
//
const MATH_MIN_POSITIVE = 0.00001;
const MATH_MAX_NEGATIVE = -0.00001;
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
const MOUSE_UP = 101;
const MOUSE_DOWN = 102;
const MOUSE_MOVE = 103;

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

let DISP_OBJ_ID = 1;

//CullFaceMode cullFaceMode;
// blend mode
let RenderBlendMode = {
    NORMAL:1,
    OPAQUE:1,
    TRANSPARENT:2,
    ALPHA_ADD:3,
    ADD:4,
    ADD2:5,
    INVERSE_ALPHA:6,
    BLAZE:7,
    DISABLE:0
};
let CullFaceMode = {
    BACK:1,
    FRONT:2,
    FRONT_AND_BACK:3,
    NONE:4,
    DISABLE:0
};
let DepthTestType = {
    RENDER_NEVER:1
	//glDepthMask(false); glDepthFunc(GL_ALWAYS);
	, RENDER_SKY:2
	//glDepthMask(true); glDepthFunc(GL_LEQUAL);
	, RENDER_SKY2:3
	//glDepthMask(true); glDepthFunc(GL_LESS);
	, RENDER_OPAQUE:4
	//glDepthMask(false); glDepthFunc(GL_EQUAL);
	, RENDER_OPAQUE_OVERHEAD:5
	//glDepthMask(false); glDepthFunc(GL_LEQUAL);
	, RENDER_DECALS:6
	, RENDER_TRANSPARENT_SORT:7
	, RENDER_WIRE_FRAME:8
	//glDepthMask(false); glDepthFunc(GL_ALWAYS);
	, RENDER_NEXT_LAYER:9
	, RENDER_WIRE_FRAME_NEXT:10
    , DISABLE:0
};
let MATH_sysCosArr = [];
let MATH_sysSinArr = [];
let pv = 0;
for(var i = 0; i <= 628; ++i)
{
    pv = 0.01 * i;
    MATH_sysCosArr[i] = Math.cos(pv);
    MATH_sysSinArr[i] = Math.sin(pv);
}
function getMathBaseCos(rad)
{
    rad = Math.round(rad * 100);
    
    if(rad < 0)
    {
        rad %= 628;
        rad += 628;
    }else if(rad > 628)
    {
        rad %= 628;
    }
    //trace(rad);
    return MATH_sysCosArr[rad];
}
function getMathBaseSin(rad)
{
    rad = Math.round(rad * 100);
    if(rad < 0)
    {
        rad %= 628;
        rad += 628;
    }else if(rad > 628)
    {
        rad %= 628;
    }
    return MATH_sysSinArr[rad];
}

function degreeToRadian(degree)
{
    return MATH_PI_OVER_180 * degree;
}
function matToString(mat)
{
	var str = mat[0]+","+mat[1]+","+mat[2]+","+mat[3]+"\n";
	str += mat[4]+","+mat[5]+","+mat[6]+","+mat[7]+"\n";
	str += mat[8]+","+mat[9]+","+mat[10]+","+mat[11]+"\n";
	str += mat[12]+","+mat[13]+","+mat[14]+","+mat[15]+"\n";
	return str;
}
function trace()
{
    var i = 0, n = arguments.length;
    var str = "";
    for(; i < n; i++)
    {
        str += arguments[i];        
    }
    console.log(str);
}
function print()
{
    var i = 0, n = arguments.length;
    var str = "";
    for(; i < n; i++)
    {
        str += arguments[i];        
    }
    console.log(str);
}
//
function traceMat(mat)
{
	var str = mat[0]+","+mat[1]+","+mat[2]+","+mat[3]+"\n";
	str += mat[4]+","+mat[5]+","+mat[6]+","+mat[7]+"\n";
	str += mat[8]+","+mat[9]+","+mat[10]+","+mat[11]+"\n";
	str += mat[12]+","+mat[13]+","+mat[14]+","+mat[15]+"\n";
	trace(str);
}
function log()
{
    let i = 0, n = arguments.length;
    let str = "";
    for(; i < n; i++)
    {
        str += arguments[i];        
    }
    console.log(str);
}
function __TextureFormat()
{
    this.RGB = 110;
    this.RGBA = 121;
    this.ALPHA = 132;
    this.RGB16F = 331;
    this.RGBA16F = 332;

    this.toGL = function(gl,format)
    {
        switch(format)
        {
            case this.RGB:
                return gl.RGB;
                break;
            case this.ALPHA:
                return gl.ALPHA;
                break;
            case this.RGB16F:
                return gl.RGB16F;
                break;
            case this.RGBA16F:
                return gl.RGBA16F;
                break;

        }
        return gl.RGBA;
    }
    //RenderBlendMode.ONE = gl.ONE;
};
var TextureFormat = new __TextureFormat();
function __TextureDataType()
{
    this.UNSIGNED_BYTE = 1110;
    this.BYTE = 1111;
    this.FLOAT = 1211;
    this.HALF_FLOAT = 1212;
    this.toGL = function(gl,type)
    {
        switch(type)
        {
            case this.UNSIGNED_BYTE:
                return gl.UNSIGNED_BYTE;
                break;
            case this.BYTE:
                return gl.BYTE;
                break;
            case this.FLOAT:
                return gl.FLOAT;
                break;                
            case this.HALF_FLOAT:
                return gl.HALF_FLOAT;
                break;

        }
        return gl.RGBA;
    }
    //RenderBlendMode.ONE = gl.ONE;
};
var TextureDataType = new __TextureDataType();

function ___TextureConst()
{
    this.initEnbled = true;
    //
    this.TEXTURE_2D = 20;
    this.TEXTURE_CUBE = 25;
    this.TEXTURE_3D = 30;
    //
    this.WRAP_REPEAT = 3001;
    this.WRAP_CLAMP_TO_EDGE = 3002;
    this.WRAP_MIRRORED_REPEAT = 3003;
    let m_gl = null;
    this.initialize = function(gl)
    {
        if(this.initEnbled)
        {
            m_gl = gl;
            //this.initEnbled = false;
            //this.WRAP_REPEAT = gl.REPEAT;
            //this.WRAP_CLAMP_TO_EDGE = gl.CLAMP_TO_EDGE;
            //this.WRAP_MIRRORED_REPEAT = gl.MIRRORED_REPEAT;
        }
    }
    this.getConst = function(gl,param)
    {

        switch(param)
        {
            case this.WRAP_REPEAT:
            return gl.REPEAT;
            break;

            case this.WRAP_CLAMP_TO_EDGE:
            return gl.CLAMP_TO_EDGE;
            break;

            case this.WRAP_MIRRORED_REPEAT:
            return gl.MIRRORED_REPEAT;
            break;

        }
        return null;
    }
}
//
var TextureConst = new ___TextureConst();

function ___LightType()
{
    this.DISABLE = 0;
	this.NO_LIGHT = 11;
	this.AMBIENT_LIGHT = 12;
	this.DIFFUSE_DIRECTION_LIGHT = 13;
    this.DIFFUSE_POINT_LIGHT = 14;    
	this.DIFFUSE_SPOT_LIGHT = 15;
	this.SPECULAR_DIRECTION_LIGHT = 17;
	this.SPECULAR_POINT_LIGHT = 18;
	this.GROUP_LIGHT = 37;
};

let LightType = new ___LightType();
//// depth test type
//RenderDepthTestType depthTestType;
//// 生成或接受阴影
//DispShadowStatus shadowStatus;

function uvClam(minU, maxU, minV, maxV,m_vtx_buf,uvTotal)
{
	var du = maxU - minU;
	var dv = maxV - minV;
	var i = 0;
	var j = 0;
	
	for (; i < uvTotal; ++i)
	{
		j = i * 2;
		m_vtx_buf[j] = m_vtx_buf[j] * du + minU;
		++j;
		m_vtx_buf[j] = m_vtx_buf[j] * dv + minV;
	}
}
function isPowerOf2(value) 
{
    return (value & (value - 1)) == 0;
}

function getNearestCeilPow2(int_n)
{
  let x = 1;
  while(x < int_n) {
    x <<= 1;
  }
  return x;
}

function calcNearestCeilPow2(int_n)
{
  return Math.pow(2, Math.ceil( Math.log(int_n) / Math.LN2 ) );
}

// ccw is positive
function getMinRadian(a1, a0)
{
	//a0 /= MATH_2PI;
	//a0 = (a0 - Math.floor(a0)) * MATH_2PI;
	//if (a0 < 0) a0 += MATH_2PI;
	////
	//a1 /= MATH_2PI;
	//a1 = (a1 - Math.floor(a1)) * MATH_2PI
    //if (a1 < 0) a1 += MATH_2PI;
    a0 %= MATH_2PI;
    a1 %= MATH_2PI;
	if (a0 < a1)
	{
		a0 = MATH_2PI - a1 + a0;
		if (a0 > MATH_PI) return a0 - MATH_2PI;
		return a0;
	}
	else if (a0 > a1)
	{
		a1 = MATH_2PI - a0 + a1;
		if (a1 > MATH_PI) return MATH_2PI - a1;
		return -a1;
	}
	return 0.0;
}
//////////////////////////////////////////////
//////////////////////////////////////////////
function getMinAngle(a0, a1)
{
    var angle = 0;
    if(a1 >= 270 && a0 < 90){
        angle = (a1 - (a0 + 360)) % 180;
    }else if (a1 <= 90 && a0 >= 270) {
        angle = (a1 + 360 - a0) % 180;
    }else {
        angle = (a1 - a0);
        if (Math.abs(angle) > 180) {
            angle -= 360;    
        }
    }
    return angle;
}
function getAngleByXY(dx,dy)
{
    if(Math.abs(dx) < 0.00001)
    {
        if(dy >= 0) return 270;
        else return 90;
    }
    var angle = Math.atan(dy/dx) * 180/Math.PI;

    //return angle;

    if(dy>0 && dx>0)
    {         
        return angle
    }else if(dy<0 && dx>=0)
    {
        return 360+angle;
    }else{
        return 180+angle;    
    }
    return angle;
}

function getRadianByXY(dx,dy)
{
    if(Math.abs(dx) < MATH_MIN_POSITIVE)
    {
        if(dy >= 0) return MATH_1PER2PI;
        else return MATH_3PER2PI;
    }
    var rad = Math.atan(dy/dx);
    if(dx >= 0)
    {
        return rad;
    }
    else
    {
        return MATH_PI+rad;
    }
}
function getRadianByCos(cosv,dx,dy)
{
    var rad = Math.acos(cosv);//Math.atan(dy/dx);
    if(dx >= 0)
    {
        return rad;
    }
    else
    {
        return MATH_PI+rad;
    }
}
// cw is positive
function __OK_getMinAng(a0, a1)
{
	a0 /= 360.0;
	a0 = (a0 - floor(a0)) * 360.0;
	if (a0 < 0) a0 += 360.0;
	//
	a1 /= 360.0;
	a1 = (a1 - floor(a1)) * 360.0;
	if (a1 < 0) a1 += 360
	if (a0 < a1)
	{
		a0 = 360.0 - a1 + a0;
		if (a0 > 180.0) return a0 - 360.0;
		return a0;
	}
	else if (a0 > a1)
	{
		a1 = 360.0 - a0 + a1;
		if (a1 > 180.0) return 360.0 - a1;
		return -a1;
	}
	return 0.0;
}
let SYS_NO_ERROR = true;
let SYS_ERROR = false;
function throwSysError(infostr)
{
    SYS_NO_ERROR = false;
    SYS_ERROR = true;
    trace("SYS_ERROR: "+infostr);
    alert(infostr);
}

/////////////////////////////////////////

function ShaderUniformProbe()
{
    this.rst = -1;
    this.uniformSlotIndex = -1;
    this.uniformSlotSize = 0;
    // array -> [SHADER_MAT4, SHADER_VEC3]
    this.uniformTypes = null;
    // array -> [1, 3], the "3" is uniform Array,length is 3
    this.dataSizeList = null;
}

const SHADER_VEC2 = "vec2";
const SHADER_VEC3 = "vec3";
const SHADER_VEC4 = "vec4";
const SHADER_VEC2FV = "vec2_fv";
const SHADER_VEC3FV = "vec3_fv";
const SHADER_VEC4FV = "vec4_fv";
const SHADER_MAT2 = "mat2";
const SHADER_MAT3 = "mat3";
const SHADER_MAT4 = "mat4";
const SHADER_FLOAT = "float";

const SHADER_PRECISION_LOWP = 101;
const SHADER_PRECISION_MEDIUMP = 111;
const SHADER_PRECISION_HIGHP = 121;
// very very important !!!!!!!!!!!!!
function ___RenderDataSlot()
{
    let total = 256;
    //
    this.index = 0;
    this.dataList = [];
    this.flagList = new Uint16Array(total);
    //
    for(let i = 0; i < total; ++i)
    {
        this.dataList.push(null);
        this.flagList[i] = 0;
    }
}
const GlobalUniformSlot = new ___RenderDataSlot();

/////////////////////////////////////////////////////////////////////////////
function ___Stage()
{
    this.stageWidth = 800;
    this.stageHeight = 600;
    this.stageHalfWidth = 400;
    this.stageHalfHeight = 300;
    this.mouseX = 0;
    this.mouseY = 0;
    //
    this.uProbe = new ShaderUniformProbe();
    //
    let m_stageParamArr = [400,300,0,0];
    //
    //
    this.update = function()
    {
        //trace("-----------------update stage size-----------------");
        //
        m_stageParamArr[0] = this.stageWidth * 0.5;
        m_stageParamArr[1] = this.stageHeight * 0.5;

        if(this.uProbe.rst < 0)
        {
            this.uProbe.rst = 1;
            //
            this.uProbe.uniformSlotIndex = GlobalUniformSlot.index;
            this.uProbe.uniformSlotSize = 1;
            GlobalUniformSlot.dataList[this.uProbe.uniformSlotIndex] = m_stageParamArr;
            //
            GlobalUniformSlot.index += this.uProbe.uniformSlotSize;
            this.uProbe.uniformTypes = [SHADER_VEC4];
            this.uProbe.dataSizeList = [1];
        }
        if(this.uProbe.rst > 0xffffff) this.uProbe.rst = Math.round(Math.random() * 1000) + 100;
        this.uProbe.rst++;
        GlobalUniformSlot.flagList[this.uProbe.uniformSlotIndex] = this.uProbe.rst;
        //
    }
    this.mouseDown = function()
    {
        let len = m_down_listener.length;
        
        //trace("m_down_listener.length: ",m_down_listener.length);
        for(var i = 0; i < len; ++i)
        {
            //trace(m_down_listener[i]);
            m_down_listener[i].call();
        }
    };    
    this.mouseUp = function()
    {
        let len = m_up_listener.length;
        for(let i = 0; i < len; ++i)
        {
            m_up_listener[i].call();
        }
    };
    this.mouseMove = function()
    {
        let len = m_move_listener.length;
        for(let i = 0; i < len; ++i)
        {
            m_move_listener[i].call();
        }
    };
    //
    let m_down_listener = [];
    let m_up_listener = [];
    let m_move_listener = [];
    //var m_funcDict = {};
    this.addEventListener = function(type,func)
    {
        if(func != undefined && type != undefined)
        {
            let i = 0;
            switch(type)
            {
                case MOUSE_DOWN:
                    for(i = m_down_listener.length - 1; i >= 0; --i)
                    {
                        if(func === m_down_listener[i])
                        {
                            break;
                        }
                    }
                    if(i < 0)
                    {
                        m_down_listener.push(func);
                    }
                break;
                case MOUSE_UP:
                    for(i = m_up_listener.length - 1; i >= 0; --i)
                    {
                        if(func === m_up_listener[i])
                        {
                            break;
                        }
                    }
                    if(i < 0)
                    {
                        m_up_listener.push(func);
                    }
                break;
                case MOUSE_MOVE:
                    for(i = m_move_listener.length - 1; i >= 0; --i)
                    {
                        if(func === m_move_listener[i])
                        {
                            break;
                        }
                    }
                    if(i < 0)
                    {
                        m_move_listener.push(func);
                    }
                break;
                default:
                break;
            }
        }
    };
    this.removeEventListener = function(type,func)
    {
        if(func != undefined && type != undefined)
        {
            let i = 0;
            switch(type)
            {
                case MOUSE_DOWN:
                    for(i = m_down_listener.length - 1; i >= 0; --i)
                    {
                        if(func === m_down_listener[i])
                        {
                            m_down_listener.splice(i,1);
                            break;
                        }
                    }
                break;
                case MOUSE_UP:
                    for(i = m_up_listener.length - 1; i >= 0; --i)
                    {
                        if(func === m_up_listener[i])
                        {
                            m_up_listener.splice(i,1);
                            break;
                        }
                    }
                break;
                case MOUSE_MOVE:
                    for(i = m_move_listener.length - 1; i >= 0; --i)
                    {
                        if(func === m_move_listener[i])
                        {
                            m_move_listener.splice(i,1);
                            break;
                        }
                    }
                break;
                default:
                break;
            }
        }
    };

};
let Stage = new ___Stage();
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
let ___Mouse = {
    x:800,
    y:600
};
//function isPCTest(){  
//    var userAgentInfo = navigator.userAgent;
//    var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");  
//    var flag = true;  
//    for (var v = 0; v < Agents.length; v++) {  
//        if (userAgentInfo.indexOf(Agents[v]) > 0) { flag = false; break; }  
//    }  
//    return flag;  
//}
function isMobileTest() {
    alert(navigator.userAgent);
    let ua = navigator.userAgent.toLowerCase();
    let boo = ua.match(/MicroMessenger/i) == "micromessenger";
    if(boo) return true;
    if(window.orientation !== undefined)
    {
        return true;
    }
    return false;
    //try{        
    //    var check = false;
    //    (function(a){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))) check = true;})(navigator.userAgent||navigator.vendor||window.opera);
    //    return check;
    //
    //}catch(err)
    //{
    //    return true;
    //}
    //return true;
};/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/


const VOX_minFloatValue = 0.000001;
const VOX_kPi = 3.14159265;
const VOX_k2Pi = VOX_kPi * 2.0;
const VOX_kPiOver2 = VOX_kPi / 2.0;
const VOX_k1OverPi = 1.0 / VOX_kPi;
const VOX_k1Over2Pi = 1.0 / VOX_k2Pi;
const VOX_k180OverPi = 180.0 / VOX_kPi;
const VOX_kPiOver180 = VOX_kPi / 180.0;

function safeACos(x)
{
	// 检查边界条件
	if (x <= -1.0)
	{
		return MATH_PI;
	}
	if (x >= 1.0)
	{
		return 0.0;
    }
	return Math.acos(x);
}
function Orientation3D()
{

}
Orientation3D.AXIS_ANGLE = 110;
Orientation3D.QUATERNION = 220;
Orientation3D.EULER_ANGLES = 330;

// 将弧度转换为角度值
function radianToDegree(rad_theta)
{
	return rad_theta * VOX_k180OverPi;
};
// 将角度值转换为弧度值
function degreeToRadian(degree_theta)
{
	return degree_theta * VOX_kPiOver180;
};
function Vector3D(px,py,pz,pw)
{

    if(px != undefined){this.x = px;}
    else{this.x = 0;}
    if(py != undefined){this.y = py;}
    else{this.y = 0;}
    if(pz != undefined){this.z = pz;}
    else{this.z = 0;}
    if(pw != undefined){this.w = pw;}
    else{this.w = 1.0;}

    this.setTo = function(px,py,pz)
    {
        this.x = px;
        this.y = py;
        this.z = pz;
    };
    this.copyFrom = function(v3)
    {
        this.x = v3.x;
        this.y = v3.y;
        this.z = v3.z;
    };
    this.getArray = function()
    {
        return [this.x,this.y,this.z];
    };
    this.dotProduct = function(a)
    {
        return this.x * a.x + this.y * a.y + this.z * a.z;
    };
    this.cross = function(a)
    {
        let px = this.y * a.z - this.z * a.y;
        let py = this.z * a.x - this.x * a.z;
        let pz = this.x * a.y - this.y * a.x;
        this.x = px;
        this.y = py;
        this.z = pz;
	};
	this.mult = function(a)
    {
        this.x *= a.x;
        this.y *= a.y;
        this.z *= a.z;
    };
    this.normalize = function()
    {
        let d = Math.sqrt(this.x*this.x + this.y*this.y + this.z*this.z);
        if (d > MATH_MIN_POSITIVE)
        {
            this.x /= d;
            this.y /= d;
            this.z /= d;
        }
    };
    this.scaleBy = function(s)
    {
        this.x *= s;
        this.y *= s;
        this.z *= s;
    }
    this.incrementBy = function(a)
    {
        this.x += a.x;
        this.y += a.y;
        this.z += a.z;
    }
    this.decrementBy = function(a)
    {
        this.x -= a.x;
        this.y -= a.y;
        this.z -= a.z;
    }
    this.negate = function()
    {
        this.x = -this.x;
        this.y = -this.y;
        this.z = -this.z;
    };

    this.equals = function(toCompare, allFour)
    {
        //if(allFour == undefined)
        return this.x == toCompare.x && this.y == toCompare.y && this.z == toCompare.z && (allFour ? this.w == toCompare.w : true);
    }
    this.project = function()
    {
        let t = 1.0 / w;
        this.x *= t;
        this.y *= t;
        this.z *= t;
    };
    this.length = function()
	{
		return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
    };
	this.lengthSquared = function()
	{
		return this.x * this.x + this.y * this.y + this.z * this.z;
	}
	// this += a
	this.addBy = function(a)
	{
		this.x += a.x;
		this.y += a.y;
		this.z += a.z;
	};
	// this -= a
	this.subtractBy = function(a)
	{
		this.x -= a.x;
		this.y -= a.y;
		this.z -= a.z;
    };
    //this.subtract = function(a, b, result)
	//{
	//	result.x = a.x - b.x;
	//	result.y = a.y - b.y;
	//	result.z = a.z - b.z;
    //}
    this.subtract = function(a)
    {
		return new Vector3D(this.x - a.x, this.y - a.y, this.z - a.z);
    }
    this.add = function(a)
	{
		return new Vector3D(this.x + a.x, this.y + a.y, this.z + a.z);
	}
    this.crossProduct = function(a)
	{
		return new Vector3D(
			this.y * a.z - this.z * a.y
			, this.z * a.x - this.x * a.z
			, this.x * a.y - this.y * a.x
			);
	}
    this.toString = function()
    {
        return "[Vector3D(x="+this.x+", y="+this.y+",z="+this.z+")]";
    };
    //static const Vector3D X_AXIS;
	//static const Vector3D Y_AXIS;
	//static const Vector3D Z_AXIS;
};
const __stv0 = new Vector3D();
Vector3D.X_AXIS = new Vector3D(1,0,0);
Vector3D.y_AXIS = new Vector3D(0,1,0);
Vector3D.z_AXIS = new Vector3D(0,0,1);
Vector3D.cross = function(a, b, result)
{
    result.x = a.y * b.z - a.z * b.y;
    result.y = a.z * b.x - a.x * b.z;
    result.z = a.x * b.y - a.y * b.x;
}
Vector3D.distanceSquared = function(a, b)
{
    __stv0.x = a.x - b.x;
    __stv0.y = a.y - b.y;
	__stv0.z = a.z - b.z;
	return __stv0.lengthSquared();
}
// calc Vector3D v0 and v1
Vector3D.angleBetween = function(v0,v1)
{
	// c^2 = a^2 + b^2 - 2*a*b * cos(x)
	// cos(x) = (a^2 + b^2 - c^2) / 2*a*b
	let pa = v0.lengthSquared();
	let pb = v1.lengthSquared();
	__stv0.x = v0.x - v1.x;
	__stv0.y = v0.y - v1.y;
	__stv0.z = v0.z - v1.z;
	let pc = __stv0.lengthSquared();
	//if(pc < MATH_MIN_POSITIVE) return 0.0;
	return Math.acos((pa + pb - pc)/ (2 * Math.sqrt(pa) * Math.sqrt(pb))) * MATH_180_OVER_PI;
}
Vector3D.radianBetween = function(v0,v1)
{
	// c^2 = a^2 + b^2 - 2*a*b * cos(x)
	// cos(x) = (a^2 + b^2 - c^2) / 2*a*b
	let pa = v0.lengthSquared();
	let pb = v1.lengthSquared();
	__stv0.x = v0.x - v1.x;
	__stv0.y = v0.y - v1.y;
	__stv0.z = v0.z - v1.z;
	let pc = __stv0.lengthSquared();
	//if(pc < MATH_MIN_POSITIVE) return 0.0;
	return Math.acos((pa + pb - pc)/ (2 * Math.sqrt(pa) * Math.sqrt(pb)));
}

const ___matrixInitRawData = new Float32Array([
    1.0,0.0,0.0,0.0,
    0.0,1.0,0.0,0.0,
    0.0,0.0,1.0,0.0,
    0.0,0.0,0.0,1.0
]
);

class Matrix3D extends Float32Array {
    constructor() {
        super(___matrixInitRawData);
        this.pos = {x:0,y:0,z:0};
        this.name = "Matrix3D";
    }
    position(px, py, pz)
	{
		this.pos.setTo(px,py,pz);
	}
    //
    identity()
    {
        this.set(___matrixInitRawData,0);
    }
    determinant()
	{
        return (this[0] * this[5] - this[4] * this[1]) * (this[10] * this[15] - this[14] * this[11]) - (this[0] * this[9] - this[8] * this[1]) * (this[6] * this[15] - this[14] * this[7]) + (this[0] * this[13] - this[12] * this[1]) * (this[6] * this[11] - this[10] * this[7]) + (this[4] * this[9] - this[8] * this[5]) * (this[2] * this[15] - this[14] * this[3]) - (this[4] * this[13] - this[12] * this[5]) * (this[2] * this[11] - this[10] * this[3]) + (this[8] * this[13] - this[12] * this[9]) * (this[2] * this[7] - this[6] * this[3]);
    }
    append(lhs)
	{
		let m111 = this[0];
		let m121 = this[4];
		let m131 = this[8];
		let m141 = this[12];
		let m112 = this[1];
		let m122 = this[5];
		let m132 = this[9];
		let m142 = this[13];
		let m113 = this[2];
		let m123 = this[6];
		let m133 = this[10];
		let m143 = this[14];
		let m114 = this[3];
		let m124 = this[7];
		let m134 = this[11];
		let m144 = this[15];
		let m211 = lhs[0];
		let m221 = lhs[4];
		let m231 = lhs[8];
		let m241 = lhs[12];
		let m212 = lhs[1];
		let m222 = lhs[5];
		let m232 = lhs[9];
		let m242 = lhs[13];
		let m213 = lhs[2];
		let m223 = lhs[6];
		let m233 = lhs[10];
		let m243 = lhs[14];
		let m214 = lhs[3];
		let m224 = lhs[7];
		let m234 = lhs[11];
		let m244 = lhs[15];
		this[0] = m111 * m211 + m112 * m221 + m113 * m231 + m114 * m241;
		this[1] = m111 * m212 + m112 * m222 + m113 * m232 + m114 * m242;
		this[2] = m111 * m213 + m112 * m223 + m113 * m233 + m114 * m243;
		this[3] = m111 * m214 + m112 * m224 + m113 * m234 + m114 * m244;
		this[4] = m121 * m211 + m122 * m221 + m123 * m231 + m124 * m241;
		this[5] = m121 * m212 + m122 * m222 + m123 * m232 + m124 * m242;
		this[6] = m121 * m213 + m122 * m223 + m123 * m233 + m124 * m243;
		this[7] = m121 * m214 + m122 * m224 + m123 * m234 + m124 * m244;
		this[8] = m131 * m211 + m132 * m221 + m133 * m231 + m134 * m241;
		this[9] = m131 * m212 + m132 * m222 + m133 * m232 + m134 * m242;
		this[10] = m131 * m213 + m132 * m223 + m133 * m233 + m134 * m243;
		this[11] = m131 * m214 + m132 * m224 + m133 * m234 + m134 * m244;
		this[12] = m141 * m211 + m142 * m221 + m143 * m231 + m144 * m241;
		this[13] = m141 * m212 + m142 * m222 + m143 * m232 + m144 * m242;
		this[14] = m141 * m213 + m142 * m223 + m143 * m233 + m144 * m243;
		this[15] = m141 * m214 + m142 * m224 + m143 * m234 + m144 * m244;
    }
    append3x3(lhs)
	{
		let m111 = this[0];
		let m121 = this[4];
		let m131 = this[8];
		let m112 = this[1];
		let m122 = this[5];
		let m132 = this[9];
		let m113 = this[2];
		let m123 = this[6];
		let m133 = this[10];
		let m211 = lhs[0];
		let m221 = lhs[4];
		let m231 = lhs[8];
		let m212 = lhs[1];
		let m222 = lhs[5];
		let m232 = lhs[9];
		let m213 = lhs[2];
		let m223 = lhs[6];
		let m233 = lhs[10];
		
		this[0] = m111 * m211 + m112 * m221 + m113 * m231;
		this[1] = m111 * m212 + m112 * m222 + m113 * m232;
		this[2] = m111 * m213 + m112 * m223 + m113 * m233;		
		this[4] = m121 * m211 + m122 * m221 + m123 * m231;
		this[5] = m121 * m212 + m122 * m222 + m123 * m232;
		this[6] = m121 * m213 + m122 * m223 + m123 * m233;		
		this[8] = m131 * m211 + m132 * m221 + m133 * m231;
		this[9] = m131 * m212 + m132 * m222 + m133 * m232;
		this[10] = m131 * m213 + m132 * m223 + m133 * m233;				
    }
    appendRotationPivot(radian, axis, pivotPoint)
	{
        if(pivotPoint == undefined)
        {
            pivotPoint = new Vector3D(0,0,0,1.0);
        }
		___sysTempMat3D.identity();
		this.getAxisRotation(axis.x, axis.y, axis.z, radian,___sysTempMat3D);
		___sysTempMat3D.appendTranslationXYZ(pivotPoint.x, pivotPoint.y, pivotPoint.z);				
		this.append(___sysTempMat3D);
	}
	appendRotation(radian, axis)
	{
		___sysTempMat3D.identity();
		this.getAxisRotation(axis.x, axis.y, axis.z, radian, ___sysTempMat3D);
		this.append(___sysTempMat3D);
    }
    appendRotationX(radian)
	{
		this.rotationX(radian, ___sysTempMat3D);
		this.append3x3(___sysTempMat3D);
    }
	appendRotationY(radian)
	{
		this.rotationY(radian, ___sysTempMat3D);
		this.append3x3(___sysTempMat3D);
	}
	appendRotationZ(radian)
	{
		this.rotationZ(radian, ___sysTempMat3D);
		this.append3x3(___sysTempMat3D);
	}
    // 用欧拉角形式旋转(heading->pitch->bank) => (y->x->z)
	appendRotationEulerAngle(radianX, radianY, radianZ)
	{
		//s_tempMat.identity();
		this.rotationY(radianY, ___sysTempMat3D);
		this.append3x3(___sysTempMat3D);
		//s_tempMat.identity();
		this.rotationX(radianX, ___sysTempMat3D);
		this.append3x3(___sysTempMat3D);
		//s_tempMat.identity();
		this.rotationZ(radianZ, ___sysTempMat3D);
		this.append3x3(___sysTempMat3D);
    }
    appendScaleXYZ(xScale, yScale, zScale)
	{
		this[0] *= xScale; this[1] *= xScale; this[2] *= xScale; this[3] *= xScale;
		this[4] *= yScale; this[5] *= yScale; this[6] *= yScale; this[7] *= yScale;
		this[8] *= zScale; this[9] *= zScale; this[10] *= zScale; this[11] *= zScale;
	}
    appendScaleXY(xScale, yScale)
    {
        this[0] *= xScale; this[1] *= xScale; this[2] *= xScale; this[3] *= xScale;
        this[4] *= yScale; this[5] *= yScale; this[6] *= yScale; this[7] *= yScale;
    }
	appendTranslationXYZ(x, y, z)
	{
		this[12] += x;
		this[13] += y;
		this[14] += z;
	}
	appendTranslation(v3)
	{
		this[12] += v3.x;
		this[13] += v3.y;
		this[14] += v3.z;
    }
    copyColumnFrom(column_index, vector3D)
	{
		switch (column_index) {
		case 0:
		{
			this[0] = vector3D.x;
			this[1] = vector3D.y;
			this[2] = vector3D.z;
			this[3] = vector3D.w;
		}
		break;
		case 1:
		{
			this[4] = vector3D.x;
			this[5] = vector3D.y;
			this[6] = vector3D.z;
			this[7] = vector3D.w;
		}
		break;
		case 2:
		{
			this[8] = vector3D.x;
			this[9] = vector3D.y;
			this[10] = vector3D.z;
			this[11] = vector3D.w;
		}
		break;
		case 3:
		{
			this[12] = vector3D.x;
			this[13] = vector3D.y;
			this[14] = vector3D.z;
			this[15] = vector3D.w;
		}
		break;
		default:
			abort();
			break;
		}
	}
	copyColumnTo(column_index, vector3D)
	{
		//int c4 = column * 4;
		column_index <<= 2;
		vector3D.x = this[column_index];
		vector3D.y = this[1 + column_index];
		vector3D.z = this[2 + column_index];
		vector3D.w = this[3 + column_index];
    }
    copyFrom(mat_other)
	{
		this.set(mat_other,0);
    }
    copyTo(mat_other)
	{
		mat_other.set(this,0);
    }
    copyRawDataFrom(float_rawDataArr,rawDataLength, index, bool_tp)
	{
		if (bool_tp) this.transpose();
		rawDataLength = rawDataLength - index;
		let _g = 0;
		let c = 0;
        while (_g < rawDataLength) 
        {
			c = _g;
			++_g;
			//c = _g++;
			this[c] = float_rawDataArr[c + index];
		}
		if (bool_tp) transpose();
	}
	copyRawDataTo(float_rawDataArr,rawDataLength, index, bool_tp)
	{
		if (bool_tp) this.transpose();
		let _g = 0;
		let c = 0;
        while (_g < rawDataLength) 
        {
			//c = _g++;
			c = _g;
			++_g;
			float_rawDataArr[c + index] = this[c];
		}
		if (bool_tp) transpose();
	}
	copyRowFrom(row_index, vector3D)
	{
		switch (row_index) {
		case 0:
		{
			this[0] = vector3D.x;
			this[4] = vector3D.y;
			this[8] = vector3D.z;
			this[12] = vector3D.w;
		}
		break;
		case 1:
		{
			this[1] = vector3D.x;
			this[5] = vector3D.y;
			this[9] = vector3D.z;
			this[13] = vector3D.w;
		}
		break;
		case 2:
		{
			this[2] = vector3D.x;
			this[6] = vector3D.y;
			this[10] = vector3D.z;
			this[14] = vector3D.w;
		}
		break;
		case 3:
		{
			this[3] = vector3D.x;
			this[7] = vector3D.y;
			this[11] = vector3D.z;
			this[15] = vector3D.w;
		}
		break;
		default:
			abort();
			break;
		}
	}
	copyRowTo(row_index, vector3D)
	{
		vector3D.x = this[row_index];
		vector3D.y = this[4 + row_index];
		vector3D.z = this[8 + row_index];
		vector3D.w = this[12 + row_index];
	}
    decompose(orientationStyle)
	{
		// TODO: optimize after 4 lines
		let vec = [];
		// TODO: attention "static" s_tempMat
		m = ___sysTempMat3D;
		this.copyTo(m);
		//float mr[16];
		let mr = ___sysTempMat3D;
        //std::memcpy(&mr, m_rawData, m_rawDataSize);
        mr.set(this,0);
		///*
		let pos = new Vector3D(mr[12], mr[13], mr[14]);
		let scale = new Vector3D();
		scale.x = Math.sqrt(mr[0] * mr[0] + mr[1] * mr[1] + mr[2] * mr[2]);
		scale.y = Math.sqrt(mr[4] * mr[4] + mr[5] * mr[5] + mr[6] * mr[6]);
		scale.z = Math.sqrt(mr[8] * mr[8] + mr[9] * mr[9] + mr[10] * mr[10]);
		if (mr[0] * (mr[5] * mr[10] - mr[6] * mr[9]) - mr[1] * (mr[4] * mr[10] - mr[6] * mr[8]) + mr[2] * (mr[4] * mr[9] - mr[5] * mr[8]) < 0) scale.z = -scale.z;
		mr[0] /= scale.x;
		mr[1] /= scale.x;
		mr[2] /= scale.x;
		mr[4] /= scale.y;
		mr[5] /= scale.y;
		mr[6] /= scale.y;
		mr[8] /= scale.z;
		mr[9] /= scale.z;
		mr[10] /= scale.z;
		let rot = new Vector3D();
		switch (orientationStyle) {
		case OrientationType.AXIS_ANGLE:
		{
			rot.w = safeACos((mr[0] + mr[5] + mr[10] - 1) / 2);
			let len = Math.sqrt((mr[6] - mr[9]) * (mr[6] - mr[9]) + (mr[8] - mr[2]) * (mr[8] - mr[2]) + (mr[1] - mr[4]) * (mr[1] - mr[4]));
			if (len > minFloatValue) {
				rot.x = (mr[6] - mr[9]) / len;
				rot.y = (mr[8] - mr[2]) / len;
				rot.z = (mr[1] - mr[4]) / len;
			}
			else rot.x = rot.y = rot.z = 0;
		}
		break;
		case OrientationType.QUATERNION:
		{
			let tr = (mr[0] + mr[5] + mr[10]);
			if (tr > 0) {
				rot.w = Math.sqrt(1 + tr) / 2;
				rot.x = (mr[6] - mr[9]) / (4 * rot.w);
				rot.y = (mr[8] - mr[2]) / (4 * rot.w);
				rot.z = (mr[1] - mr[4]) / (4 * rot.w);
			}
			else if (mr[0] > mr[5] && mr[0] > mr[10]) {
				rot.x = Math.sqrt(1 + mr[0] - mr[5] - mr[10]) / 2;
				rot.w = (mr[6] - mr[9]) / (4 * rot.x);
				rot.y = (mr[1] + mr[4]) / (4 * rot.x);
				rot.z = (mr[8] + mr[2]) / (4 * rot.x);
			}
			else if (mr[5] > mr[10]) {
				rot.y = Math.sqrt(1 + mr[5] - mr[0] - mr[10]) / 2;
				rot.x = (mr[1] + mr[4]) / (4 * rot.y);
				rot.w = (mr[8] - mr[2]) / (4 * rot.y);
				rot.z = (mr[6] + mr[9]) / (4 * rot.y);
			}
            else
            {
				rot.z = Math.sqrt(1 + mr[10] - mr[0] - mr[5]) / 2;
				rot.x = (mr[8] + mr[2]) / (4 * rot.z);
				rot.y = (mr[6] + mr[9]) / (4 * rot.z);
				rot.w = (mr[1] - mr[4]) / (4 * rot.z);
			}
		}
		break;
		case OrientationType.EULER_ANGLES:
		{
			rot.y = Math.asin(-mr[2]);
			if (mr[2] != 1 && mr[2] != -1) {
				rot.x = Math.atan2(mr[6], mr[10]);
				rot.z = Math.atan2(mr[1], mr[0]);
			}
			else {
				rot.z = 0;
				rot.x = Math.atan2(mr[4], mr[5]);
			}
		}
		break;
		};
		vec.push(pos);
		vec.push(rot);
		vec.push(scale)
		mr = null;
		return vec;
	}
	
	deltaTransformVector(v3)
	{
		let x = v3.x;
		let y = v3.y;
		let z = v3.z;
		return new Vector3D(x * this[0] + y * this[4] + z * this[8] + this[3], x * this[1] + y * this[5] + z * this[9] + this[7], x * this[2] + y * this[6] + z * this[10] + this[11], 0);
    }
    invert()
	{
		let d = this.determinant();
		let invertable = Math.abs(d) > MATH_MIN_POSITIVE;
		if (invertable) {
			d = 1.0 / d;
			let m11 = this[0];
			let m21 = this[4];
			let m31 = this[8];
			let m41 = this[12];
			let m12 = this[1];
			let m22 = this[5];
			let m32 = this[9];
			let m42 = this[13];
			let m13 = this[2];
			let m23 = this[6];
			let m33 = this[10];
			let m43 = this[14];
			let m14 = this[3];
			let m24 = this[7];
			let m34 = this[11];
			let m44 = this[15];
			this[0] = d * (m22 * (m33 * m44 - m43 * m34) - m32 * (m23 * m44 - m43 * m24) + m42 * (m23 * m34 - m33 * m24));
			this[1] = -d * (m12 * (m33 * m44 - m43 * m34) - m32 * (m13 * m44 - m43 * m14) + m42 * (m13 * m34 - m33 * m14));
			this[2] = d * (m12 * (m23 * m44 - m43 * m24) - m22 * (m13 * m44 - m43 * m14) + m42 * (m13 * m24 - m23 * m14));
			this[3] = -d * (m12 * (m23 * m34 - m33 * m24) - m22 * (m13 * m34 - m33 * m14) + m32 * (m13 * m24 - m23 * m14));
			this[4] = -d * (m21 * (m33 * m44 - m43 * m34) - m31 * (m23 * m44 - m43 * m24) + m41 * (m23 * m34 - m33 * m24));
			this[5] = d * (m11 * (m33 * m44 - m43 * m34) - m31 * (m13 * m44 - m43 * m14) + m41 * (m13 * m34 - m33 * m14));
			this[6] = -d * (m11 * (m23 * m44 - m43 * m24) - m21 * (m13 * m44 - m43 * m14) + m41 * (m13 * m24 - m23 * m14));
			this[7] = d * (m11 * (m23 * m34 - m33 * m24) - m21 * (m13 * m34 - m33 * m14) + m31 * (m13 * m24 - m23 * m14));
			this[8] = d * (m21 * (m32 * m44 - m42 * m34) - m31 * (m22 * m44 - m42 * m24) + m41 * (m22 * m34 - m32 * m24));
			this[9] = -d * (m11 * (m32 * m44 - m42 * m34) - m31 * (m12 * m44 - m42 * m14) + m41 * (m12 * m34 - m32 * m14));
			this[10] = d * (m11 * (m22 * m44 - m42 * m24) - m21 * (m12 * m44 - m42 * m14) + m41 * (m12 * m24 - m22 * m14));
			this[11] = -d * (m11 * (m22 * m34 - m32 * m24) - m21 * (m12 * m34 - m32 * m14) + m31 * (m12 * m24 - m22 * m14));
			this[12] = -d * (m21 * (m32 * m43 - m42 * m33) - m31 * (m22 * m43 - m42 * m23) + m41 * (m22 * m33 - m32 * m23));
			this[13] = d * (m11 * (m32 * m43 - m42 * m33) - m31 * (m12 * m43 - m42 * m13) + m41 * (m12 * m33 - m32 * m13));
			this[14] = -d * (m11 * (m22 * m43 - m42 * m23) - m21 * (m12 * m43 - m42 * m13) + m41 * (m12 * m23 - m22 * m13));
			this[15] = d * (m11 * (m22 * m33 - m32 * m23) - m21 * (m12 * m33 - m32 * m13) + m31 * (m12 * m23 - m22 * m13));
		};
		return invertable;
    }
    pointAt(pos, at, up)
	{
		//TODO: need optimize
		if (at == null || at == undefined) at = new Vector3D(0.0, 0.0, -1.0);
		if (up == null || up == undefined) up = new Vector3D(0.0, -1.0, 0.0);
		let dir = at.subtract(pos);
		let vup = new Vector3D(up.x,up.y,up.z);//up->clone();
		//Vector3D right;
		dir.normalize();
		vup.normalize();
		let dir2 = new Vector3D(dir.x,dir.y,dir.z);
		dir2.scaleBy(vup.dotProduct(dir));
		//
		vup.subtractBy(dir2);
		if (vup.length() > minFloatValue) vup.normalize();
		else if (dir.x != 0)vup.setTo(-dir.y, dir.x, 0);// vup = Vector3D(-dir.y, dir.x, 0);
		else vup.setTo(1, 0, 0);// vup = Vector3D(1, 0, 0);
		let right = vup.crossProduct(dir);
		right.normalize();
		m_rawData[0] = right.x;
		m_rawData[4] = right.y;
		m_rawData[8] = right.z;
		m_rawData[12] = 0.0;
		m_rawData[1] = vup.x;
		m_rawData[5] = vup.y;
		m_rawData[9] = vup.z;
		m_rawData[13] = 0.0;
		m_rawData[2] = dir.x;
		m_rawData[6] = dir.y;
		m_rawData[10] = dir.z;
		m_rawData[14] = 0.0;
		m_rawData[3] = pos.x;
		m_rawData[7] = pos.y;
		m_rawData[11] = pos.z;
		m_rawData[15] = 1.0;
    }
    prepend(rhs)
	{
		let m111 = rhs[0];
		let m121 = rhs[4];
		let m131 = rhs[8];
		let m141 = rhs[12];
		let m112 = rhs[1];
		let m122 = rhs[5];
		let m132 = rhs[9];
		let m142 = rhs[13];
		let m113 = rhs[2];
		let m123 = rhs[6];
		let m133 = rhs[10];
		let m143 = rhs[14];
		let m114 = rhs[3];
		let m124 = rhs[7];
		let m134 = rhs[11];
		let m144 = rhs[15];
		let m211 = this[0];
		let m221 = this[4];
		let m231 = this[8];
		let m241 = this[12];
		let m212 = this[1];
		let m222 = this[5];
		let m232 = this[9];
		let m242 = this[13];
		let m213 = this[2];
		let m223 = this[6];
		let m233 = this[10];
		let m243 = this[14];
		let m214 = this[3];
		let m224 = this[7];
		let m234 = this[11];
		let m244 = this[15];
		this[0] = m111 * m211 + m112 * m221 + m113 * m231 + m114 * m241;
		this[1] = m111 * m212 + m112 * m222 + m113 * m232 + m114 * m242;
		this[2] = m111 * m213 + m112 * m223 + m113 * m233 + m114 * m243;
		this[3] = m111 * m214 + m112 * m224 + m113 * m234 + m114 * m244;
		this[4] = m121 * m211 + m122 * m221 + m123 * m231 + m124 * m241;
		this[5] = m121 * m212 + m122 * m222 + m123 * m232 + m124 * m242;
		this[6] = m121 * m213 + m122 * m223 + m123 * m233 + m124 * m243;
		this[7] = m121 * m214 + m122 * m224 + m123 * m234 + m124 * m244;
		this[8] = m131 * m211 + m132 * m221 + m133 * m231 + m134 * m241;
		this[9] = m131 * m212 + m132 * m222 + m133 * m232 + m134 * m242;
		this[10] = m131 * m213 + m132 * m223 + m133 * m233 + m134 * m243;
		this[11] = m131 * m214 + m132 * m224 + m133 * m234 + m134 * m244;
		this[12] = m141 * m211 + m142 * m221 + m143 * m231 + m144 * m241;
		this[13] = m141 * m212 + m142 * m222 + m143 * m232 + m144 * m242;
		this[14] = m141 * m213 + m142 * m223 + m143 * m233 + m144 * m243;
		this[15] = m141 * m214 + m142 * m224 + m143 * m234 + m144 * m244;
	}
	
	prepend3x3(rhs)
	{
		let m111 = rhs[0];
		let m121 = rhs[4];
		let m131 = rhs[8];
		let m112 = rhs[1];
		let m122 = rhs[5];
		let m132 = rhs[9];
		let m113 = rhs[2];
		let m123 = rhs[6];
		let m133 = rhs[10];
		let m211 = this[0];
		let m221 = this[4];
		let m231 = this[8];
		let m212 = this[1];
		let m222 = this[5];
		let m232 = this[9];
		let m213 = this[2];
		let m223 = this[6];
		let m233 = this[10];
		
		this[0] = m111 * m211 + m112 * m221 + m113 * m231;
		this[1] = m111 * m212 + m112 * m222 + m113 * m232;
		this[2] = m111 * m213 + m112 * m223 + m113 * m233
		this[4] = m121 * m211 + m122 * m221 + m123 * m231;
		this[5] = m121 * m212 + m122 * m222 + m123 * m232;
		this[6] = m121 * m213 + m122 * m223 + m123 * m233
		this[8] = m131 * m211 + m132 * m221 + m133 * m231;
		this[9] = m131 * m212 + m132 * m222 + m133 * m232;
		this[10] = m131 * m213 + m132 * m223 + m133 * m233;
    }
    prependRotationPivot(radian, axis, pivotPoint)
	{
		___sysTempMat3D.identity();
		this.getAxisRotation(axis.x, axis.y, axis.z, radian,___sysTempMat3D);
		___sysTempMat3D.appendTranslationXYZ(pivotPoint.x, pivotPoint.y, pivotPoint.z);
		this.prepend(___sysTempMat3D);
	}
	prependRotation(radian, axis)
	{
		___sysTempMat3D.identity();
		this.getAxisRotation(axis.x, axis.y, axis.z, radian, ___sysTempMat3D);
		this.prepend(___sysTempMat3D);
	}
	prependRotationX(radian)
	{
		//s_tempMat.identity();
		this.rotationX(radian, ___sysTempMat3D);
		this.prepend3x3(___sysTempMat3D);
    }
	prependRotationY(radian)
	{
		//s_tempMat.identity();
		this.rotationY(radian, ___sysTempMat3D);
		this.prepend3x3(___sysTempMat3D);
	}
	prependRotationZ(radian)
	{
		//s_tempMat.identity();
		this.rotationZ(radian, ___sysTempMat3D);
		this.prepend3x3(___sysTempMat3D);
	}
	// 用欧拉角形式旋转(heading->pitch->bank) => (y->x->z)
	prependRotationEulerAngle(radianX, radianY, radianZ)
	{
		//s_tempMat.identity();
		this.rotationY(radianY, ___sysTempMat3D);
		this.prepend3x3(___sysTempMat3D);
		//s_tempMat.identity();
		this.rotationX(radianX, ___sysTempMat3D);
		this.prepend3x3(___sysTempMat3D);
		//s_tempMat.identity();
		this.rotationZ(radianZ, ___sysTempMat3D);
		this.prepend3x3(___sysTempMat3D);
    }
    prependScale(xScale, yScale, zScale)
	{
		this[0] *= xScale; this[1] *= yScale; this[2] *= zScale;
		this[4] *= xScale; this[5] *= yScale; this[6] *= zScale;
		this[8] *= xScale; this[9] *= yScale; this[10] *= zScale;
		this[12] *= xScale; this[13] *= yScale; this[14] *= zScale;
	}
    prependScaleXY(xScale, yScale)
    {
        this[0] *= xScale; this[1] *= yScale;
        this[4] *= xScale; this[5] *= yScale;
        this[8] *= xScale; this[9] *= yScale;
        this[12] *= xScale; this[13] *= yScale;
    }
	prependTranslationXYZ(px, py, pz)
	{
		___sysTempMat3D.identity();
		___sysTempMat3D.position(px, py, pz);
		this.prepend(___sysTempMat3D);
	}
	prependTranslation(v3)
	{
		___sysTempMat3D.identity();
		___sysTempMat3D.position(v3.x, v3.y, v3.z);
		this.prepend(___sysTempMat3D);
	}
    recompose(components, orientationStyle)
	{
		if (components.length < 3 || components[2].x == 0 || components[2].y == 0 || components[2].z == 0) return false;
		this.identity();
		//float scale[10];
		let scale = ___sysTempMat3D;
		scale[0] = scale[1] = scale[2] = components[2].x;
		scale[4] = scale[5] = scale[6] = components[2].y;
		scale[8] = scale[9] = scale[10] = components[2].z;
		switch (orientationStyle) {
		case OrientationType.EULER_ANGLES:
		{
			let cx = Math.cos(components[1].x);
			let cy = Math.cos(components[1].y);
			let cz = Math.cos(components[1].z);
			let sx = Math.sin(components[1].x);
			let sy = Math.sin(components[1].y);
			let sz = Math.sin(components[1].z);
			this[0] = cy * cz * scale[0];
			this[1] = cy * sz * scale[1];
			this[2] = -sy * scale[2];
			this[3] = 0;
			this[4] = (sx * sy * cz - cx * sz) * scale[4];
			this[5] = (sx * sy * sz + cx * cz) * scale[5];
			this[6] = sx * cy * scale[6];
			this[7] = 0;
			this[8] = (cx * sy * cz + sx * sz) * scale[8];
			this[9] = (cx * sy * sz - sx * cz) * scale[9];
			this[10] = cx * cy * scale[10];
			this[11] = 0;
			this[12] = components[0].x;
			this[13] = components[0].y;
			this[14] = components[0].z;
			this[15] = 1;
		}
		break;
		default:
		{
			let x = components[1].x;
			let y = components[1].y;
			let z = components[1].z;
			let w = components[1].w;
			if (orientationStyle == OrientationType.AXIS_ANGLE) {
				let halfW = 0.5 * w;
				x *= Math.sin(halfW);
				y *= Math.sin(halfW);
				z *= Math.sin(halfW);
				w = Math.cos(halfW);
			};
			this[0] = (1 - 2 * y * y - 2 * z * z) * scale[0];
			this[1] = (2 * x * y + 2 * w * z) * scale[1];
			this[2] = (2 * x * z - 2 * w * y) * scale[2];
			this[3] = 0;
			this[4] = (2 * x * y - 2 * w * z) * scale[4];
			this[5] = (1 - 2 * x * x - 2 * z * z) * scale[5];
			this[6] = (2 * y * z + 2 * w * x) * scale[6];
			this[7] = 0;
			this[8] = (2 * x * z + 2 * w * y) * scale[8];
			this[9] = (2 * y * z - 2 * w * x) * scale[9];
			this[10] = (1 - 2 * x * x - 2 * y * y) * scale[10];
			this[11] = 0;
			this[12] = components[0].x;
			this[13] = components[0].y;
			this[14] = components[0].z;
			this[15] = 1;
		}
		break;
		};
		//TODO: need thinking
		if (components[2].x == 0) this[0] = 0;// 1e-15;
		if (components[2].y == 0) this[5] = 0;// 1e-15;
		if (components[2].z == 0) this[10] = 0;// 1e-15;
		scale = null;
		return !(components[2].x == 0 || components[2].y == 0 || components[2].y == 0);
    }
    
    transformVector(v3)
	{
		let x = v3.x;
		let y = v3.y;
		let z = v3.z;
		return new Vector3D(x * this[0] + y * this[4] + z * this[8] + this[12], x * this[1] + y * this[5] + z * this[9] + this[13], x * this[2] + y * this[6] + z * this[10] + this[14], x * this[3] + y * this[7] + z * this[11] + this[15]);
	}
	transformOutVector(v3, out_v3)
	{
		let x = v3.x;
		let y = v3.y;
		let z = v3.z;
		out_v3.setTo(x * this[0] + y * this[4] + z * this[8] + this[12], x * this[1] + y * this[5] + z * this[9] + this[13], x * this[2] + y * this[6] + z * this[10] + this[14], x * this[3] + y * this[7] + z * this[11] + this[15]);
	}
	transformVectorSelf(v3)
	{
		let x = v3.x;
		let y = v3.y;
		let z = v3.z;
		v3.setTo(x * this[0] + y * this[4] + z * this[8] + this[12], x * this[1] + y * this[5] + z * this[9] + this[13], x * this[2] + y * this[6] + z * this[10] + this[14], x * this[3] + y * this[7] + z * this[11] + this[15]);
	}
    transformVectors(float_vinArr, vinLength, float_voutArr)
	{
		let i = 0;
		let x, y, z;
		while ((i + 3) <= vinLength) {
			x = float_vinArr[i];
			y = float_vinArr[i + 1];
			z = float_vinArr[i + 2];
			float_voutArr[i] = x * this[0] + y * this[4] + z * this[8] + this[12];
			float_voutArr[i + 1] = x * this[1] + y * this[5] + z * this[9] + this[13];
			float_voutArr[i + 2] = x * this[2] + y * this[6] + z * this[10] + this[14];
			i += 3;
		}
	}
    transpose()
	{
        ___sysTempMat3D.set(this, 0);
		this[1] = ___sysTempMat3D[4];
		this[2] = ___sysTempMat3D[8];
		this[3] = ___sysTempMat3D[12];
		this[4] = ___sysTempMat3D[1];
		this[6] = ___sysTempMat3D[9];
		this[7] = ___sysTempMat3D[13];
		this[8] = ___sysTempMat3D[2];
		this[9] = ___sysTempMat3D[6];
		this[11] = ___sysTempMat3D[14];
		this[12] = ___sysTempMat3D[3];
		this[13] = ___sysTempMat3D[7];
		this[14] = ___sysTempMat3D[11];
    }
    interpolateTo(toMat, float_percent)
	{
		let _g = 0;
		let i = 0;
		while (_g < 16)
		{
			//i = _g++;
			i = _g;
			++_g;
			this[i] = this[i] + (toMat[i] - this[i]) * float_percent;
		}
	}
    getAxisRotation(x, y, z, radian, target)
	{
		radian= -radian;
		let  s = Math.sin(radian), c = Math.cos(radian);
		let  t = 1.0 - c;
		target[0] = c + x * x * t;
		target[5] = c + y * y * t;
		target[10] = c + z * z * t;
		let tmp1 = x * y * t;
		let tmp2 = z * s;
		target[4] = tmp1 + tmp2;
		target[1] = tmp1 - tmp2;
		tmp1 = x * z * t;
		tmp2 = y * s;
		target[8] = tmp1 - tmp2;
		target[2] = tmp1 + tmp2;
		tmp1 = y * z * t;
		tmp2 = x * s;
		target[9] = tmp1 + tmp2;
		target[6] = tmp1 - tmp2;
    }
    rotationX(radian, target)
	{
		let s = Math.sin(radian), c = Math.cos(radian);
		target[0] = 1.0; target[1] = 0.0; target[2] = 0.0;
		target[4] = 0.0; target[5] = c; target[6] = s;
		target[8] = 0.0; target[9] = -s; target[10] = c;
	}
	rotationY(radian, target)
	{
		let s = Math.sin(radian), c = Math.cos(radian);
		target[0] = c; target[1] = 0.0; target[2] = -s;
		target[4] = 0.0; target[5] = 1.0; target[6] = 0.0;
		target[8] = s; target[9] = 0.0; target[10] = c;
	}
	rotationZ(radian, target)
	{
		let s = Math.sin(radian), c = Math.cos(radian);
		target[0] = c; target[1] = s; target[2] = 0.0;
		target[4] = -s; target[5] = c; target[6] = 0.0;
		target[8] = 0.0; target[9] = 0.0; target[10] = 1.0;
	}
    /////////////////////////////////////////////////////////////
    toString()
    {

        let str = this[0]+","+this[1]+","+this[2]+","+this[3]+"\n";
        str += this[4]+","+this[5]+","+this[6]+","+this[7]+"\n";
        str += this[8]+","+this[9]+","+this[10]+","+this[11]+"\n";
        str += this[12]+","+this[13]+","+this[14]+","+this[15]+"\n";
        return str;
    }
    ///////
    // view etc..
    ///////////////////////////////////////////
    perspectiveRH(fovy, aspect, zNear, zFar)
	{
        //assert(abs(aspect - std::numeric_limits<float>::epsilon()) > minFloatValue)
		let tanHalfFovy = Math.tan(fovy * 0.5);
		this.identity();
		this[0] = 1.0/(aspect * tanHalfFovy);
		this[5] = 1.0 / tanHalfFovy;
		this[10] = -(zFar + zNear) / (zFar - zNear);
		this[11] = -1.0;
		this[14] = -(2.0 * zFar * zNear) / (zFar - zNear)
	}
	orthoRH(b, t, l, r, zNear, zFar)
	{
		this.identity();
		this[0] = 2.0/(r-l);
		this[5] = 2.0/(t-b);
		this[10] = -2.0 / (zFar - zNear);
		this[12] = -(r + l) / (r - l);
		this[13] = -(t + b) / (t - b);
		this[14] = -(zFar + zNear) / (zFar - zNear);
		this[15] = 1.0;
	}
	
	perspectiveLH(fovy, aspect, zNear, zFar)
	{
        //assert(abs(aspect - std::numeric_limits<float>::epsilon()) > minFloatValue)
        
		let tanHalfFovy = Math.tan(fovy * 0.5);
		this.identity();
		this[0] = 1.0 / (aspect * tanHalfFovy);
		this[5] = 1.0 / tanHalfFovy;
		this[10] = (zFar + zNear) / (zFar - zNear);
		this[11] = 1.0;
		this[14] = (2.0 * zFar * zNear) / (zFar - zNear);
	}
	orthoLH(b, t, l, r, zNear, zFar)
	{
		this.identity();
		this[0] = 2.0 / (r - l);// / (aspect * tanHalfFovy);
		this[5] = 2.0 / (t - b);// / tanHalfFovy;
		this[10] = 2.0 / (zFar - zNear);
		this[12] = -(r + l) / (r - l);
		this[13] = -(t + b) / (t - b);
		this[14] = -(zFar + zNear) / (zFar - zNear);
		this[15] = 1.0;
	}
	lookAtRH(eye, center, up)
	{
		this.identity()
		let f = center.subtract(eye);
		f.normalize();
		let s = f.crossProduct(up);
		s.normalize();
		let u = s.crossProduct(f)
		s.w = -s.dotProduct(eye);
		u.w = -u.dotProduct(eye);
		f.w = f.dotProduct(eye);
		f.negate();
		this.copyRowFrom(0, s);
		this.copyRowFrom(1, u);
		this.copyRowFrom(2, f);
	}
	lookAtLH(eye, center, up)
	{
		identity()
		let f = center.subtract(eye);
		f.normalize();
		let s = f.crossProduct(up);
		s.normalize();
		let u = s.crossProduct(f);
		
		s.w = -s.dotProduct(eye);
		u.w = -u.dotProduct(eye);
		f.w = -f.dotProduct(eye);
		this.copyRowFrom(0, s);
		this.copyRowFrom(1, u);
		this.copyRowFrom(2, f);
    }
       
};
let ___sysTempMat3D = new Matrix3D();

/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/

function AABB()
{
    this.min = new Vector3D(-50.0, -50.0, -50.0);
    this.max = new Vector3D(50.0, 50.0, 50.0);
    let m_center = new Vector3D(0.0, 0.0, 0.0);
    let m_ocenter = new Vector3D(0.0, 0.0, 0.0);
    let m_long = 100.0;
    let m_width = 100.0;
	let m_height = 100.0;
	let m_halfLong = 50.0;
    let m_halfWidth = 50.0;
    let m_halfHeight = 50.0;
	let m_radius = 87;
	let m_radius2 = 7500;
	//
	let m_tempV = new Vector3D();
	// max bounds sphere range intersect calc
	this.sphereIntersectFast = function(centerV,radius)
	{
		m_tempV.x = m_center.x - centerV.x;
		m_tempV.y = m_center.y - centerV.y;
		m_tempV.z = m_center.z - centerV.z;
		let dis = m_tempV.lengthSquared();
		if(dis < m_radius2)
		{
			return true;
		}
		radius += m_radius;
		radius *= radius;
		return radius >= dis;
	}
    this.getCenter = function()
    {
        return m_center;
	}
	this.moveXYZ = function(px,py,pz)
    {
		m_center.x = m_ocenter.x + px;
		m_center.y = m_ocenter.y + py;
		m_center.z = m_ocenter.z + pz;
		//
		this.max.x = m_center.x + m_halfWidth;
		this.max.y = m_center.y + m_halfHeight;
		this.max.z = m_center.z + m_halfLong;
		//
		this.min.x = m_center.x - m_halfWidth;
		this.min.y = m_center.y - m_halfHeight;
		this.min.z = m_center.z - m_halfLong;
	}
	
	this.getRadius = function(){return m_radius}
	this.getRadiusSquared = function(){return m_radius2}
	this.addXYZ = function(px,py,pz)
    {
		if (this.min.x > px) this.min.x = px;
		if (this.min.y > py) this.min.y = py;
		if (this.min.z > pz) this.min.z = pz;
		if (this.max.x < px) this.max.x = px;
		if (this.max.y < py) this.max.y = py;
		if (this.max.z < pz) this.max.z = pz;
	}
	this.setVolume = function(width,height,long)
    {
		m_width = width;
		m_height = height;
		m_long = long;
		//
		m_halfLong = 0.5 * m_long;
    	m_halfWidth = 0.5 * m_width;
		m_halfHeight = 0.5 * m_height;
		//
		this.max.x = m_center.x + m_halfWidth;
		this.max.y = m_center.y + m_halfHeight;
		this.max.z = m_center.z + m_halfLong;
		//
		this.min.x = m_center.x - m_halfWidth;
		this.min.y = m_center.y - m_halfHeight;
		this.min.z = m_center.z - m_halfLong;

		m_radius2 = m_halfWidth * m_halfWidth + m_halfHeight * m_halfHeight + m_halfLong * m_halfLong;
		m_radius = Math.sqrt(m_radius2);
		
	}
	this.addPosition = function(pv)
    {
		if (this.min.x > pv.x) this.min.x = pv.x;
		if (this.min.y > pv.y) this.min.y = pv.y;
		if (this.min.z > pv.z) this.min.z = pv.z;
		if (this.max.x < pv.x) this.max.x = pv.x;
		if (this.max.y < pv.y) this.max.y = pv.y;
		if (this.max.z < pv.z) this.max.z = pv.z;
	}
    this.update = function()
    {
       	// x
		m_width = this.max.x;
		if (this.min.x > this.max.x)
		{
			this.max.x = this.min.x;
			this.min.x = m_width;
		}
		m_width = this.max.x - this.min.x;
		// y
		m_height = this.max.y;
		if (this.min.y > this.max.y)
		{
			this.max.y = this.min.y;
			this.min.y = m_height;
		}
		m_height = this.max.y - this.min.y;
		// z
		m_long = this.max.z;
		if (this.min.z > this.max.z)
		{
			this.max.z = this.min.z;
			this.min.z = m_long;
		}
		m_long = this.max.z - this.min.z;
		//
		m_center.x = 0.5 * m_width;
		m_center.y = 0.5 * m_height;
		m_center.z = 0.5 * m_long;
		//
		m_halfLong = m_center.z;
    	m_halfWidth = m_center.x;
    	m_halfHeight = m_center.y;
		//
		m_radius2 = m_halfWidth * m_halfWidth + m_halfHeight * m_halfHeight + m_halfLong * m_halfLong;
		m_radius = Math.sqrt(m_radius2);
		//
		m_center.x += this.min.x;
		m_center.y += this.min.y;
		m_center.z += this.min.z;
		//
		m_ocenter.copyFrom(m_center);
	}

	this.updateFast = function()
    {
		m_width = this.max.x - this.min.x;
		m_height = this.max.y - this.min.y;
		m_long = this.max.z - this.min.z;
		//
		m_center.x = 0.5 * m_width;
		m_center.y = 0.5 * m_height;
		m_center.z = 0.5 * m_long;
		//
		m_halfLong = m_center.z;
    	m_halfWidth = m_center.x;
    	m_halfHeight = m_center.y;
		//
		m_radius2 = m_halfWidth * m_halfWidth + m_halfHeight * m_halfHeight + m_halfLong * m_halfLong;
		m_radius = Math.sqrt(m_radius2);
		//
		m_center.x += this.min.x;
		m_center.y += this.min.y;
		m_center.z += this.min.z;
		m_ocenter.copyFrom(m_center);
    }
};
/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/



var __defaultTex_bufID = null;
function TextureProxy()
{
    var m_uploadBufBoo = true;
    var m_texImg = null;
    var m_texBuf = null;
    // rtt used true or false
    this.fboOutEnabled = false;
    this.fboIndex = -1;
    //
    var m_imgLoaded = false;
    // uniform sampler index
    this.texIndex = 0;
    // uniform sampler total
    this.texTotal = 1;
    // combination texture
    this.next = null;

    this.internalFormat = TextureFormat.RGBA;
    this.srcFormat = TextureFormat.RGBA;
    this.dataType = TextureDataType.UNSIGNED_BYTE;
    this.mipmapEnabled = false;
    var texTarget = null;
    //
    this.getType = function()
    {
        return TextureConst.TEXTURE_2D;
    }
    this.__gpuBuf = function(){return m_texBuf;}
    //
    let m_texWidth = 128;
    let m_texHeight = 128;
    this.getWidth = function(){return m_texWidth;}
    this.getHeight = function(){return m_texHeight;}
    //  
    var loadedImgCallback = function()
    {
        m_imgLoaded = true;
        if(m_texImg != null)
        {
            m_texWidth = m_texImg.width;
            m_texHeight = m_texImg.height;
        }
        //console.log("TextureProxy::loadedImgCallback(),loaded a TextureProxy("+m_texWidth+","+m_texHeight+")");
    }
    this.dataEnough = function(){ return m_imgLoaded;}
    //
    this.getNumTextures = function(){return 1;};
    //
    this.initializeBySize = function(width,height, powerof2Boo)
    {
        if(m_texBuf == null)
        {
            if(width == undefined) width = 128;
            if(height == undefined) height = 128;
            if(powerof2Boo == undefined || powerof2Boo == true)
            {
                m_texWidth = calcNearestCeilPow2(width);
                m_texHeight = calcNearestCeilPow2(height);
            }else
            {
                m_texWidth = width;
                m_texHeight = height;
            }
            //trace("TextureProxy::initializeBySize(), TextureProxy("+m_texWidth+","+m_texHeight+")");
        }
    }
    this.initializeByTexBuf = function(texBuf,ptexTarget) 
    {
        if(texBuf != undefined && texBuf != null)
        {
            m_texBuf = texBuf;
            m_uploadBufBoo = false;
            m_imgLoaded = true;
            texTarget = ptexTarget;
            //trace("TextureProxy::initializeByTexBuf(), Img("+m_texWidth+","+m_texHeight+")");
        }
    };
    this.loadImgFromUrl = function(purl)
    {
        if(m_texImg == null)
        {
            m_texImg = new Image();
            m_texImg.onload = loadedImgCallback;
        }
        m_texImg.crossOrigin = "";
        //m_texImg.setAttribute('crossorigin', 'anonymous');
        m_texImg.src = purl;
        
    };
    this.destroy = function(gl)
    {
        if(m_texBuf != null)
        {
            gl.deleteTexture(m_texBuf);
            m_texBuf = null;
        }
    };
    this._buildParam = function(gl)
    {

        if (this.mipmapEnabled && isPowerOf2(m_texWidth) && isPowerOf2(m_texHeight))
        {
            gl.hint(gl.GENERATE_MIPMAP_HINT, gl.NICEST);
            gl.generateMipmap(texTarget);
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_S, TextureConst.getConst(gl,this.wrap_s));
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_T, TextureConst.getConst(gl,this.wrap_t));//REPEAT
            gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
            //trace("TextureProxy::_buildParam(), .........._buildParam....B "+this.name);
        } else {
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_S, TextureConst.getConst(gl,this.wrap_s));
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_T, TextureConst.getConst(gl,this.wrap_t));//REPEAT
            gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
            gl.texParameteri(texTarget, gl.TEXTURE_MAG_FILTER, gl.LINEAR);            
            //gl.texParameteri(texTarget, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
            //trace("TextureProxy::_buildParam(), .........._buildParam....A "+this.name);
            //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
            //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
            //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        }
    }
    this.wrap_s = TextureConst.WRAP_CLAMP_TO_EDGE;
    this.wrap_t = TextureConst.WRAP_CLAMP_TO_EDGE;
    this.isUploaded = function(){return !m_uploadBufBoo};
    //this.isHaveGpuBuf = function(){return m_texBuf != null};
    this.upload = function(gl) 
    {
        if(m_uploadBufBoo)
        {
            if(TextureConst.initEnbled) TextureConst.initialize(gl);            
            
            if(m_imgLoaded && m_texBuf == null)
            {
                texTarget = gl.TEXTURE_2D;
                if(m_texBuf == null) m_texBuf = gl.createTexture();
                gl.bindTexture(texTarget, m_texBuf);
                //this.dataType = TextureDataType.UNSIGNED_BYTE;
                //TextureDataType.toGL(this.dataType)
                //trace("TextureBase::upload(), TextureDataType.toGL(this.dataType): "+TextureDataType.toGL(gl, this.dataType)+", this.dataType: "+this.dataType);
                gl.texImage2D(texTarget, 0, TextureFormat.toGL(gl,this.internalFormat),
                TextureFormat.toGL(gl,this.srcFormat), TextureDataType.toGL(gl, this.dataType), m_texImg);
                //
                this._buildParam(gl);
                //
                m_uploadBufBoo = false;
                //trace(this.name+", >>>>>>>>>>>>>>>>>>>>>>>>>>>uploadA...m_texImg: "+m_texImg);
            }
            else if(m_texBuf == null)
            {
                texTarget = gl.TEXTURE_2D;
                if(__defaultTex_bufID == null)
                {
                    __defaultTex_bufID = gl.createTexture();
                    gl.bindTexture(gl.TEXTURE_2D, __defaultTex_bufID);
                    const pixel = new Uint8Array([0, 0, 255, 255,255, 0, 0, 255,0, 0, 255, 255,0, 0, 255, 255]);  // opaque blue
                    gl.texImage2D(
                                    texTarget, 0, TextureFormat.toGL(gl,this.internalFormat),
                                    1, 1, 0, TextureFormat.toGL(gl,this.srcFormat), gl.UNSIGNED_BYTE,
                                    pixel
                                );
                }
            }else
            {
                //trace("TextureProxy::upload(), _buildParam() ...");
                //this._buildParam(gl);
                m_uploadBufBoo = false;
            }
            //trace("TextureProxy::upload(),run..");
        }
    };
    this.use = function(gl) 
    {
        gl.activeTexture(gl.TEXTURE0 + this.texIndex);
        if(m_texBuf != null)
        {
            //trace("TextureProxy::use(),this.texIndex: "+this.texIndex+","+m_texBuf+","+this.name);
            gl.bindTexture(texTarget, m_texBuf);
        }
        else
        {
            gl.bindTexture(texTarget, __defaultTex_bufID);
        }
        //console.log("TextureProxy::use(),run..m_texBuf: "+m_texBuf);
    };
};
function CubeTexturesProxy()
{
    let m_uploadBufBoo = true;
    var m_texImgArr = null;
    var m_texUrlsArr = null;
    var m_texBuf = null;
    //var m_tex_bufIDsArr = null;
    //var m_uniformTexIDsArr = null;
    //
    let m_needLoaded = true;
    let m_imgLoaded = false;
    let m_texLoadedTotal = 0;
    //
    this.internalFormat = TextureFormat.RGBA;
    this.srcFormat = TextureFormat.RGBA;
    this.dataType = TextureDataType.UNSIGNED_BYTE;
    //
    this.mipmapEnabled = false;
    // uniform sampler index
    this.texIndex = 0;
    // uniform sampler total
    this.texTotal = 1;
    // combination texture
    this.next = null;
    //
    let m_texWidth = 128;
    let m_texHeight = 128;
    this.getWidth = function(){return m_texWidth;}
    this.getHeight = function(){return m_texHeight;}
    //
    this.getType = function()
    {
        return TextureConst.TEXTURE_CUBE;
    }
    this.__gpuBuf = function(){return m_texBuf;}
    var texTarget = null;
    var loadedImgCallback = function()
    {
        console.log("TextureProxy::loadedImgCallback(),loaded a img");
        m_texLoadedTotal ++;
        if(m_texLoadedTotal >= m_texUrlsArr.length)
        {
            m_texLoadedTotal = m_texUrlsArr.length;
            m_imgLoaded = true;
        }
    }
    //
    this.initializeBySize = function(size, powerof2Boo)
    {
        if(m_texBuf == null)
        {
            if(size == undefined) size = 128;
            if(powerof2Boo == undefined || powerof2Boo == true)
            {
                m_texWidth = calcNearestCeilPow2(size);
            }
            m_texHeight = m_texWidth;
            //trace("CubeTexturesProxy::initializeBySize(), CubeTexturesProxy("+m_texWidth+" x "+m_texHeight+")");
        }
    }
    // @param       sideIndex [0~5]
    this.initializeByTexBuf = function(texBuf) 
    {
        if(texBuf != undefined && texBuf != null)
        {
            m_texBuf = texBuf;
            m_uploadBufBoo = false;
            m_imgLoaded = true;
            //trace("CubeTexturesProxy::initializeByTexBuf(), Img("+m_texWidth+","+m_texHeight+")");
        }
    };
    this.getNumTextures = function(){return 1;};
    this.dataEnough = function(){ return m_imgLoaded;}
    //
    this.initialize = function() 
    {
    };
    this.loadImgFromUrls = function(purlsArr)
    {
        let len = purlsArr.length;
        if(len != 6)
        {
            throwSysError("Error!");
            abort();
            return;
        }
        if(m_needLoaded)
        {
            m_needLoaded = false;
            m_texUrlsArr = [];
            m_texImgArr = [];
            var m_texImg = null;
            let purl = "";
            for(let i = 0; i < len; ++i)
            {
                purl = purlsArr[i];
                m_texUrlsArr.push( purl );
                m_texImg = new Image();
                m_texImgArr.push( m_texImg );
                m_texImg.onload = loadedImgCallback;
                m_texImg.src = purl;
            }
        }
        
    };
    this.destroy = function()
    {
    };
    this.wrap_s = TextureConst.WRAP_CLAMP_TO_EDGE;//TextureConst.WRAP_CLAMP_TO_EDGE;
    this.wrap_t = TextureConst.WRAP_CLAMP_TO_EDGE;//TextureConst.WRAP_CLAMP_TO_EDGE;
    this.setTexDefaultParam = function(gl)
    {
        //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
        //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        //trace("------------------setTexDefaultParam---------------");
        //return;
        if (this.mipmapEnabled)
        {
            gl.generateMipmap(texTarget);
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_S, TextureConst.getConst(gl,this.wrap_s));
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_T, TextureConst.getConst(gl,this.wrap_t));//REPEAT
            gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
        } else {
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_S, TextureConst.getConst(gl,this.wrap_s));
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_T, TextureConst.getConst(gl,this.wrap_t));
            gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
            gl.texParameteri(texTarget, gl.TEXTURE_MAG_FILTER, gl.NEAREST);        
        }
    }
    this.isUploaded = function(){return !m_uploadBufBoo};
    this.upload = function(gl) 
    {
        if(TextureConst.initEnbled) TextureConst.initialize(gl);
        if(m_uploadBufBoo)
        {
            texTarget = gl.TEXTURE_CUBE_MAP;
            if(m_imgLoaded)
            {
                var img = null;
                m_texBuf = gl.createTexture();
                gl.bindTexture(texTarget, m_texBuf);
                for(let i = 0; i < m_texLoadedTotal; ++i)
                {
                    img = m_texImgArr[i];
                    
                    gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, TextureFormat.toGL(gl,this.internalFormat),
                        TextureFormat.toGL(gl,this.srcFormat), TextureDataType.toGL(gl, this.dataType), img);
                    //if(true)
                    //{
                    //    gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, TextureFormat.toGL(gl,this.internalFormat),
                    //        TextureFormat.toGL(gl,this.srcFormat), gl.UNSIGNED_BYTE, img);
                    //}else
                    //{
                    //    gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, TextureFormat.toGL(gl,this.internalFormat),
                    //        TextureFormat.toGL(gl,this.srcFormat), gl.UNSIGNED_BYTE, null);
                    //}
                }
                this.setTexDefaultParam(gl);
                m_uploadBufBoo = false;
            }
            //console.log("TextureProxy::upload(),run..");
        }
    };
    
    this.use = function(gl) 
    {
        if(m_texBuf != null)
        {
            gl.activeTexture(gl.TEXTURE0 + this.texIndex);
            gl.bindTexture(texTarget, m_texBuf);
        }
    };
};


function MultTexturesProxy()
{
    let m_uploadBufBoo = true;
    var m_texImgArr = null;
    var m_texUrlsArr = null;
    var m_texBuf = null;
    var m_tex_bufIDsArr = null;
    //var m_uniformTexIDsArr = null;
    // rtt used true or false
    this.fboOutEnabled = false;
    //
    let m_needLoaded = true;
    let m_imgLoaded = false;
    let m_texLoadedTotal = 0;
    //
    this.internalFormat = TextureFormat.RGBA;
    this.srcFormat = TextureFormat.RGBA;
    this.dataType = TextureDataType.UNSIGNED_BYTE;
    this.mipmapEnabled = false;
    // uniform sampler index
    this.texIndex = 0;
    // uniform sampler total
    this.texTotal = 1;
    // combination texture
    this.next = null;
    this.getType = function()
    {
        return TextureConst.TEXTURE_2D;
    }
    this.__gpuBuf = function(){return m_texBuf;}
    var texTarget = null;    
    var loadedImgCallback = function()
    {
        console.log("TextureProxy::loadedImgCallback(),loaded a img");
        m_texLoadedTotal ++;
        if(m_texLoadedTotal >= m_texUrlsArr.length)
        {
            m_texLoadedTotal = m_texUrlsArr.length;
            m_imgLoaded = true;
        }
    }
    this.dataEnough = function(){ return m_imgLoaded;}
    this.getNumTextures = function(){return m_texLoadedTotal;};
    //
    this.initializeByTexBufs = function(texBufsArr,ptexTarget) 
    {
        if(texBufsArr != undefined && texBufsArr != null && texBufsArr.length > 1)
        {
            m_needLoaded = false;
            m_texLoadedTotal = texBufsArr.length;
            m_tex_bufIDsArr = [];
            for(let i = 0; i < m_texLoadedTotal; i++)
            {
                m_tex_bufIDsArr.push(texBufsArr[i]);
            }
            m_texBuf = texBufsArr[0];
            m_uploadBufBoo = false;
            m_imgLoaded = true;
            texTarget = ptexTarget;
        }
    };
    this.loadImgFromUrls = function(purlsArr)
    {
        let len = purlsArr.length;
        if(len < 2)
        {
            throwSysError("MultTexturesProxy::loadImgFromUrls(),urls.length < 2, Error!");
            return;
        }
        this.texTotal = len;
        if(m_needLoaded)
        {
            m_needLoaded = false;
            m_texUrlsArr = [];
            m_texImgArr = [];
            var m_texImg = null;
            let purl = "";
            for(let i = 0; i < len; ++i)
            {
                purl = purlsArr[i];
                m_texUrlsArr.push( purl );
                m_texImg = new Image();
                m_texImgArr.push( m_texImg );
                m_texImg.onload = loadedImgCallback;
                m_texImg.src = purl;
            }
            //m_texImg.crossOrigin = "";
            //m_texImg.setAttribute('crossorigin', 'anonymous');
        }
        
    };
    this.destroy = function()
    {
    };
    this.wrap_s = TextureConst.WRAP_REPEAT;//TextureConst.WRAP_CLAMP_TO_EDGE;
    this.wrap_t = TextureConst.WRAP_REPEAT;//TextureConst.WRAP_CLAMP_TO_EDGE;
    this.setTexDefaultParam = function(gl,img)
    {
        if (this.mipmapEnabled && isPowerOf2(img.width) && isPowerOf2(img.height))
        {
            gl.generateMipmap(texTarget);
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_S, TextureConst.getConst(gl,this.wrap_s));
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_T, TextureConst.getConst(gl,this.wrap_t));//REPEAT
            gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
        } else {
            //
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_S, TextureConst.getConst(gl,this.wrap_s));
            gl.texParameteri(texTarget, gl.TEXTURE_WRAP_T, TextureConst.getConst(gl,this.wrap_t));//REPEAT
            //
            gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
            gl.texParameteri(texTarget, gl.TEXTURE_MAG_FILTER, gl.LINEAR);                   
        }
    }
    this.isUploaded = function(){return !m_uploadBufBoo};
    this.upload = function(gl) 
    {
        if(TextureConst.initEnbled) TextureConst.initialize(gl);
        if(m_uploadBufBoo)
        {
            m_tex_bufIDsArr = [];
            texTarget = gl.TEXTURE_2D;
            if(m_imgLoaded)
            {
                var img = null;
                for(let i = 0; i < m_texLoadedTotal; ++i)
                {
                    img = m_texImgArr[i];
                    m_texBuf = gl.createTexture();
                    m_tex_bufIDsArr.push(m_texBuf);
                    gl.bindTexture(texTarget, m_texBuf);
                    
                    //trace("MultTexturesProxy::upload(), TextureDataType.toGL(gl, this.dataType): "+TextureDataType.toGL(gl, this.dataType)+", this.dataType: "+this.dataType);
                    gl.texImage2D(texTarget, 0, TextureFormat.toGL(gl,this.internalFormat),
                    TextureFormat.toGL(gl,this.srcFormat), TextureDataType.toGL(gl, this.dataType), img);
                    this.setTexDefaultParam(gl,img);
                }                
                m_uploadBufBoo = false;                
            }
            //console.log("TextureProxy::upload(),run..");
        }
    };
    this.use = function(gl) 
    {
        if(m_texBuf != null)
        {
            for(let i = 0; i < m_texLoadedTotal; i++)
            {
                gl.activeTexture(gl.TEXTURE0 + i + this.texIndex);
                gl.bindTexture(texTarget, m_tex_bufIDsArr[i]);
            }
        }
        else
        {
            for(let i = 0; i < m_texLoadedTotal; i++)
            {
                gl.activeTexture(gl.TEXTURE0 + i);
                gl.bindTexture(texTarget, __defaultTex_bufID);
            }
        }
        //console.log("TextureProxy::use(),run..m_texBuf: "+m_texBuf);
    };
};

// internalformat: gl.ALPHA 
function AlphaTextureProxy()
{
    var m_uploadBufBoo = true;
    var m_texBuf = null;
    var m_imgLoaded = false;
    // uniform sampler index
    this.texIndex = 0;
    // uniform sampler total
    this.texTotal = 1;
    // combination texture
    this.next = null;
    this.internalFormat = TextureFormat.ALPHA;
    this.srcFormat = TextureFormat.ALPHA;
    this.dataType = TextureDataType.UNSIGNED_BYTE;
    //
    this.mipmapEnabled = false;
    //
    this.getType = function()
    {
        return TextureConst.TEXTURE_2D;
    }
    this.__gpuBuf = function(){return m_texBuf;}
    var texTarget = null;
    //
    var m_bytesData = null;
    var m_imgWidth = 0;
    var m_imgHeight = 0;
    var m_changeBytesData = false;
    
    this.getNumTextures = function(){return 1;};
    this.destroy = function()
    {
    };
    this.dataEnough = function(){ return m_bytesData != null;}
    this.setBytesData = function(uint8arr,twidth,theight,offset)
    {   if(uint8arr != undefined && uint8arr != null) m_imgLoaded = true; 

        if(offset == undefined)
        {
            offset = 0;
        }
        m_bytesData = uint8arr;
        m_imgWidth = twidth;
        m_imgHeight = theight;
        m_changeBytesData = true;
    }
    var m_subImgWidth = 0;
	var m_subImgHeight = 0;
	var m_subX = 0;
	var m_subY = 0;
    var m_subBytesData = null;
    var m_changeSubBytesData = false;
	this.setSubBytesData = function(uint8arr,px,py,twidth,theight,offset)
    {   if(uint8arr != undefined && uint8arr != null) m_imgLoaded = true; 

        if(offset == undefined)
        {
            offset = 0;
        }
		m_subBytesData = uint8arr;
		m_subX = px;
		m_subY = py;
        m_subImgWidth = twidth;
		m_subImgHeight = theight;
        m_changeSubBytesData = true;
        //trace("AlphaTextureProxy::setSubBytesData()");
    }
    this.wrap_s = TextureConst.WRAP_CLAMP_TO_EDGE;
    this.wrap_t = TextureConst.WRAP_CLAMP_TO_EDGE;
    this.isUploaded = function(){return !m_uploadBufBoo};
    this.upload = function(gl) 
    {
        if(TextureConst.initEnbled) TextureConst.initialize(gl);
        if(m_uploadBufBoo)
        {
            texTarget = gl.TEXTURE_2D;
            if(m_imgLoaded)
            {
                //gl.pixelStorei(gl.PACK_ALIGNMENT,4);
                m_changeBytesData = false;
                if(m_texBuf == null)
                {
                    //m_tex_buf
                    m_texBuf = gl.createTexture();
                }
                //
                gl.bindTexture(texTarget, m_texBuf);
                gl.texImage2D(texTarget, 0, gl.ALPHA,
                                    m_imgWidth, m_imgHeight, 0, gl.ALPHA, TextureDataType.toGL(gl, this.dataType),
                                    m_bytesData
                                ); 
                if (this.mipmapEnabled && isPowerOf2(m_imgWidth) && isPowerOf2(m_imgHeight))
                {
                    // Yes, it's a power of 2. Generate mips.
                    gl.generateMipmap(texTarget);
                    gl.texParameteri(texTarget, gl.TEXTURE_WRAP_S, TextureConst.getConst(gl,this.wrap_s));
                    gl.texParameteri(texTarget, gl.TEXTURE_WRAP_T, TextureConst.getConst(gl,this.wrap_t));//REPEAT
                    gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
                    gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
                } else {
                    gl.texParameteri(texTarget, gl.TEXTURE_WRAP_S, TextureConst.getConst(gl,this.wrap_s));
                    gl.texParameteri(texTarget, gl.TEXTURE_WRAP_T, TextureConst.getConst(gl,this.wrap_t));
                    gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
                    gl.texParameteri(texTarget, gl.TEXTURE_MAG_FILTER, gl.NEAREST);        
                }
                m_uploadBufBoo = false;
            }
            //console.log("TextureProxy::upload(),run..");
        }else if(m_texBuf != null)
        {
            if(m_changeSubBytesData)
            {
                gl.pixelStorei(gl.UNPACK_ALIGNMENT,1);
                gl.bindTexture(texTarget, m_texBuf);
                gl.texSubImage2D(texTarget, 0, m_subX, m_subY, m_subImgWidth, m_subImgHeight, gl.ALPHA, gl.UNSIGNED_BYTE, m_subBytesData);
                m_changeSubBytesData = false;
                gl.pixelStorei(gl.PACK_ALIGNMENT,4);
            }
        }
    };
    this.use = function(gl)
    {
        gl.activeTexture(gl.TEXTURE0 + this.texIndex);
        if(m_texBuf != null)
        {
            gl.bindTexture(texTarget, m_texBuf);
            if(m_changeBytesData)
            {
				gl.texSubImage2D(texTarget, 0, 0, 0, m_imgWidth, m_imgHeight, gl.ALPHA, TextureDataType.toGL(gl, this.dataType), m_bytesData);
                m_changeBytesData = false;
            }else if(m_changeSubBytesData)
            {
                gl.pixelStorei(gl.UNPACK_ALIGNMENT,1);
                gl.texSubImage2D(texTarget, 0, m_subX, m_subY, m_subImgWidth, m_subImgHeight, gl.ALPHA, TextureDataType.toGL(gl, this.dataType), m_subBytesData);
                m_changeSubBytesData = false;
                gl.pixelStorei(gl.UNPACK_ALIGNMENT,4);
            }
        }
        else
        {
            if(__defaultTex_bufID != null)gl.bindTexture(texTarget, __defaultTex_bufID);
        }
    };
};


function TextureUint8Proxy()
{
    var m_uploadBufBoo = true;
    var m_texBuf = null;
    // uniform sampler index
    this.texIndex = 0;
    // uniform sampler total
    this.texTotal = 1;
    // combination texture
    this.next = null;
    this.internalFormat = TextureFormat.RGBA;
    this.srcFormat = TextureFormat.RGBA;
    this.dataType = TextureDataType.UNSIGNED_BYTE;
    this.mipmapEnabled = false;
    this.getType = function()
    {
        return TextureConst.TEXTURE_2D;
    }
    this.__gpuBuf = function(){return m_texBuf;}
    var texTarget = null;
    var m_pixelData = null;
    let m_width = 0;
    let m_height = 0;
    this.initialize = function() 
    {
        
    };
    
    this.dataEnough = function(){ return m_pixelData != null;}
    //
    this.initializeByTexBuf = function(texBuf,ptexTarget) 
    {
        if(texBuf != undefined && texBuf != null)
        {
            m_texBuf = texBuf;
            m_uploadBufBoo = false;
            texTarget = ptexTarget;
        }
    };

    this.setUint8ArrData = function(uin8Pixel,pw,ph) 
    {
        if(m_uploadBufBoo && uin8Pixel != undefined)
        {
            // default RGBA
            let step = 4;
            switch(this.srcFormat)
            {
                case TextureFormat.RGB:
                step = 3;
                break;
                case TextureFormat.ALPHA:
                step = 1;
                break;

            }
            if((uin8Pixel.length/step) != (pw * ph))
            {
                alert("TextureUint8Proxy::setUint8ArrData() Data Error!");
                return;
            }
            m_pixelData = uin8Pixel;
            m_width =pw;
            m_height =ph;
        }
    };
    this.destroy = function()
    {

    };
    //
    this.wrap_s = TextureConst.WRAP_CLAMP_TO_EDGE;
    this.wrap_t = TextureConst.WRAP_CLAMP_TO_EDGE;
    this.isUploaded = function(){return !m_uploadBufBoo};
    this.upload = function(gl) 
    {
        if(m_uploadBufBoo)
        {
            if(TextureConst.initEnbled) TextureConst.initialize(gl);
            texTarget = gl.TEXTURE_2D;
            if(m_texBuf == null)
            {
                m_texBuf = gl.createTexture();
            }
            gl.bindTexture(texTarget, m_texBuf);
            //trace("TextureUint8Proxy::upload(), 2------------------m_width,m_height: "+m_width+","+m_height+", this.mipmapEnabled: "+this.mipmapEnabled);
            gl.texImage2D(
                texTarget, 0, TextureFormat.toGL(gl,this.internalFormat),
                m_width, m_height, 0, TextureFormat.toGL(gl,this.srcFormat), TextureDataType.toGL(gl, this.dataType),
                m_pixelData
            );
            //trace("TextureUint8Proxy::upload(), m_pixelData.length: "+m_pixelData.length);
            //gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, 4, 4, 0, gl.RGBA, gl.FLOAT, m_pixelData);
            if (this.mipmapEnabled && isPowerOf2(m_texImg.width) && isPowerOf2(m_texImg.height))
            {
                // Yes, it's a power of 2. Generate mips.
                gl.hint(gl.GENERATE_MIPMAP_HINT, gl.NICEST);
                gl.generateMipmap(texTarget);
                gl.texParameteri(texTarget, gl.TEXTURE_WRAP_S, TextureConst.getConst(gl,this.wrap_s));
                gl.texParameteri(texTarget, gl.TEXTURE_WRAP_T, TextureConst.getConst(gl,this.wrap_t));//REPEAT
                gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
                gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
            } else {
                //
                //trace("TextureUint8Proxy::upload(), 2----------------------------TextureUint8Proxy----------------------------------upload()");
                gl.texParameteri(texTarget, gl.TEXTURE_WRAP_S, TextureConst.getConst(gl,this.wrap_s));
                gl.texParameteri(texTarget, gl.TEXTURE_WRAP_T, TextureConst.getConst(gl,this.wrap_t));//REPEAT
                ////
                //gl.texParameteri(texTarget, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
                //gl.texParameteri(texTarget, gl.TEXTURE_MAG_FILTER, gl.NEAREST);    
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
                //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
                //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);             
            }
            m_uploadBufBoo = false;
            //console.log("TextureProxy::upload(),run..");
        }
    };
    this.use = function(gl) 
    {
        gl.activeTexture(gl.TEXTURE0 + this.texIndex);
        if(m_texBuf != null)
        {
            gl.bindTexture(texTarget, m_texBuf);
        }
        else
        {
            gl.bindTexture(texTarget, __defaultTex_bufID);
        }
        //console.log("TextureProxy::use(),run..m_texBuf: "+m_texBuf);
    };
};
//var uint8Tex = new TextureUint8Proxy();
let ___voxTexDict = {};
TextureProxy.Create = function(purl,internalFormat,srcFormat)
{
    //console.log("TextureProxy.Create() begin...");
    if(purl ==undefined)
    {
        return null;
    }
    if((typeof purl) == "string")
    {
        var t = ___voxTexDict[purl];
        if(t == undefined || t == null)
        {
            //t = new TextureProxy(unique_name_str, vshdsrc,fshdSrc);
            t = new TextureProxy();
            t.internalFormat = internalFormat;
            t.srcFormat = srcFormat;
            t.loadImgFromUrl(purl);
            ___voxTexDict[purl] = t;
            //console.log("TextureProxy.Create() new TextureProxy: ",t);
        }
        return t;
    }
    return null;
}
/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/
"use strict"

const VTXLAYOUT_AUTO = 100000000;
//
const VTXLAYOUT_1 = 110000000;
const VTXLAYOUT_2 = 120000000;
const VTXLAYOUT_2_2 = 122000000;
const VTXLAYOUT_3 = 130000000;
const VTXLAYOUT_3_2 = 132000000;
const VTXLAYOUT_3_2_2 = 132200000;
const VTXLAYOUT_3_2_3 = 132300000;
const VTXLAYOUT_3_3 = 133000000;
const VTXLAYOUT_3_3_3 = 133300000;
const VTXLAYOUT_3_4 = 134000000;
const VTXLAYOUT_3_3_4 = 133400000;
const VTXLAYOUT_4 = 140000000;
const VTXLAYOUT_4_4 = 144000000;
const VTXLAYOUT_4_3_3_2 = 143320000;
const VTXLAYOUT_4_4_4_4 = 144440000;
const VTXLAYOUT_4_4_4_4_4 = 144444000;
const VTXLAYOUT_4_4_4_4_2 = 144442000;
//
const VTX_STATIC_DRAW = 0;
const VTX_DYNAMIC_DRAW = 1;
//
const VTXTYPE_GL_POINTS = 101;
const VTXTYPE_GL_LINES = 102;
const VTXTYPE_GL_LINE_STRIP = 103;
const VTXTYPE_GL_TRIANGLES = 111;

function VtxBufBlock()
{
    this.dynamicUpdateEnabled = false;
    //
    let m_type = 0;
    let m_layoutList = null;
    let m_bufs = [];
    let m_dataList = null;
    // record: static draw or dynamic draw
    let m_statusList = null;
    // record sub data need update
    let m_updateList = null;

    //if(dataList != undefined) m_dataList = dataList;
    //if(statusList != undefined) m_statusList = statusList;

    let m_ivs = null;
    let m_ivsBuf = null;
    let m_ivsStatus = VTX_STATIC_DRAW;
    let m_total = 0;
    //
    this.initialize = function(type,dataList,statusList,layoutList)
    {
        m_type = type;
        if(dataList != undefined) m_dataList = dataList;
        if(statusList != undefined) m_statusList = statusList;
        let mt = type - VTXLAYOUT_AUTO;
        let k = VTXLAYOUT_AUTO;
        let v = 0;
        if(dataList == null)
        {
            m_dataList = [];
            m_statusList = [];
            m_layoutList = [];
            m_updateList = [];
            //var str = "";
            for(;mt>0;)
            {
                //m_bufs.push(null);
                m_dataList.push(null);
                m_statusList.push(VTX_STATIC_DRAW);
                k /= 10;
                v = Math.floor(mt / k);
                mt = mt - v * k;
                //
                //str += v;
                m_layoutList.push(v);
                m_updateList.push(false);
                m_total ++;
            }
            //trace(str);
        }
        else
        {
            m_total = dataList.length;
            m_updateList = [];
            for(v = 0; v < m_total; ++v)
            {
                m_updateList.push(false);
            }
            //
            if(layoutList != undefined)
            {
                m_layoutList = layoutList;
            }
            else
            {
                m_layoutList = [];
                for(;mt>0;)
                {
                    k /= 10;
                    v = Math.floor(mt / k);
                    mt = mt - v * k;
                    m_layoutList.push(v);
                }
            }
        }
    }
    this.getType = function(){ return m_type};
    this.getLayoutList = function(){ return m_layoutList};
    //
    this.setFloat32DataAt = function(i,float32Arr,status)
    {
        m_dataList[i] = float32Arr;
        if(status == undefined) m_statusList[i] = VTX_STATIC_DRAW;
        else m_statusList[i] = status;
    }
    this.updateFloat32DataAt = function(i,float32Arr)
    {
        if(this.dynamicUpdateEnabled)
        {
            i = 0;
            m_updateList[i] = true;
            if(float32Arr != undefined)m_dataList[i] = float32Arr;
        }
    }
    this.setUint16IVSData = function(uint16Arr,status)
    {
        m_ivs = uint16Arr;
        if(status == undefined) m_ivsStatus = VTX_STATIC_DRAW;
        else m_ivsStatus = status;
    }
    this.getDrawMode = function(gl,st)
    {
        switch(st)
        {
            case VTX_STATIC_DRAW:
            return gl.STATIC_DRAW;
            break;
            case VTX_DYNAMIC_DRAW:
            return gl.DYNAMIC_DRAW;
            break;
        }
        return gl.STATIC_DRAW;
    }
    this.isEnabled = function(){return m_gl != null;};
    let m_gl = null;
    this.__upload = function(gl)
    {
    }
    this.upload = function(gl)
    {
        if(m_gl == null)
        {
            this.__upload(gl);
            //
            m_gl = gl;
            let i = 0;
            let buf = null;
            for(; i < m_total; ++i)
            {
                buf = gl.createBuffer();
                gl.bindBuffer(gl.ARRAY_BUFFER, buf);
                gl.bufferData
                (
                    gl.ARRAY_BUFFER,
                    m_dataList[i],
                    this.getDrawMode(gl,m_statusList[i])
                );
                m_bufs.push(buf);
                if(i == 0)
                {
                    
                }
            }
            if(m_ivs != null)
            {
                m_ivsBuf = gl.createBuffer();
                gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m_ivsBuf);
                gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, m_ivs, this.getDrawMode(gl,m_ivsStatus));
            }
            //
        }
        // ready to cmds list
        this.use = function(shdp)
        {
            let i = 0;
            let buf = m_bufs[i];
            m_gl.bindBuffer(m_gl.ARRAY_BUFFER, buf);
            m_gl.vertexAttribPointer(shdp.getAttriLocationFirst(),m_layoutList[0],m_gl.FLOAT,false,0,0);
            // wait next...
            
            if(this.dynamicUpdateEnabled)
            {
                if(m_statusList[i] == VTX_DYNAMIC_DRAW && m_updateList[i])
                {
                    m_updateList[i] = false;
                    // upload sub data to GPU
                    m_gl.bufferSubData(m_gl.ARRAY_BUFFER, 0, m_dataList[i]);
                }
            }
            //
            for(let i = 1; i < m_total; ++i)
            {
                buf = m_bufs[i];
                m_gl.bindBuffer(m_gl.ARRAY_BUFFER, buf);
                m_gl.vertexAttribPointer(shdp.getAttriLocationNext(),m_layoutList[i],m_gl.FLOAT,false,0,0);
            }
        }
    }
    this.draw = function() 
    {
        m_gl.bindBuffer(m_gl.ELEMENT_ARRAY_BUFFER, m_ivsBuf);
        m_gl.drawElements(m_gl.TRIANGLES, m_ivs.length, m_gl.UNSIGNED_SHORT,0);
        //trace("VtxBufBlock::draw().");
    }
    this.destroy = function()
    {

    }
}
function VtxLineBufBlock()
{
    VtxBufBlock.call(this);
    //
    this.vtxTotal = 0;
    var v_gl = null;
    this.__upload = function(gl)
    {
        v_gl = gl;
    }
    this.draw = function() 
    {
        //v_gl.bindBuffer(m_gl.ELEMENT_ARRAY_BUFFER, m_ivsBuf);
        //v_gl.drawElements(m_gl.TRIANGLES, m_ivs.length, m_gl.UNSIGNED_SHORT,0);        
        //v_gl.drawArrays(v_gl.LINE_STRIP, 0, this.vtxTotal);
        //v_gl.drawArrays(gl.POINTS, 0, m_vtxTotal);
        v_gl.drawArrays(v_gl.LINES, 0, this.vtxTotal);
    }
}
VtxLineBufBlock.prototype = Object.create(VtxBufBlock.prototype);
VtxLineBufBlock.prototype.constructor = VtxLineBufBlock;
function VtxLineStripBufBlock()
{
    VtxBufBlock.call(this);
    //
    this.vtxTotal = 0;
    var v_gl = null;
    this.__upload = function(gl)
    {
        v_gl = gl;
    }
    this.draw = function() 
    {     
        v_gl.drawArrays(v_gl.LINE_STRIP, 0, this.vtxTotal);
    }
}
VtxLineStripBufBlock.prototype = Object.create(VtxBufBlock.prototype);
VtxLineStripBufBlock.prototype.constructor = VtxLineStripBufBlock;
function VtxPointsBufBlock()
{
    VtxBufBlock.call(this);
    //
    this.vtxTotal = 0;
    var v_gl = null;
    this.__upload = function(gl)
    {
        v_gl = gl;
    }
    this.draw = function() 
    {     
        v_gl.drawArrays(v_gl.POINTS, 0, this.vtxTotal);
    }
}
VtxPointsBufBlock.prototype = Object.create(VtxBufBlock.prototype);
VtxPointsBufBlock.prototype.constructor = VtxPointsBufBlock;
//
VtxBufBlock.__dataList = null;
VtxBufBlock.__dataStatusList = null;
VtxBufBlock.__dataStepList = null;
VtxBufBlock.Reset = function()
{
    VtxBufBlock.__dataList = [];
    VtxBufBlock.__dataStatusList = [];
    VtxBufBlock.__dataStepList = [];
}
VtxBufBlock.AddFloat32Data = function(float32Arr,step,status)
{
    VtxBufBlock.__dataList.push(float32Arr);
    VtxBufBlock.__dataStepList.push(step);
    if(status == undefined) VtxBufBlock.__dataStatusList.push(VTX_STATIC_DRAW);
    else VtxBufBlock.__dataStatusList.push(status);
}
VtxBufBlock.CreateBySaveData = function(vtxType)
{
    //if(vtxType == undefined) vtxType = VTX_GL_TRIANGLES;
    //
    let i = 0;
    let len = VtxBufBlock.__dataStepList.length;
    let k = 1;
    let t = 0;
    //VTXLAYOUT_AUTO
    //trace("len: ",len);
    for(; i < len; i++)
    {
        t += VtxBufBlock.__dataStepList[len - i - 1] * k;
        k *= 10;
    }
    k = 10;
    for(; i < 8; i++)
    {
        t *= k;
    }
    t += VTXLAYOUT_AUTO;
    //const VTXLAYOUT_3_2 = 132000;
    //trace(">>>>>>>>>>st: "+t);
    //trace(">>>>>>>>>>dt: "+VTXLAYOUT_3_2);
    return VtxBufBlock.Create(t,VtxBufBlock.__dataList, VtxBufBlock.__dataStatusList, VtxBufBlock.__dataStepList, vtxType);
}
VtxBufBlock.Create = function(type,dataList,statusList,stepList,vtxType)
{
    if(vtxType == undefined) vtxType = VTXTYPE_GL_TRIANGLES;
    //let m_layoutList = null;
    switch(type)
    {
        case VTXLAYOUT_2:
        case VTXLAYOUT_2_2:
        case VTXLAYOUT_3:
        case VTXLAYOUT_3_2:
        case VTXLAYOUT_3_2_2:
        case VTXLAYOUT_3_2_3:
        case VTXLAYOUT_3_3:
        case VTXLAYOUT_3_3_3:
        case VTXLAYOUT_3_4:
        case VTXLAYOUT_3_3_4:
        case VTXLAYOUT_4:
        case VTXLAYOUT_4_3_3_2:
        case VTXLAYOUT_4_4:
        case VTXLAYOUT_4_4_4_4:
        case VTXLAYOUT_4_4_4_4_2:
        case VTXLAYOUT_4_4_4_4_4:
        break;
        default:
            throwSysError("Error VtxBufBlock's bufs type("+type+")!");
            abort();
            break;
    }
    
    let block = null;
    switch(vtxType)
    {
        case  VTXTYPE_GL_LINES:
        block = new VtxLineBufBlock();
        break;
        case  VTXTYPE_GL_LINE_STRIP:
        block = new VtxLineStripBufBlock();
        break;
        case  VTXTYPE_GL_POINTS:
        block = new VtxPointsBufBlock();
        break;
        default:
        block = new VtxBufBlock();
        break;
        //default:
        //    throwSysError("Error VtxBufBlock type!");
        //    abort();
        //    break;
    }
    //
    block.initialize(type,dataList,statusList,stepList);
    return block;
}

function ___Vertex()
{
    // pos
    this.x = 0;
    this.y = 0;
    this.z = 0;
    // uv
    this.u = 0.0;
    this.v = 1.0;
    // normal
    this.nx = 0.00;
    this.ny = 0.00;
    this.nz = 0.00;
    //
    this.index = 0;
    //
    this.cloneVertex = function()
    {
        let vtx = new ___Vertex();
        vtx.x = this.x; vtx.y = this.y; vtx.z = this.z;
        vtx.nx = this.nx; vtx.ny = this.ny; vtx.nz = this.nz;
        vtx.u = this.u; vtx.v = this.v;
        vtx.index = this.index;
        return vtx;
    }
    this.copyFrom = function(pv)
    {
        this.x = pv.x; this.y = pv.y; this.z = pv.z;
        this.u = pv.u; this.v = pv.v;
        this.nx = pv.nx; this.ny = pv.ny; this.nz = pv.nz;
        this.index = pv.index;
    }
}

function Color(pr,pg,pb,pa)
{
    if(pr == undefined)this.r = 1.0;
    else this.r = pr;
    if(pg == undefined)this.g = 1.0;
    else this.g = pg;
    if(pb == undefined)this.b = 1.0;
    else this.b = pb;
    if(pa == undefined)this.a = 1.0;
    else this.a = pa;
    //
    this.changed = true;
    // for uniform
    this.dataArray = null;
    //
    this.setRGB3fTo = function(r,g,b)
    {
        this.r = r;
        this.g = g;
        this.b = b;
        //
        if(this.dataArray != null)
        {
            this.dataArray[0] = this.r;
            this.dataArray[1] = this.g;
            this.dataArray[2] = this.b;
        }
    };
    this.setRGBAfToArray = function()
    {
        if(this.dataArray == null) this.dataArray = [];
        this.dataArray[0] = this.r;
        this.dataArray[1] = this.g;
        this.dataArray[2] = this.b;
        this.dataArray[3] = this.a;
    }
    this.setRGBfToArray = function()
    {
        if(this.dataArray == null) this.dataArray = [];
        this.dataArray[0] = this.r;
        this.dataArray[1] = this.g;
        this.dataArray[2] = this.b;
    }
    this.setRGBUint24To = function(rgbUint24)
    {
        this.r = ((rgbUint24 >> 16) & 0x0000ff)/255.0;
        this.g = ((rgbUint24 >> 8) & 0x0000ff)/255.0;
        this.b = (rgbUint24 & 0x0000ff)/255.0;        
        //
        if(this.dataArray != null)
        {
            this.dataArray[0] = this.r;
            this.dataArray[1] = this.g;
            this.dataArray[2] = this.b;
        }
    };
    this.setRGBUint24To = function(rgbUint24)
    {
        this.r = ((rgbUint24 >> 16) & 0x0000ff)/255.0;
        this.g = ((rgbUint24 >> 8) & 0x0000ff)/255.0;
        this.b = (rgbUint24 & 0x0000ff)/255.0;        
        //
        if(this.dataArray != null)
        {
            this.dataArray[0] = this.r;
            this.dataArray[1] = this.g;
            this.dataArray[2] = this.b;
        }
    };
    //this.getRGBUint24 = function()
    //{
    //    var pr = Math.round(this.r*255.0);
    //    var pg = Math.round(this.g*255.0);
    //    var pb = Math.round(this.b*255.0);
    //    pr = pr << 16;
    //    pg = pg << 8;
    //    var pc = pr + pg + pb;
    //    return pc;
    //}
    this.setRGBA4fTo = function(r,g,b,a)
    {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
        //
        if(this.dataArray != null)
        {
            this.dataArray[0] = this.r;
            this.dataArray[1] = this.g;
            this.dataArray[2] = this.b;
            this.dataArray[3] = this.a;
        }
    };
    this.copyFrom = function(c)
    {
        this.r = c.r;
        this.g = c.g;
        this.b = c.b;
        this.a = c.a;
        if(this.dataArray != null)
        {
            this.dataArray[0] = this.r;
            this.dataArray[1] = this.g;
            this.dataArray[2] = this.b;
            this.dataArray[3] = this.a;
        }
    };
    this.scaleBy = function(s)
    {
        this.r *= s;
        this.g *= s;
        this.b *= s;
        if(this.dataArray != null)
        {
            this.dataArray[0] = this.r;
            this.dataArray[1] = this.g;
            this.dataArray[2] = this.b;
        }
    }
    this.randomRGB = function(density)
    {
        if(density == undefined) density = 1.0;
        this.r = Math.random() * density;
        this.g = Math.random() * density;
        this.b = Math.random() * density;
        if(this.dataArray != null)
        {
            this.dataArray[0] = this.r;
            this.dataArray[1] = this.g;
            this.dataArray[2] = this.b;
        }
    };
    this.toString = function()
    {
        return "[Color(r="+this.r+", g="+this.g+",b="+this.b+",a="+this.a+")]";
    };
};

function MeshBase()
{
    this.bounds = new AABB();
    // very important!!!
    this.vbuf = null;
    //this.initialize = function() 
    //{
    //    
    //};
    this.destroy = function()
    {
        if(this.vbuf != null)
        {
            // do something
            // ...
            //
            this.vbuf = null;
        }
    };
};

// -------------------------------------------------------------------------------
// -------------------------------------------------------------------------------
function RectPlaneMesh()
{
    MeshBase.call( this );
    this.vtxUVEnabled = false;
    this.vtxColorEnabled = false;
    this.vtxNormalEnabled = false;

    //var m_uploadBufBoo = true;
    this.uScale = 1.0;
    this.vScale = 1.0;
    //
    let m_vtxTotal = 0;
    //
    this.flipVerticalUV = false;
    //
    //this.vbuf = null;
    //
    this.initialize = function(startX,startY,pwidth,pheight) 
    {
        let m_vs = null;
        let m_uvs = null;
        let m_nvs = null;
        let m_ivs = null;
        //console.log("RectPlaneMesh::initialize()...");
        VtxBufBlock.Reset();
        let minX = startX;
        let minY = startY;
        let maxX = startX + pwidth;
        let maxY = startY + pheight;
        let pz = 0.0;

        // ccw is positive, left-bottom pos(minX,minY) -> right-bottom pos(maxX,minY) -> right-top pos(maxX,maxY)  -> right-top pos(minX,maxY)
        m_ivs = new Uint16Array([0,1,2,0,2,3])
        m_vs = [
            minX,minY,pz,
            maxX,minY,pz,
            maxX,maxY,pz,
            minX,maxY,pz,
        ];
        VtxBufBlock.AddFloat32Data(new Float32Array(m_vs),3);
        //trace("RectPlaneMesh::initialize(), m_vs: ",m_vs);
        if(this.vtxUVEnabled)
        {
            if(this.flipVerticalUV)
            {
                m_uvs = [
                    0.0 * this.uScale,0.0 * this.vScale,
                    1.0 * this.uScale,0.0 * this.vScale,
                    1.0 * this.uScale,1.0 * this.vScale,
                    0.0 * this.uScale,1.0 * this.vScale
                ];
            }
            else
            {
                m_uvs = [
                    0.0 * this.uScale,1.0 * this.vScale,
                    1.0 * this.uScale,1.0 * this.vScale,
                    1.0 * this.uScale,0.0 * this.vScale,
                    0.0 * this.uScale,0.0 * this.vScale
                ];

            }
            VtxBufBlock.AddFloat32Data(new Float32Array(m_uvs),2);
        }
        if(this.vtxNormalEnabled)
        {
            m_nvs = [
                0,0.0,1.0,
                0,0.0,1.0,
                0,0.0,1.0,
                0,0.0,1.0,
            ];
            VtxBufBlock.AddFloat32Data(new Float32Array(m_nvs),3);
        }
        //VTXLAYOUT_3_2
        m_vtxTotal = 6;
        this.vbuf = VtxBufBlock.CreateBySaveData();
        this.vbuf.setUint16IVSData(m_ivs);
    };
    this.initializeXOZ = function(startX,startZ,pwidth,plong) 
    {
        let m_vs = null;
        let m_uvs = null;
        let m_nvs = null;
        let m_ivs = null;
        VtxBufBlock.Reset();
        //console.log("RectPlaneMesh::initialize()...");
        let minX = startX;
        let minZ = startZ;
        let maxX = startX + pwidth;
        let maxZ = startZ + plong;
        let py = 0.0;

        // ccw is positive, left-bottom pos(minX,minY) -> right-bottom pos(maxX,minY) -> right-top pos(maxX,maxY)  -> right-top pos(minX,maxY)
        m_ivs = new Uint16Array([0,1,2,0,2,3])
        m_vs = [
            maxX,py,minZ,
            minX,py,minZ,
            minX,py,maxZ,
            maxX,py,maxZ,
        ];
        VtxBufBlock.AddFloat32Data(new Float32Array(m_vs),3);
        //
        //trace("RectPlaneMesh::initialize(), m_vs: ",m_vs);
        if(this.vtxUVEnabled)
        {
            if(this.flipVerticalUV)
            {
                m_uvs = [
                    0.0,0.0,
                    1.0,0.0,
                    1.0,1.0,
                    0.0,1.0,
                ];

            }
            else
            {
                m_uvs = [
                    0.0,1.0,
                    1.0,1.0,
                    1.0,0.0,
                    0.0,0.0,
                ];

            }
            VtxBufBlock.AddFloat32Data(new Float32Array(m_uvs),2);
        }
        
        if(this.vtxNormalEnabled)
        {
            m_nvs = [
                0,1.0,0,
                0,1.0,0,
                0,1.0,0,
                0,1.0,0,
            ];
            
            VtxBufBlock.AddFloat32Data(new Float32Array(m_nvs),3);
        }
        m_vtxTotal = 6;
        this.vbuf = VtxBufBlock.CreateBySaveData();
        this.vbuf.setUint16IVSData(m_ivs);
    };
    
    this.destroy = function()
    {
        if(this.vbuf != null)
        {
            this.vbuf = null;
        }
    };
};
RectPlaneMesh.prototype = Object.create(MeshBase.prototype);
RectPlaneMesh.prototype.constructor = RectPlaneMesh;
/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/
function ___GLSLConverter()
{
    this.es2VtxShderToES3 = function(glslStr)
    {
        let codeStr = glslStr;
        //attribute
        const ATTRIBUTE = "attribute";
        //const POSY_OUTPUT = "out";
        //const POSY_INPUT = "in";
        const VARYING = "varying ";
        let i = codeStr.indexOf(ATTRIBUTE);
        let j = 0;
        while( i>=0 )
        {
            codeStr = codeStr.slice(0,i) + "layout(location="+j+") in"+codeStr.slice(i+9);
            i = codeStr.indexOf(ATTRIBUTE);
            j++;
        }
        let regex = new RegExp(VARYING, "g");
		codeStr = codeStr.replace(regex, "out ");
        //i = codeStr.indexOf(ATTRIBUTE);
        return "#version 300 es\n"+codeStr;
    }
    this.es2FragShderToES3 = function(glslStr)
    {
        let codeStr = glslStr;
        //attribute
        const GL1_OUTPUT = "gl_FragColor";
        const VARYING = "varying ";
        let i = codeStr.indexOf(GL1_OUTPUT);
        let j = 0;
        let outFragColor = "FragColorOut_"+j;
        if(i>=0)codeStr = codeStr.slice(0,i) + outFragColor+codeStr.slice(i+12);

        i = codeStr.indexOf("void ");
        codeStr = codeStr.slice(0,i) + "out vec4 "+outFragColor+";\n"+codeStr.slice(i);
        //let j = 0;
        //while( i>=0 )
        //{
        //    codeStr = codeStr.slice(0,i) + "layout(location="+j+") in"+codeStr.slice(i+9);
        //    i = codeStr.indexOf(ATTRIBUTE);
        //    j++;
        //}
        
        let regex = new RegExp(VARYING, "g");
		codeStr = codeStr.replace(regex, "in ");
        regex = new RegExp(" texture2D", "g");
        codeStr = codeStr.replace(regex, " texture");
        regex = new RegExp(" textureCube", "g");
        codeStr = codeStr.replace(regex, " texture");
        return "#version 300 es\n"+codeStr;
    }
}
let GLSLConverter = new ___GLSLConverter();
//
// 对于每一个指定的 shader, 那么它的 vtx 输入的格式也是指定的, 因此着色器中的vtx块就可以和mesh中的 vtx bufs块配型
//
function ShaderProgram(unique_ns,vshdsrc,fshdSrc)
{
    let m_gl = null;
    let m_texTotal = 0;
    // find textures total
    let p = fshdSrc.indexOf( " sampler2D " );
    for(; p >= 0;)
    {
        m_texTotal ++;
        p = fshdSrc.indexOf( " sampler2D ", p+1 );
    }
    //
    p = fshdSrc.indexOf( " samplerCube " );
    for(; p >= 0;)
    {
        m_texTotal ++;
        p = fshdSrc.indexOf( " samplerCube ", p+1 );
    }
    // identify use texture
    let m_useTex = m_texTotal > 0;
    // web gl 1.0, attributes
    this.attriNSList = null;
    // m_uniform name list
    this.uniformNameList = null;
    //
    var m_aLocations = null;
    var m_uLocations = null;
    var m_texLocations = [null,null,null,null, null,null,null,null];
    //
    this.useTexLocation = function() 
    {
        for(let i = 0; i < m_texTotal; ++i)
        {
            if(m_texLocations[i] != null)
            {
                m_gl.uniform1i(m_texLocations[i], i);
            }else
            {
                m_texLocations[i] = m_gl.getUniformLocation(m_program, SHDER_UNIFORM_TEX_SAMPLE_LIST[ i ]);
                m_gl.uniform1i(m_texLocations[i], i);
            }
        }
    }
    // use texture true or false
    this.haveTexture = function()
    {
        return m_useTex;
    }
    this.createLocations = function()
    {
        let i = 0;
        let len = 0;
        if(this.attriNSList != null)
        {
            if(m_aLocations == null)
            {
                m_aLocations = [];
                len = this.attriNSList.length;
                for(; i < len; ++i)
                {
                    m_aLocations.push( m_gl.getAttribLocation(m_program, this.attriNSList[i]) );
                }
                trace("ShaderProgram::createLocations(), m_aLocations: ",m_aLocations);
                trace("ShaderProgram::createLocations(), attriNSList: ",this.attriNSList);
            }
        }
        if(this.uniformNameList != null)
        {
            if(m_uLocations == null)
            {
                m_uLocations = [];
                len = this.uniformNameList.length;
                let ul = null;
                for(i = 0; i < len; ++i)
                {
                    ul = m_gl.getUniformLocation(m_program, this.uniformNameList[i]);
                    trace("ShaderProgram::createLocations(), ul ",ul,", this.uniformNameList["+i+"]: "+this.uniformNameList[i]);
                    if(ul != null)
                    {
                        m_uLocations.push(ul);
                    }
                    else
                    {
                        trace("uniform ",this.uniformNameList[i]," no used!");
                    }
                }
                //trace("m_uLocations.length: ",m_uLocations.length);
                //trace("uniformNameList.length: ",this.uniformNameList.length);
                //trace("m_uLocations: ",m_uLocations);
                //trace("uniformNameList: ",this.uniformNameList);
            }
        }
    }
    let m_attrid = 0;
    let m_attridIndex = 0;
    this.getAttriLocationAt = function(i)
    {
        m_attridIndex = i;
        m_attrid = m_aLocations[i];
        m_gl.enableVertexAttribArray( m_attrid );
        return m_attrid;
    }
    this.getAttriLocationNext = function()
    {
        m_attrid = m_aLocations[m_attridIndex];
        m_gl.enableVertexAttribArray( m_attrid );
        m_attridIndex ++;
        return m_attrid;
    }
    this.getAttriLocationFirst = function()
    {
        m_attridIndex = 1;
        m_attrid = m_aLocations[0];
        m_gl.enableVertexAttribArray( m_attrid );
        return m_attrid;
    }
    //
    let m_uLc = null;
    let m_uIndex = 0;
    this.getUniformLocationAt = function(i)
    {
        m_uIndex = i+1;
        return m_uLocations[i];
    }
    this.getUniformLocationNext = function()
    {
        m_uLc = m_uLocations[m_uIndex++];
        //m_uIndex ++;
        return m_uLc;
    }
    this.getUniformLocationFirst = function()
    {
        m_uIndex = 1;
        return m_uLocations[0];
    }
    //

    //// 是否重新 create location identifier and upload data
    //this.lctcBoo = true;
    this.name = "ShaderProgram";
    //
    var m_vshdSrc = vshdsrc;
    var m_fshdSrc = fshdSrc;
    var m_shdUniqueName = unique_ns;
    //
    var m_program = null;
    //
    function initShaderProgram( vshd_str, fshd_str) {

        var vtxShd = loadShader(m_gl.VERTEX_SHADER, vshd_str);
        var frgShd = loadShader(m_gl.FRAGMENT_SHADER, fshd_str);
        // Create the shader program      
        var shdProgram = m_gl.createProgram();
        m_gl.attachShader(shdProgram, vtxShd);
        m_gl.attachShader(shdProgram, frgShd);
        m_gl.linkProgram(shdProgram);      
        // If creating the shader program failed, alert
        if (!m_gl.getProgramParameter(shdProgram, m_gl.LINK_STATUS))
        {
            alert('Unable to initialize the shader program: ' + m_gl.getProgramInfoLog(shdProgram));
            return null;
        }
        return shdProgram;
    };
    //
    function loadShader(type, source)
    {
        var shader = m_gl.createShader(type);      
        // Send the source to the shader object      
        m_gl.shaderSource(shader, source);      
        // Compile the shader program      
        m_gl.compileShader(shader);      
        // See if it compiled successfully      
        if (!m_gl.getShaderParameter(shader, m_gl.COMPILE_STATUS))
        {
            alert('An error occurred compiling the shaders: ' + m_gl.getShaderInfoLog(shader));
            m_gl.deleteShader(shader);
            return null;
        }
      
        return shader;
    };

    this.getUniqueShaderName = function() 
    {
        return m_shdUniqueName;
    };
    this.enabled = function() 
    {
        return m_program != null;
    };
    this.upload = function(gl) 
    {
        if(m_program == null)
        {
            m_gl = gl;
            m_program = initShaderProgram(m_vshdSrc,m_fshdSrc);
            if(null != m_program) this.createLocations();            
            //trace("ShaderProgram::upload(), this.name: "+this.name);
        }
    };
    this.getProgram = function() 
    {
        return m_program;
    };
    this.destroy = function() 
    {
        m_aLocations = null;
        //
        m_texLocations[0] = null;
        m_texLocations[1] = null;
        m_texLocations[2] = null;
        m_texLocations[3] = null;
        m_texLocations[4] = null;
        m_texLocations[5] = null;
        m_texLocations[6] = null;
        m_texLocations[7] = null;

        if(m_program != null)
        {
            gl.deleteProgram(m_programID);
            m_program = null;
        }
        m_gl = null;
    };
};
let ___voxShadersDict = new Map();
ShaderProgram.Create = function(unique_name_str,vshdsrc,fshdSrc)
{
    //console.log("ShaderProgram.Create() begin...");
    if(unique_name_str ==undefined)
    {
        return null;
    }
    if((typeof unique_name_str) == "string")
    {
        if(___voxShadersDict.has(unique_name_str)){return ___voxShadersDict.get(unique_name_str);}
        var p = new ShaderProgram(unique_name_str, vshdsrc,fshdSrc);
        p.name = unique_name_str;
        //___voxShadersDict[unique_name_str] = p;
        ___voxShadersDict.set(unique_name_str,p);
        console.log("ShaderProgram.Create() a new ShaderProgram: ",p);
        return p;
    }
    //console.log("ShaderProgram.Create() end...");
    return null;
}
ShaderProgram.Find = function(unique_name_str)
{
    if(___voxShadersDict.has(unique_name_str)){return ___voxShadersDict.get(unique_name_str);}
    return null;
}
ShaderProgram.Reset = function(type)
{
    //function proReset(v,k,m)
    //{
    //    v.lctcBoo = true;
    //    //trace("ShaderProgram.Reset: "+v.name);
    //}
    //___voxShadersDict.forEach(proReset);
}
function ShaderUniform()
{
    this.slotIndex = 0;
    this.slotSize = 0;
    this.types = null;
    this.locationIndexList = null;
    this.locations = null;
    this.dataSizeList = null;
    //
    this.always = false;
    this.rst = 0;
    // for mult uniform data src, for example: camera, lightGroup
    this.next = null;
    //
    this.copyDataFromProbe = function(probe)
    {
        //this.locationIndexList = [];
        this.types = [];
        this.dataSizeList = [];
        this.slotIndex = probe.uniformSlotIndex;
        this.slotSize = probe.uniformSlotSize;

        for(let i = 0; i < probe.uniformSlotSize; ++i)
        {
            this.types.push( probe.uniformTypes[i] );
            this.dataSizeList.push( probe.dataSizeList[i] );
        }
    }
    this.use = function(gl)
    {
        if(this.always || this.rst != GlobalUniformSlot.flagList[this.slotIndex])
        {
            this.rst = GlobalUniformSlot.flagList[this.slotIndex];
            let i = 0;
            if(isWebGL1())
            {
                for(; i < this.slotSize; ++i)
                {
                    switch(this.types[i])
                    {
                        case SHADER_MAT4:
                        gl.uniformMatrix4fv(this.locations[i], false, GlobalUniformSlot.dataList[this.slotIndex + i]);
                        break;
                        case SHADER_MAT3:
                        gl.uniformMatrix3fv(this.locations[i], false, GlobalUniformSlot.dataList[this.slotIndex + i]);
                        break;
                        case SHADER_VEC4FV:
                        gl.uniform4fv(this.locations[i], GlobalUniformSlot.dataList[this.slotIndex + i], this.dataSizeList[i]);
                        break;
                        case SHADER_VEC3FV:
                        //trace("this.dataSizeList["+i+"]: "+this.dataSizeList[i]);
                        gl.uniform3fv(this.locations[i], GlobalUniformSlot.dataList[this.slotIndex + i], this.dataSizeList[i]);
                        break;
                        case SHADER_VEC4:
                        let arr4 = GlobalUniformSlot.dataList[this.slotIndex + i];
		        		gl.uniform4f(this.locations[i], arr4[0], arr4[1], arr4[2], arr4[3]);
                        break;
                        case SHADER_VEC3:
                        let arr3 = GlobalUniformSlot.dataList[this.slotIndex + i];
		        		gl.uniform3f(this.locations[i], arr3[0], arr3[1], arr3[2]);
                        break;
                        case SHADER_VEC2:
                        let arr2 = GlobalUniformSlot.dataList[this.slotIndex + i];
		        		gl.uniform2f(this.locations[i], arr2[0], arr2[1]);
                        break;
                    }
                }
            }
            else
            {
                for(; i < this.slotSize; ++i)
                {
                    switch(this.types[i])
                    {
                        case SHADER_MAT4:
                        gl.uniformMatrix4fv(this.locations[i], false, GlobalUniformSlot.dataList[this.slotIndex + i]);
                        break;
                        case SHADER_MAT3:
                        gl.uniformMatrix3fv(this.locations[i], false, GlobalUniformSlot.dataList[this.slotIndex + i]);
                        break;
                        case SHADER_VEC4FV:
                        gl.uniform4fv(this.locations[i], GlobalUniformSlot.dataList[this.slotIndex + i], 0, this.dataSizeList[i] * 3);
                        break;
                        case SHADER_VEC3FV:
                        //trace("this.dataSizeList["+i+"]: "+this.dataSizeList[i]);
                        //trace("GlobalUniformSlot.dataList["+this.slotIndex + i+"]:"+GlobalUniformSlot.dataList[this.slotIndex + i] + ", vec3 tot:"+(GlobalUniformSlot.dataList[this.slotIndex + i].length/3));
                        gl.uniform3fv(this.locations[i], GlobalUniformSlot.dataList[this.slotIndex + i], 0, this.dataSizeList[i] * 3);
                        break;
                        case SHADER_VEC4:
                        let arr4 = GlobalUniformSlot.dataList[this.slotIndex + i];
                        //trace("ShaderUniform::, arr4: "+arr4);
		        		gl.uniform4f(this.locations[i], arr4[0], arr4[1], arr4[2], arr4[3]);
                        break;
                        case SHADER_VEC3:
                        let arr3 = GlobalUniformSlot.dataList[this.slotIndex + i];
		        		gl.uniform3f(this.locations[i], arr3[0], arr3[1], arr3[2]);
                        break;
                        case SHADER_VEC2:
                        let arr2 = GlobalUniformSlot.dataList[this.slotIndex + i];
		        		gl.uniform2f(this.locations[i], arr2[0], arr2[1]);
                        break;
                    }
                }
            }
            
        }
        //trace("use shared uniform...");
    }
    //
    this.destroy = function()
    {
        this.types =  null;
        this.dataSizeList = null;
        this.slotIndex = -1;
        this.slotSize = 0;
    }
}
function ShaderObjectUniform()
{
    this.types = null;
    this.uniformSize = 0;
    this.locations = null;
    this.dataSizeList = null;
    this.dataList = null;
    //
    this.use = function(gl)
    {
        let i = 0;
        if(isWebGL1())
        {
            for(; i < this.uniformSize; ++i)
            {
                switch(this.types[i])
                {
                    case SHADER_MAT4:
                    gl.uniformMatrix4fv(this.locations[i], false, this.dataList[i]);
                    break;
                    case SHADER_MAT3:
                    gl.uniformMatrix3fv(this.locations[i], false, this.dataList[i]);
                    break;
                    case SHADER_VEC4FV:
                    gl.uniform4fv(this.locations[i], this.dataList[i], this.dataSizeList[i]);
                    break;
                    case SHADER_VEC3FV:
                    gl.uniform3fv(this.locations[i], this.dataList[i], this.dataSizeList[i]);
                    break;
                    //this.dataSizeList
                    case SHADER_VEC4:
                    let arr4 = this.dataList[i];
		    		gl.uniform4f(this.locations[i], arr4[0], arr4[1], arr4[2], arr4[3]);
                    break;
                    case SHADER_VEC3:
                    let arr3 = this.dataList[i];
		    		gl.uniform3f(this.locations[i], arr3[0], arr3[1], arr3[2]);
                    break;
                    case SHADER_VEC2:
                    let arr2 = this.dataList[i];
		    		gl.uniform2f(this.locations[i], arr2[0], arr2[1]);
                    break;
                }
            }
        }
        else
        {
            for(; i < this.uniformSize; ++i)
            {
                switch(this.types[i])
                {
                    case SHADER_MAT4:
                    gl.uniformMatrix4fv(this.locations[i], false, this.dataList[i]);
                    break;
                    case SHADER_MAT3:
                    gl.uniformMatrix3fv(this.locations[i], false, this.dataList[i]);
                    break;
                    case SHADER_VEC4FV:
                    gl.uniform4fv(this.locations[i], this.dataList[i], 0, this.dataSizeList[i] * 4);
                    break;
                    case SHADER_VEC3FV:
                    gl.uniform3fv(this.locations[i], this.dataList[i], 0, this.dataSizeList[i] * 3);
                    break;
                    //this.dataSizeList
                    case SHADER_VEC4:
                    let arr4 = this.dataList[i];
                    //trace("SHADER_VEC4: "+i+",arr4: "+arr4);
		    		gl.uniform4f(this.locations[i], arr4[0], arr4[1], arr4[2], arr4[3]);
                    break;
                    case SHADER_VEC3:
                    let arr3 = this.dataList[i];
		    		gl.uniform3f(this.locations[i], arr3[0], arr3[1], arr3[2]);
                    break;
                    case SHADER_VEC2:
                    let arr2 = this.dataList[i];
		    		gl.uniform2f(this.locations[i], arr2[0], arr2[1]);
                    break;
                }
            }
        }
        this._update();
    }
    //  for subobject override
    this._update = function()
    {

    }
    //
    this.destroy = function()
    {
        let i = 0;
        let len = this.dataList.length;
        for(; i < len; ++i)
        {
            this.dataList[i] = null
        }
        this.dataList = null;
        this.types = null;
        this.locations = null;
        this.dataSizeList = null;
    }
}
// base Material example and usage
function MaterialBase()
{
    // use rgb normalize bias enabled
    this.rgbNormalizeEnabled = false;
    
    this.initializeByPosy = function(posyBox,shdParam) 
    {
        if(this.getShaderProgram() == null)
        {
            //this.posyBox.lightType = this.lightType;
            posyBox.buildIdns();
            var program = ShaderProgram.Find( posyBox.vshd_idns );
            if(null == program)
            {
                posyBox.build(shdParam);
                program = ShaderProgram.Create(
                    posyBox.vshd_idns
                    ,  posyBox.getVshdStr()
                    , posyBox.getFshdStr()
                );
                program.attriNSList = [];
                program.uniformNameList = [];
                //program.uniformNameList
                posyBox.getVtxAttributeNameList(program.attriNSList);
                //
                posyBox.getVtxUniformNameList( program.uniformNameList);
		        posyBox.getFragUniformNameList( program.uniformNameList);
            }
            this.setShaderProgram(program);
        }
    };
    this.initialize = function(shdCode,uniformNameList,attriNSList) 
    {
        if(this.getShaderProgram() == null)
        {
            var program = ShaderProgram.Find( shdCode.uniqueName );
            if(null == program)
            {
                program = ShaderProgram.Create(
                    shdCode.uniqueName
                    , shdCode.vshdCode
                    , shdCode.fshdCode
                );
                if(attriNSList != undefined || attriNSList != null)
                {
                    program.attriNSList = attriNSList;
                }
                if(uniformNameList != undefined || uniformNameList != null)
                {
                    program.uniformNameList = uniformNameList;
                }
            }
            this.setShaderProgram(program);

        }        
    };
    var m_spg = null;
    this.setShaderProgram = function(p){ m_spg = p;};
    this.getShaderProgram = function(){return m_spg;};    
    this.getProgram = function(){return m_spg.getProgram();};
    //
    var m_tex = null;
    this.setTextureProxy = function(p){m_tex = p;};
    this.getTextureProxy = function(){return m_tex;}
    //
    this.createSharedUniform = function(camera)
    {
        let cuniform = new ShaderUniform();
        cuniform.locationIndexList = [1,2];
        cuniform.locations = [this.getUniformLocationAt(1),this.getUniformLocationAt(2)];
        cuniform.copyDataFromProbe(camera.uProbe);
        return cuniform;
    }
    this.createSelfUniform = function(ro)
    {
        let oum = new ShaderObjectUniform();
        oum.types = [SHADER_MAT4];
        oum.uniformSize = 1;
        oum.locations = [this.getUniformLocationAt(0)];
        //oum.locations = [this.getShaderProgram().getUniformLocationAt(0)];
        oum.dataList = [ro.getMatrix()];
        return oum;
    }
    this.getUniformLocationAt = function(i)
    {
        return m_spg.getUniformLocationAt(i);
    }
    this.destroy = function()
    {
        m_spg = null;
        m_tex = null;
    };
};

MaterialBase.CreateShaderProgram = function(unique_name_str,vshdsrc,fshdSrc)
{
    return ShaderProgram.Create(unique_name_str,vshdsrc,fshdSrc);
};/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/

function DispObj3D()
{
    let m_obj_id = DISP_OBJ_ID++;
    this.getObjId = function(){return m_obj_id;};
    var m_matUpdateEnabled = true;
    ///////////////////////
    this.bounds = new AABB();
    // render yes or no
    this.visible = true;
    // 是否需要创建逆变化的矩阵
    this.invMatEnabled = true;
    // 这是非常重要的参数, 主系统会依据这个参数来做很多的重要操作    
    this.lightType = LightType.NO_LIGHT;
    //
    this.lightGroup = null;
    //
    this.initialize = function()
    {
        console.log("DispObj3D::initialize(),init...");
    };

    this.cullFaceMode = CullFaceMode.BACK;
	// blend mode
	this.blendMode = RenderBlendMode.NORMAL;
	// depth test type
	this.depthTestType = DepthTestType.RENDER_OPAQUE;
    // shadow status(receive | make | receive and make | none)
    this.shadowStatus = 0;
    // record render state: this.shadowStatus(one byte) + this.depthTestType(one byte) + this.blendMode(one byte) + this.cullFaceMode(one byte)
    this.renderState = 0;
    //
    var m_action = null;
    this.setAction = function(a)
    {
        if(a == undefined)return;
        if(m_action != null && a == m_action) m_action.bindTarget(null);m_action = null;
        if(a != null)
        {
            m_action = a;
            m_action.bindTarget(this);
        }
    }
    this.getAction = function()
    {
        return m_action;
    }
    //var m_x=0,m_y=0,m_z=0;
    var m_pos = new Vector3D();
    this.getX = function(){return m_pos.x;};
    this.getY = function(){return m_pos.y;};
    this.getZ = function(){return m_pos.z;};
    this.setX = function(p){m_pos.x = p;m_matUpdateEnabled = true;};
    this.setY = function(p){m_pos.y = p;m_matUpdateEnabled = true;};
    this.setZ = function(p){m_pos.z = p;m_matUpdateEnabled = true;};
    this.setXYZ = function(px,py,pz)
    {
        m_pos.x = px;
        m_pos.y = py;
        m_pos.z = pz;
        m_matUpdateEnabled = true;
    }
    this.setPosition = function(pv)
    {
        m_pos.x = pv.x;
        m_pos.y = pv.y;
        m_pos.z = pv.z;
        m_matUpdateEnabled = true;
    }

    var m_rx=0,m_ry=0,m_rz=0;
    this.getRotationX = function(){return m_rx;};
    this.getRotationY = function(){return m_ry;};
    this.getRotationZ = function(){return m_rz;};
    this.setRotationX = function(degrees){m_rx = degrees;m_matUpdateEnabled = true;};
    this.setRotationY = function(degrees){m_ry = degrees;m_matUpdateEnabled = true;};
    this.setRotationZ = function(degrees){m_rz = degrees;m_matUpdateEnabled = true;};
    this.setRotationXYZ = function(rx,ry,rz)
    {
        m_rx = rx;
        m_ry = ry;
        m_rz = rz;
        m_matUpdateEnabled = true;
    }

    var m_sx=1.0,m_sy=1.0,m_sz=1.0;
    this.getScaleX = function(){return m_sx;};
    this.getScaleY = function(){return m_sy;};
    this.getScaleZ = function(){return m_sz;};
    this.setScaleX = function(p){m_sx = p;m_matUpdateEnabled = true;};
    this.setScaleY = function(p){m_sy = p;m_matUpdateEnabled = true;};
    this.setScaleZ = function(p){m_sz = p;m_matUpdateEnabled = true;};
    this.setScaleXYZ = function(sx,sy,sz)
    {
        m_sx = sx;
        m_sy = sy;
        m_sz = sz;
        m_matUpdateEnabled = true;
    }
    this.setScale = function(s)
    {
        m_sx = s;
        m_sy = s;
        m_sz = s;
        m_matUpdateEnabled = true;
    }
    //
    // Object Matrix
    var m_omat = new Matrix3D();
    var m_itOmat = null;
    //var m_itOmat = new Matrix3D();
    var m_invOmat = new Matrix3D();
    var m_mesh = null;
    var m_material = null;
    //inverse transpose
    this.getITMatrix = function()
    {
        return m_itOmat;
    };
    this.getInvMatrix = function()
    {
        return m_invOmat;
    };
    this.getMatrix = function()
    {
        return m_omat;
    };
    this.getMesh = function()
    {
        return m_mesh;
    };
    this.setMesh = function(m)
    {
         m_mesh = m;
    };
    this.getMaterial = function()
    {
        return m_material;
    };
    this.setMaterial = function(m)
    {
        m_material = m;
    };
    this.renderVertices = function(gl,shdProgram)
    {
        if(m_mesh != null)
        {
            if(m_material != null)
            {
                m_mesh.upload(gl, shdProgram);
                m_mesh.useVertices(gl, m_material.getShaderProgram());
            }
        }
    };
    this.destroy = function()
    {
        m_omat = null;
        m_itOmat = null;
        m_invOmat = null;
        m_direcV = null;
        m_directV = null;
        m_direcM = null;
        //
        if(m_action != null)
        {
            m_action.destroy();
            m_action = null;
        }
    };
    //
    let m_dAng = 0.0;
    let m_tv3 = new Vector3D();
    let m_direcM = null;
    let m_direcV = null;
    let m_directV = null;
    let m_bv = new Vector3D(1.0,0.0,0.0);
    //let m_maxAng = 1000;
	/**
	 * 使显示对象朝向某个方向
	 * @param				directV		将要变化到的朝向的方向矢量(默认是物体原+x的朝向将被更改), directVb == null, direction was disabled
	 * @param				maxAng		本次向目标朝向变化的最大变化角度,如果当前转向所需的角度大于这个值，则使用maxAng的值
	 * 									此参数用于实现朝向变化的平滑差值
	 * @param				bv			初始朝向(默认是 Vector3D(1.0, 0.0, 0.0))
	 * */
    this.directTo = function(directV, bv, maxAng)
    {
        if(maxAng == undefined) maxAng = 1000;
        //
        if(directV != null)
        {
            m_directV = directV;
            if(bv != null) m_bv.copyFrom(bv);
            if (m_direcV == null) m_direcV = new Vector3D();
            m_direcV.setTo(m_bv.x, m_bv.y, m_bv.z);
            let ang = Vector3D.radianBetween(m_direcV, directV);
		    m_dAng = Math.abs(ang);
		    if (m_dAng > 0.01) {
		    	if (m_direcM != null) {
		    		m_direcM.identity();
		    	}else{
                    m_direcM = new Matrix3D();
                }
                Vector3D.cross(m_direcV, directV, m_tv3);
                m_tv3.normalize();
		    	if (m_dAng > maxAng) {
		    		if (ang * maxAng < 0) maxAng *= -1;
		    	}else {
		    		maxAng = ang;
		    	}
		    	m_direcM.appendRotation(maxAng, m_tv3);
                m_direcV.copyFrom(directV);
                m_matUpdateEnabled = true;
            }
        }
        else if(m_directV != null)
        {
            m_directV = null;
            m_bv.setTo(1.0,0.0,0.0);
            m_matUpdateEnabled = true;
        }
    }
    //
    this.update = function()
    {
        
        if(m_action != null) m_action.update();
        if (m_matUpdateEnabled)
		{
			m_omat.identity();
			m_omat.appendScaleXYZ(m_sx, m_sy, m_sz);
			
			//if (m_rotateX > 360.0) m_rotateX -= 360.0;
			//else if (m_rotateX < -360.0f) m_rotateX += 360.0;
			//if (m_rotateY > 360.0) m_rotateY -= 360.0;
			//else if (m_rotateY < -360.0f) m_rotateY += 360.0;
			//if (m_rotateZ > 360.0) m_rotateZ -= 360.0;
			//else if (m_rotateZ < -360.0) m_rotateZ += 360.0;
			//
            m_omat.appendRotationEulerAngle(m_rx * MATH_PI_OVER_180, m_ry * MATH_PI_OVER_180, m_rz * MATH_PI_OVER_180);
            if(m_directV != null)
            {
                if (m_direcM != null)
                {
                    m_omat.append(m_direcM);
                }
            }
			m_omat.appendTranslation(m_pos);
			m_matUpdateEnabled = false;
			// 有的物体只需要沿着y轴旋转即可 m_matrix.appendRotationY();
			// 有些物体不需要缩放
            // 所以这里的计算其实可以优化计算只需要的变换
            //copyFrom
            if(this.invMatEnabled)
            {
                m_invOmat.copyFrom(m_omat);
                m_invOmat.invert();
                //m_itOmat.transpose();
            }
            //
            //this.cullFaceMode = CullFaceMode.BACK;
	        //// blend mode
	        //this.blendMode = RenderBlendMode.NORMAL;
	        //// depth test type
	        //this.depthTestType = DepthTestType.RENDER_OPAQUE;
            //// shadow status(receive | make | receive and make | none)
            //this.shadowStatus = null;
            //// record render state: this.shadowStatus(one byte) + this.depthTestType(one byte) + this.blendMode(one byte) + this.cullFaceMode(one byte)
            //this.renderState = 0;
            //
            //trace("this.shadowStatus: "+this.shadowStatus +" <<12: "+(this.shadowStatus<<12));
            //trace("this.depthTestType: "+this.depthTestType +" <<8: "+(this.depthTestType<<8));
            //trace("this.blendMode: "+this.blendMode +" <<4: "+(this.blendMode<<4));
            //trace("this.cullFaceMode: "+this.cullFaceMode +" <<0: "+(this.cullFaceMode));
            
            this.renderState = this.shadowStatus << 12 | this.depthTestType << 8 | this.blendMode<<4 | this.cullFaceMode;

            //let pshadowStatus = this.renderState >> 12 & 0x0000000f;
            //let pdepthTestType = this.renderState >> 8 & 0x0000000f;
            //let pblendMode = this.renderState >> 4 & 0x0000000f;
            //let cullFaceMode = this.renderState & 0x0000000f;
            //trace("pshadowStatus: "+pshadowStatus);
            //trace("pdepthTestType: "+pdepthTestType);
            //trace("pblendMode: "+pblendMode);
            //trace("cullFaceMode: "+cullFaceMode);
            //
            //trace("this.renderState: "+this.renderState);
            this.bounds.moveXYZ(m_pos.x,m_pos.y,m_pos.z);
		}
    };
    //
    let m__rSign = -1
    // only render sys call !!!!
    this.setRenderSign = function(t)
    {
        m__rSign = t;
    }
    // only render sys call !!!
    this.getRenderSign = function()
    {
        return m__rSign;
    }
    this.toString = function()
    {
        return "[DispObj3D Object]";
    };
};
// for rtt and mrt
function RTTDispObj3D()
{
    DispObj3D.call( this );
    // exec: instance.renderBegin(renderer);
    this.renderBegin = function(renderer)
    {
        // to do somthing...
    };
    // exec: instance.renderEnd(renderer);
    this.renderEnd = function(renderer)
    {
        // to do somthing...
    };
};
RTTDispObj3D.prototype = Object.create(DispObj3D.prototype);
RTTDispObj3D.prototype.constructor = RTTDispObj3D;/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/

function CameraBase()
{

    this.uProbe = new ShaderUniformProbe();
    this.ufrustumProbe = new ShaderUniformProbe();
    //
	let m_tempV = new Vector3D()
	let m_tempV1 = new Vector3D();
	let m_initSV = new Vector3D();
	let m_initUP = new Vector3D();
	let  m_lookRHEnabled = true;
	//
	let m_matrix = new Matrix3D();
	let m_viewMat = new Matrix3D();
    let m_viewInvertMat = new Matrix3D();
	let m_eye = new Vector3D();
	let m_pos = new Vector3D();
	let m_up = new Vector3D();
    let m_lookDirectNV = new Vector3D();
	let m_lookAtDirec = new Vector3D();
	//
    let m_nearPlaneWidth = 1.0;
    let m_nearPlaneHeight = 1.0;
	//
	let m_stageW = 800, m_stageH = 600;
    let m_fovy = 0.0,m_aspect = 1.0, m_zNear = 0.1, m_zFar = 1000.0;
    let m_b = 0.0,m_t = 0.0,m_l = 0.0,m_r = 0.0;
	let m_projMat = new Matrix3D();
    let m_perspectiveEnabled = false;
    let m_rightHandEnabled = true;
	let m_rotateX = 0.0;
    let m_rotateY = 0.0;
    let m_rotateZ = 0.0;
    //
    let m_viewFieldZoom = 1.0;
    //
    let m_changed = true;
    this.name = "Camera";
	this.initilize = function()
	{

	}
	this.lookAtLH = function(eye, pos, up)
	{
		m_eye.copyFrom(eye);
		m_pos.copyFrom(pos);
		m_up.copyFrom(up);
		m_lookAtDirec.x = m_pos.x - m_eye.x;
		m_lookAtDirec.y = m_pos.y - m_eye.y;
		m_lookAtDirec.z = m_pos.z - m_eye.z;
		m_lookRHEnabled = false;
        m_lookDirectNV.copyFrom(m_lookAtDirec);
        m_lookDirectNV.normalize();
        //
        m_initUP.copyFrom(up);
        m_initUP.normalize();
        Vector3D.cross(m_lookAtDirec, m_up, m_initSV);
        m_initSV.normalize();
        m_changed = true;
	}
	this.lookAtRH = function(eye, pos, up)
	{
		m_eye.copyFrom(eye);
		m_pos.copyFrom(pos);
		m_up.copyFrom(up);
		m_lookAtDirec.x = m_pos.x - m_eye.x;
		m_lookAtDirec.y = m_pos.y - m_eye.y;
		m_lookAtDirec.z = m_pos.z - m_eye.z;
		m_lookRHEnabled = true;
        m_lookDirectNV.copyFrom(m_lookAtDirec);
        m_lookDirectNV.normalize();
        //
        m_initUP.copyFrom(up);
        m_initUP.normalize();
        Vector3D.cross(m_lookAtDirec, m_up, m_initSV);
        m_initSV.normalize();
        m_changed = true;
	}
    //
    this.getLookAtLH = function(eye, pos, up, outViewMat)
    {
        outViewMat.lookAtLH(eye, pos, up);
    }
    this.getLookAtRH = function(eye, pos, up, outViewMat)
    {
        outViewMat.lookAtRH(eye, pos, up);
    }
	this.perspectiveLH = function(fovy, aspect, zNear, zFar)
	{
		m_aspect = aspect;
        m_fovy = fovy;
        m_zNear = zNear;
        m_zFar = zFar;
		m_projMat.perspectiveLH(fovy, aspect, zNear, zFar);
        m_viewFieldZoom = Math.tan(fovy * 0.5);
        m_perspectiveEnabled = true;
        m_rightHandEnabled = false;
        m_changed = true;
	}
	this.perspectiveRH = function(fovy, aspect, zNear, zFar)
	{
		m_aspect = aspect;
        m_fovy = fovy;
        m_zNear = zNear;
        m_zFar = zFar;
        m_projMat.perspectiveRH(fovy, aspect, zNear, zFar);
        m_viewFieldZoom = Math.tan(fovy * 0.5);
        //
        trace("CameraBase::perspective(), m_viewFieldZoom: "+m_viewFieldZoom);
        //
		m_perspectiveEnabled = true;
        m_rightHandEnabled = true;
        m_changed = true;
    }
    this.getViewFieldZoom = function(){return m_viewFieldZoom;}
	this.orthoRH = function(zNear, zFar, b, t, l, r)
	{
        m_zNear = zNear;
        m_zFar = zFar;
        m_b = b;m_t = t;m_l = l;m_r = r;
		m_projMat.orthoRH(b, t, l, r, zNear, zFar);
		m_perspectiveEnabled = false;
        m_rightHandEnabled = true;
        m_changed = true;
	}
	this.orthoLH = function(zNear, zFar, b, t, l, r)
	{
        m_zNear = zNear;
        m_zFar = zFar;
        m_b = b;m_t = t;m_l = l;m_r = r;
		m_projMat.orthoLH(b, t, l, r, zNear, zFar);
		m_perspectiveEnabled = false;
        m_rightHandEnabled = false;
        m_changed = true;
	}
	this.perspectiveEnabled = function()
	{
		return m_perspectiveEnabled;
    }
    this.rightHandEnabled = function()
	{
		return m_rightHandEnabled;
    }
    
    this.sizeViewSize = function(pw,ph)
    {
        if(m_perspectiveEnabled)
        {
            if(m_rightHandEnabled)this.perspectiveRH(m_fovy, pw/ph, m_zNear, m_zFar);
            else this.perspectiveRH(m_fovy, pw/ph, m_zNear, m_zFar);
        }else
        {
            //
            //if(m_rightHandEnabled)this.orthoRH(m_zNear, m_zFar, m_b, m_t, m_l, m_r);
            //else this.orthoLH(m_zNear, m_zFar, m_b, m_t, m_l, m_r);
        }
    }
	this.translation = function(v3)
    {
        m_eye.copyFrom(v3);
        m_pos.x = v3.x + m_lookAtDirec.x;
        m_pos.y = v3.y + m_lookAtDirec.y;
        m_pos.z = v3.z + m_lookAtDirec.z;
        m_changed = true;
    }
	this.translationXYZ = function(px, py, pz)
    {
        m_eye.setTo(px,py,pz);
        m_pos.x = px + m_lookAtDirec.x;
        m_pos.y = py + m_lookAtDirec.y;
        m_pos.z = pz + m_lookAtDirec.z;
        m_changed = true;
	}
    this.setPosition = function(v3)
    {
        Vector3D.cross(m_lookAtDirec, m_up, m_tempV);
        var dot = m_tempV.dotProduct(m_initUP);
        m_tempV1.copyFrom(m_initUP);
        m_tempV1.scaleBy(dot);
        m_tempV.subtractBy(m_tempV1);
        //m_tempV.y = 0;
        m_eye.copyFrom(v3);
        m_lookAtDirec.x = m_pos.x - m_eye.x;
        m_lookAtDirec.y = m_pos.y - m_eye.y;
        m_lookAtDirec.z = m_pos.z - m_eye.z;
        m_lookDirectNV.copyFrom(m_lookAtDirec);
        m_lookDirectNV.normalize();
        //
        Vector3D.cross(m_tempV, m_lookAtDirec, m_up);
        m_up.normalize();
        m_changed = true;
    }
    this.setPositionXYZ = function(px, py, pz)
    {
        Vector3D.cross(m_lookAtDirec, m_up, m_tempV);
        var dot = m_tempV.dotProduct(m_initUP);
        m_tempV1.copyFrom(m_initUP);
        m_tempV1.scaleBy(dot);
        m_tempV.subtractBy(m_tempV1);
        //m_tempV.y = 0;
        m_eye.setTo(px, py, pz);
        m_lookAtDirec.x = m_pos.x - m_eye.x;
        m_lookAtDirec.y = m_pos.y - m_eye.y;
        m_lookAtDirec.z = m_pos.z - m_eye.z;
        m_lookDirectNV.copyFrom(m_lookAtDirec);
        m_lookDirectNV.normalize();
        //
        Vector3D.cross(m_tempV, m_lookAtDirec, m_up);
        m_up.normalize();
        m_changed = true;
    }
	this.getPosition = function() {return m_eye;}
	this.setLookAtPosition = function(px, py, pz)
	{
        m_pos.setTo(px,py,pz);
        m_lookAtDirec.x = m_pos.x - m_eye.x;
        m_lookAtDirec.y = m_pos.y - m_eye.y;
        m_lookAtDirec.z = m_pos.z - m_eye.z;
        m_lookDirectNV.copyFrom(m_lookAtDirec);
        m_lookDirectNV.normalize();
        m_changed = true;
	}
	this.getLookAtPosition = function() { return m_pos; }
    this.setRotationX = function(degree){m_rotateX = degree;m_changed = true;}
    this.getRotationX = function() { return m_rotateX; }
    this.setRotationY = function(degree){m_rotateY = degree;m_changed = true;}
    this.getRotationY =function(){ return m_rotateY; }
    this.setRotationZ = function(degree){m_rotateZ = degree;m_changed = true;}
    this.getRotationZ = function() { return m_rotateZ; }
    this.setRotationXYZ = function(rx, ry, rz)
    {
        m_rotateX = rx;
        m_rotateY = ry;
        m_rotateZ = rz;
        m_changed = true;
    }
    this.screenXYToViewXYZ = function(px, py, outV)
    {
        if (m_perspectiveEnabled) {
            px = m_nearPlaneWidth * (px - Stage.stageHalfWidth) / Stage.stageHalfWidth;
            py = m_nearPlaneHeight * (Stage.stageHalfHeight - py) / Stage.stageHalfHeight;
        }
        else {
            //px = VoxApp::app()->windowHalfWidth();
            //py = VoxApp::app()->windowHalfHeight() - py;
        }
        outV.setTo(px,py, -m_zNear);
        //
    }
    this.screenXYToWorldXYZ = function(px, py, outV)
    {
        if (m_perspectiveEnabled) {
            px = 0.5 * m_nearPlaneWidth * (px - Stage.stageHalfWidth) / Stage.stageHalfWidth;
            py = 0.5 * m_nearPlaneHeight * (Stage.stageHalfHeight - py) / Stage.stageHalfHeight;
        }
        else {
            //px = VoxApp::app()->windowHalfWidth();
            //py = VoxApp::app()->windowHalfHeight() - py;
        }
        //trace(">> screenXYToWorldXYZ(),m_nearPlaneWidth: ", m_nearPlaneWidth, ",m_nearPlaneHeight: ", m_nearPlaneHeight);
        outV.setTo(px, py, -m_zNear);
        outV.w = 1.0;
        m_viewInvertMat.transformVectorSelf(outV);
        //trace("screenXYToWorldXYZ(),B outV:", outV);
    }
    this.getWorldPickingRayByScreenXY = function(screenX, screenY, ray_pos, ray_tv)
    {
        if (m_perspectiveEnabled) {
            screenX = 0.5 * m_nearPlaneWidth * (screenX - Stage.stageHalfWidth) / Stage.stageHalfWidth;
            //screenY = 0.5 * m_nearPlaneHeight * (Stage.stageHalfHeight - screenY) / Stage.stageHalfHeight;
            screenY = 0.5 * m_nearPlaneHeight * (screenY - Stage.stageHalfHeight) / Stage.stageHalfHeight;
        }
        else {
            //px = VoxApp::app()->windowHalfWidth();
            //py = VoxApp::app()->windowHalfHeight() - py;
        }
        //trace(">> screenXYToWorldXYZ(),m_nearPlaneWidth: ", m_nearPlaneWidth, ",m_nearPlaneHeight: ", m_nearPlaneHeight);
        ray_pos.setTo(screenX, screenY, -m_zNear);
        ray_pos.w = 1.0;
        m_viewInvertMat.transformVectorSelf(ray_pos);
        ray_tv.copyFrom(ray_pos);
        ray_tv.subtractBy(m_eye);
        ray_tv.normalize();
    }
    this.getLookDirectNV = function(outNV)
    {
        outNV.copyFrom(m_lookDirectNV);
    }
    //
    let m_frustumWAABB = new AABB();
    let m_invViewMat = null;
    let m_newrPlaneHalfW = 0.5;
    let m_newrPlaneHalfH = 0.5;
    let m_nearWCV = new Vector3D();
    let m_farWCV = new Vector3D();
    let m_wNV = new Vector3D();
    let m_wFrustumVtxArr = [new Vector3D(),new Vector3D(),new Vector3D(),new Vector3D(),new Vector3D(),new Vector3D(),new Vector3D(),new Vector3D(),null,null,null];
    this.getInvertViewMatrix = function(){return m_invViewMat;};
    this.getZNear = function(){return m_zNear;};
    this.getZFar = function(){return m_zFar;};
    this.__calcTestParam = function()
    {
        if(m_invViewMat == null) m_invViewMat = new Matrix3D();
        m_invViewMat.copyFrom(m_viewMat);
        m_invViewMat.invert();
        //
        //m_aspect = aspect;
        //m_fovy = fovy;
        //m_zNear = zNear;
        //m_zFar = zFar;
        let tanv = Math.tan(m_fovy * 0.5);
        
        let halfMinH = m_zNear * tanv;
        let halfMinW = halfMinH * m_aspect;
        m_newrPlaneHalfW = halfMinW;
        m_newrPlaneHalfH = halfMinH;
        //trace("CameraBase::__calcTestParam(), (halfMinW, halfMinH): "+halfMinW+", "+halfMinH);
        let halfMaxH = m_zFar * tanv;
        let halfMaxW = halfMaxH * m_aspect;
        // inner view space
        m_nearWCV.setTo(0,0,-m_zNear);
        m_farWCV.setTo(0,0,-m_zFar);
        m_invViewMat.transformVectorSelf(m_nearWCV);
        m_invViewMat.transformVectorSelf(m_farWCV);
        m_wNV.x = m_farWCV.x - m_nearWCV.x;
        m_wNV.y = m_farWCV.y - m_nearWCV.y;
        m_wNV.z = m_farWCV.z - m_nearWCV.z;
        m_wNV.normalize();
        m_wFrustumVtxArr[8] = m_nearWCV;
        m_wFrustumVtxArr[9] = m_farWCV;
        m_wFrustumVtxArr[11] = m_wNV;
        //
        m_wFrustumVtxArr[0].setTo(-halfMaxW,-halfMaxH,-m_zFar);
        m_wFrustumVtxArr[1].setTo(halfMaxW,-halfMaxH,-m_zFar);
        m_wFrustumVtxArr[2].setTo(halfMaxW,halfMaxH,-m_zFar);
        m_wFrustumVtxArr[3].setTo(-halfMaxW,halfMaxH,-m_zFar);
        //
        m_wFrustumVtxArr[4].setTo(-halfMinW,-halfMinH,-m_zNear);
        m_wFrustumVtxArr[5].setTo(halfMinW,-halfMinH,-m_zNear);
        m_wFrustumVtxArr[6].setTo(halfMinW,halfMinH,-m_zNear);
        m_wFrustumVtxArr[7].setTo(-halfMinW,halfMinH,-m_zNear);
        //
        m_invViewMat.transformVectorSelf(m_wFrustumVtxArr[0]);
        m_invViewMat.transformVectorSelf(m_wFrustumVtxArr[1]);
        m_invViewMat.transformVectorSelf(m_wFrustumVtxArr[2]);
        m_invViewMat.transformVectorSelf(m_wFrustumVtxArr[3]);
        m_invViewMat.transformVectorSelf(m_wFrustumVtxArr[4]);
        m_invViewMat.transformVectorSelf(m_wFrustumVtxArr[5]);
        m_invViewMat.transformVectorSelf(m_wFrustumVtxArr[6]);
        m_invViewMat.transformVectorSelf(m_wFrustumVtxArr[7]);
        //
        m_frustumWAABB.max.setTo(-9999999,-9999999,-9999999);
        m_frustumWAABB.min.setTo(9999999,9999999,9999999);
        for(let i = 0; i < 8; ++i)
        {
            m_frustumWAABB.addPosition(m_wFrustumVtxArr[i]);
        }
        m_frustumWAABB.updateFast();
    }
    this.getWordFrustumWAABB = function(){return m_frustumWAABB;};
    this.getWordFrustumVtxArr = function(){return m_wFrustumVtxArr;};
    // visibility test
    this.visiTest = function(ro)
    {
        return m_frustumWAABB.sphereIntersectFast(ro.bounds.getCenter(),ro.bounds.getRadius());
        //return false;
    }
	this.update = function()
	{
        if(m_changed)
        {
            m_changed = false;
            if (m_rotateX > 360.0) m_rotateX -= 360.0;
            else if (m_rotateX < -360.0) m_rotateX += 360.0;
            if (m_rotateY > 360.0) m_rotateY -= 360.0;
            else if (m_rotateY < -360.0) m_rotateY += 360.0;
            if (m_rotateZ > 360.0) m_rotateZ -= 360.0;
            else if (m_rotateZ < -360.0) m_rotateZ += 360.0;
            m_matrix.identity();
            m_matrix.appendRotationEulerAngle(m_rotateX * MATH_PI_OVER_180, m_rotateY * MATH_PI_OVER_180, m_rotateZ * MATH_PI_OVER_180)
		    //
		    if (m_lookRHEnabled)
		    {
		    	m_viewMat.lookAtRH(m_eye, m_pos, m_up);
		    }
		    else
		    {
		    	m_viewMat.lookAtLH(m_eye, m_pos, m_up);
		    }
            m_nearPlaneHeight = m_zNear * Math.tan(m_fovy * 0.5) * 2.0;
            m_nearPlaneWidth = m_aspect * m_nearPlaneHeight;
            //m_viewInvertMat.copyFrom(m_viewMat)
            m_viewMat.append(m_matrix)
            m_viewInvertMat.copyFrom(m_viewMat);
            m_viewInvertMat.invert();
            //
            this.__calcTestParam();
            //
            // very important !!!
            if(this.uProbe.rst < 0)
            {
                this.uProbe.rst = 1;
                //
                this.uProbe.uniformSlotIndex = GlobalUniformSlot.index;
                this.uProbe.uniformSlotSize = 2;
                GlobalUniformSlot.dataList[this.uProbe.uniformSlotIndex] = m_viewMat;
                GlobalUniformSlot.dataList[this.uProbe.uniformSlotIndex+1] = m_projMat;
                //
                GlobalUniformSlot.index += this.uProbe.uniformSlotSize;
                this.uProbe.uniformTypes = [SHADER_MAT4, SHADER_MAT4];
                this.uProbe.dataSizeList = [1,1];
            }
            if(this.uProbe.rst > 0xffffff) this.uProbe.rst = Math.round(Math.random() * 1000) + 100;
            this.uProbe.rst++;
            GlobalUniformSlot.flagList[this.uProbe.uniformSlotIndex] = this.uProbe.rst;
            GlobalUniformSlot.flagList[this.uProbe.uniformSlotIndex+1] = this.uProbe.rst;
            // frustumProbe param
            if(this.ufrustumProbe.rst < 0)
            {
                this.ufrustumProbe.rst = 1;
                //
                this.ufrustumProbe.uniformSlotIndex = GlobalUniformSlot.index;
                this.ufrustumProbe.uniformSlotSize = 1;
                GlobalUniformSlot.dataList[this.ufrustumProbe.uniformSlotIndex] = [m_zNear,m_zFar,m_newrPlaneHalfW,m_newrPlaneHalfH];
                //
                GlobalUniformSlot.index += this.ufrustumProbe.uniformSlotSize;
                this.ufrustumProbe.uniformTypes = [SHADER_VEC4];
                this.ufrustumProbe.dataSizeList = [1];
            }
            if(this.ufrustumProbe.rst > 0xffffff) this.ufrustumProbe.rst = Math.round(Math.random() * 1000) + 100;
            this.ufrustumProbe.rst++;
            GlobalUniformSlot.flagList[this.ufrustumProbe.uniformSlotIndex] = this.ufrustumProbe.rst;

        }
    }
    
	this.destroy = function()
	{
        
	}
	this.lookRHEnabled = function()
	{
		return m_lookRHEnabled;
	}
	this.lookLHEnabled = function()
	{
		return !m_lookRHEnabled;
	}
	this.getMatrix = function()
	{
		return m_viewMat;
	}
	this.getViewMatrix = function()
	{
		return m_viewMat;
	}
	this.getProjectMatrix = function()
	{
		return m_projMat;
	}
}

var camera = new CameraBase();/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/
//function CameraBase()
//{
//    this.projMatrix = new  Matrix3D();
//    this.viewMatrix = new  Matrix3D();
//};
function RendererState()
{
    //
    //var m_self = this;
    
    let s_blendMode = RenderBlendMode.NORMAL;
    let s_blendDisabled = true;
    let s_cullMode = CullFaceMode.NONE;
    let s_cullDisabled = true;
    let m_gl = null;
    let s_depthTestType = DepthTestType.DISABLE;
    this.setRenderer = function(r)
    {
        m_gl = r.gl;
    }
    this.setCullFaceMode = function(mode)
	{
		switch (mode)
		{
        case CullFaceMode.BACK:
        if(s_cullMode)
        {
            s_cullMode = mode;
            if(!s_cullDisabled){s_cullDisabled = false;m_gl.enable(m_gl.CULL_FACE);}
            m_gl.cullFace(m_gl.BACK);
        }
			break;
        case CullFaceMode.FRONT:
        if(s_cullMode)
        {
            s_cullMode = mode;
            if(!s_cullDisabled){s_cullDisabled = false;m_gl.enable(m_gl.CULL_FACE);}
            m_gl.cullFace(m_gl.FRONT);
        }
			break;
        case CullFaceMode.FRONT_AND_BACK:
        if(s_cullMode)
        {
            s_cullMode = mode;
            if(!s_cullDisabled){s_cullDisabled = false;m_gl.enable(m_gl.CULL_FACE);}
            m_gl.cullFace(m_gl.FRONT_AND_BACK);
        }
            break;
        case CullFaceMode.NONE:
        case CullFaceMode.DISABLE:
        if(s_cullMode)
        {
            s_cullMode = mode;
            if(s_cullDisabled){s_cullDisabled = true;m_gl.disable(m_gl.CULL_FACE);}
        }
			break;
		default:
			break;
		}
	}
    this.setBlendMode = function(mode)
    {
        if(s_blendMode != mode)
        {
            s_blendMode = mode;
            //return;
            switch(mode)
            {
                case RenderBlendMode.NORMAL:
                    if (s_blendDisabled) { m_gl.enable(m_m_gl.BLEND); s_blendDisabled = false; m_gl.blendEquation(m_gl.FUNC_ADD);}
                    m_gl.blendFunc(m_gl.ONE, m_gl.ZERO);
                    break;
                case RenderBlendMode.TRANSPARENT:
                    if (s_blendDisabled) { m_gl.enable(m_gl.BLEND); s_blendDisabled = false; m_gl.blendEquation(m_gl.FUNC_ADD);}
                    m_gl.blendFunc(m_gl.SRC_ALPHA, m_gl.ONE_MINUS_SRC_ALPHA);
                    break;
                case RenderBlendMode.ALPHA_ADD:
                    if (s_blendDisabled) { m_gl.enable(m_gl.BLEND); s_blendDisabled = false; m_gl.blendEquation(m_gl.FUNC_ADD);}
                    m_gl.blendFunc(m_gl.ONE, m_gl.ONE_MINUS_SRC_ALPHA);
                    break;
                case RenderBlendMode.ADD:
                    if (s_blendDisabled) { m_gl.enable(m_gl.BLEND); s_blendDisabled = false; m_gl.blendEquation(m_gl.FUNC_ADD);}
                    m_gl.blendFunc(m_gl.SRC_ALPHA, m_gl.ONE);
                    break;
                case RenderBlendMode.ADD2:
                    if (s_blendDisabled) { m_gl.enable(m_gl.BLEND); s_blendDisabled = false; m_gl.blendEquation(m_gl.FUNC_ADD);}
                    m_gl.blendFunc(m_gl.ONE, m_gl.ONE);
                    break;
                case RenderBlendMode.INVERSE_ALPHA:
                    if (s_blendDisabled) { m_gl.enable(m_gl.BLEND); s_blendDisabled = false; m_gl.blendEquation(m_gl.FUNC_ADD);}
                    m_gl.blendFunc(m_gl.ONE, m_gl.SRC_ALPHA);
                    break;
                case RenderBlendMode.BLAZE:
                    if (s_blendDisabled) { m_gl.enable(m_gl.BLEND); s_blendDisabled = false; m_gl.blendEquation(m_gl.FUNC_ADD);}
					m_gl.blendFunc(m_gl.SRC_COLOR, m_gl.ONE);
                    break;
                case RenderBlendMode.DISABLE:
                    if (!s_blendDisabled) { m_gl.disable(m_gl.BLEND); s_blendDisabled = true; }
                    break; 
                default:
                    break;
            }
        }
    }
    this.setDepthTest = function(type)
    {
        if (s_depthTestType != type) {
            s_depthTestType = type;
            //trace("RendererBase::setDepthTest(),type：",std::to_string(static_cast<int>(type)));
            switch (type)
            {
            case DepthTestType.RENDER_SKY:
                m_gl.depthMask(false); m_gl.depthFunc(m_gl.ALWAYS);
                break;
            case DepthTestType.RENDER_SKY2:
                m_gl.depthMask(true); m_gl.depthFunc(m_gl.LEQUAL);
                break;
            case DepthTestType.RENDER_OPAQUE:
                m_gl.depthMask(true); m_gl.depthFunc(m_gl.LESS);
                break;
            case DepthTestType.RENDER_OPAQUE_OVERHEAD:
                m_gl.depthMask(false); m_gl.depthFunc(m_gl.EQUAL);
                break;
            case DepthTestType.RENDER_DECALS:
                m_gl.depthMask(false); m_gl.depthFunc(m_gl.LEQUAL);
                break;
            case DepthTestType.RENDER_TRANSPARENT_SORT:
                //if (list.next != null) list = sortByAverageZ(list);
                m_gl.depthMask(false); m_gl.depthFunc(m_gl.LESS);
                break;
            case DepthTestType.RENDER_WIRE_FRAME:
                m_gl.depthMask(true); m_gl.depthFunc(m_gl.LEQUAL);
                break;
            case DepthTestType.RENDER_NEXT_LAYER:
                m_gl.depthMask(false); m_gl.depthFunc(m_gl.ALWAYS);
                break;
            case DepthTestType.RENDER_WIRE_FRAME_NEXT:
                break;
            default:
                break;
            }
        }
    }    
};
/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/

function RendererBase()
{
    //
    let m_self = this;
    let m_rState = new RendererState();
    this.document = null;
    this.canvas = null;
    this.gl = null;
    this.bgColor = new Color();
    //
    let m_gl = null;
    //
    this.camera = new CameraBase();
    this.clearMask = 0;
    //
    let m_colorMask = {mr:true,mg:true,mb:true,ma:true};
    let m_canvas2D = null;
    let m_ctx2D = null;
    //STENCIL_TEST
    this.depthTestEnabled = true;
    this.stencilTestEnabled = true;
    this.drawBufsObj = null;
    this.initialize = function(document, canvas_id_name)
    {
        this.document = document;
        this.canvas = document.getElementById(canvas_id_name);
        m_canvas2D = document.getElementById("text");        
        m_ctx2D = m_canvas2D.getContext("2d");
        this.canvas.onmousedown = function(evt)
        {
            //console.log("mouseDown: "+evt.pageX+","+evt.pageY);
            //Stage
            Stage.mouseX = evt.pageX;
            Stage.mouseY = Stage.stageHeight - evt.pageY;
            Stage.mouseDown();
        }
        this.canvas.onmouseup = function(evt)
        {
            //console.log("mouseUp"+evt.pageX+","+evt.pageY);
            //Stage
            Stage.mouseX = evt.pageX;
            Stage.mouseY = Stage.stageHeight - evt.pageY;
            Stage.mouseUp();
        }
        this.canvas.onmousemove = function(evt)
        {
            //console.log("onmouseMove"+evt.pageX+","+evt.pageY);
            Stage.mouseX = evt.pageX;
            Stage.mouseY = Stage.stageHeight - evt.pageY;
            Stage.mouseMove();
        }
        //{preserveDrawingBuffer: true}
        var attr = {depth:this.depthTestEnabled,premultipliedAlpha: false, alpha: true, antialias:false,stencil:this.stencilTestEnabled,preserveDrawingBuffer:true };
        if(isWebGL1())
        {
            m_gl = this.gl = this.canvas.getContext('webgl',attr) || this.canvas.getContext("experimental-webgl",attr);
            if(m_gl == null || m_gl == undefined)
            {
                throwSysError("WebGL1 can not support!");
                return;
            }else
            {
                trace("Use WebGL1 success!");
            }
            this.drawBufsObj = m_gl.getExtension('WEBGL_draw_buffers');
            if (this.drawBufsObj != null) {
                //trace("Use WEBGL_draw_buffers Extension success!");
            }else
            {
                throwSysError("WEBGL_draw_buffers Extension can not support!");
                return;
            }
        }else
        {
            m_gl = this.gl = this.canvas.getContext('webgl2',attr);
            if(m_gl == null || m_gl == undefined)
            {
                throwSysError("WebGL2 can not support!");
                return;
            }else
            {
                trace("Use WebGL2 success!");
            }
        }

        var gl = m_gl;
        //
        if(this.depthTestEnabled) m_gl.enable(m_gl.DEPTH_TEST);
        else m_gl.disable(m_gl.DEPTH_TEST);
        if(this.stencilTestEnabled) m_gl.enable(m_gl.STENCIL_TEST);
        else m_gl.disable(m_gl.STENCIL_TEST);
        //
        m_gl.enable(m_gl.CULL_FACE);
        m_gl.cullFace(m_gl.BACK);
        //
        Stage.stageWidth = gl.drawingBufferWidth;
        Stage.stageHeight = gl.drawingBufferHeight;
        if (!this.gl) {
            alert('Unable to initialize WebGL. Your browser or machine may not support it.');
            return;
        }
        this.resize();
        //
        window.addEventListener('resize', this.resize, false);
        //
        m_rState.setRenderer(this);
        //
        this.clearMask = m_gl.COLOR_BUFFER_BIT | m_gl.DEPTH_BUFFER_BIT | m_gl.STENCIL_BUFFER_BIT;
    };
    this.setOnlyClearColor = function()
    {
        this.clearMask = m_gl.COLOR_BUFFER_BIT;
    }
    this.setOnlyClearColorAndDepth = function()
    {
        this.clearMask = m_gl.COLOR_BUFFER_BIT | m_gl.DEPTH_BUFFER_BIT;
    }
    this.setClearALL = function()
    {
        this.clearMask = m_gl.COLOR_BUFFER_BIT | m_gl.DEPTH_BUFFER_BIT | m_gl.STENCIL_BUFFER_BIT;
    }
    this.getGL = function(){return m_gl;}
    this.getRenderState = function(){return m_rState;}
    let m_displayWidth = 800.0;
    let m_displayHeight = 600.0;
    this.resize = function ()
    {
        // Lookup the size the browser is displaying the canvas.
        m_displayWidth  = m_self.canvas.clientWidth;
        m_displayHeight = m_self.canvas.clientHeight;
        if (m_self.canvas.width  != m_displayWidth ||
            m_self.canvas.height != m_displayHeight)
        {
          m_self.canvas.width  = m_displayWidth;
          m_self.canvas.height = m_displayHeight;
        }        
        Stage.stageWidth = m_gl.drawingBufferWidth;
        Stage.stageHeight = m_gl.drawingBufferHeight;
        //
        Stage.stageHalfWidth = Stage.stageWidth * 0.5;
        Stage.stageHalfHeight = Stage.stageHeight * 0.5;
        //
        Stage.update();
        if(m_self.camera != null)
        {
            m_self.camera.sizeViewSize(Stage.stageWidth, Stage.stageHeight);
        }
    }
    
    this.getStageWidth = function()
    {
        return Stage.stageWidth;
    }
    this.getStageHeight = function()
    {
        return Stage.stageHeight;
    }
    //
    this.statusInfo = "";
    let m_lastTime = 0;
    let m_fps = 60;
    this.statusEnbled = true;
    this.getFPS = function(){return m_fps;};
    this.showStatus = function()
    {
        let t = new Date().getTime();
        if(m_lastTime > 0)
        {
            m_lastTime = t - m_lastTime;
            m_fps = Math.round(1000/m_lastTime);
        }
        m_lastTime = t;
        if(this.statusEnbled)
        {
            m_ctx2D.clearRect(0, 0, 600, 70);
            m_ctx2D.font="50px Verdana";
            m_ctx2D.fillStyle = "red";
            m_ctx2D.textAlign = "left";
            m_ctx2D.fillText("FPS:"+m_fps+this.statusInfo, 5,50);
            //
            //let t = new Date().getTime();
            //if(m_lastTime > 0)
            //{
            //    m_lastTime = t - m_lastTime;
            //    //context.clearRect(0, 0, m_canvas2D.width, m_canvas2D.height);
            //    m_ctx2D.clearRect(0, 0, 600, 70);
            //    m_ctx2D.font="50px Verdana";
            //    m_ctx2D.fillStyle = "red";
            //    m_ctx2D.textAlign = "left";
            //    m_ctx2D.fillText("FPS:"+Math.round(1000/m_lastTime)+this.statusInfo, 5,50);
            //}
            //m_lastTime = t;
        }
    }
    this.setColorMask = function(mr,mg,mb,ma)
    {
        if(mr != undefined)m_colorMask.mr = mr;
        if(mg != undefined)m_colorMask.mg = mg;
        if(mb != undefined)m_colorMask.mb = mb;
        if(ma != undefined)m_colorMask.ma = ma;
    }
    this.renderBegin = function()
    {
        //Clear to black, fully opaque
        m_gl.clearColor(this.bgColor.r,this.bgColor.g,this.bgColor.b,this.bgColor.a);
        //
        //m_gl.colorMask(false, false, false, true);
        m_gl.colorMask(m_colorMask.mr,m_colorMask.mg,m_colorMask.mb,m_colorMask.ma);
        m_rState.setDepthTest(DepthTestType.RENDER_OPAQUE);
        // Clear everything
        m_gl.clearDepth(1.0);
        //
        if(this.depthTestEnabled)
        {
            m_gl.clear(this.clearMask);
        }else{            
            m_gl.clear(m_gl.COLOR_BUFFER_BIT);
        }
        m_gl.viewport(0, 0, Stage.stageWidth, Stage.stageHeight);
    };
    this.getDrawingBufferWidth = function()
    {
        return m_displayWidth;//this.gl.drawingBufferWidth;
    }
    this.getDrawingBufferHeight = function()
    {
        return m_displayHeight;//this.gl.drawingBufferHeight;
    }
    this.renderEnd = function()
    {
    };
    //let m_fbos = [];
    let m_fboBuf = null;
    let m_fboclearBoo = true;
    this.setRenderToTexture = function(texProxy,enableDepth,enableStencil, outputIndex)
    {
        if(texProxy == undefined) texProxy = null;
        if(outputIndex == undefined || outputIndex == null)
        {
            outputIndex = 0;
        }
        if(texProxy == null && outputIndex == 0)
        {
            m_gl.bindFramebuffer(m_gl.FRAMEBUFFER,null);
            this.renderBegin();
        }else
        {
            if(m_fboBuf == null)
            {
                m_fboBuf = new RendererFrameBufferBase();
                m_fboBuf.drawBufsObj = this.drawBufsObj;
            }
            if(outputIndex == 0)
            {
                if(enableDepth == undefined) enableDepth = true;
                if(enableStencil == undefined) enableStencil = true;
                m_fboBuf.writeDepthEnabled = enableDepth;
                m_fboBuf.writeStencilEnabled = enableStencil;
                m_fboBuf.initialize(m_gl, texProxy.getWidth(), texProxy.getHeight());
                //m_gl.bindFramebuffer(m_gl.FRAMEBUFFER,m_fboBuf.getFBO());
            }
            m_fboBuf.renderToTexAt(m_gl,texProxy,outputIndex);            
            //trace("....m_postBuf.getFBO(): "+m_postBuf.getFBO());
            m_fboclearBoo = true;
        }
    }
    this.__useFBO = function()
    {
        if(m_fboBuf != null)
        {
            if(m_fboclearBoo)
            {
                m_fboclearBoo = false;
                m_fboBuf.use(m_gl);    
                this.renderBegin();
                //trace("----fbo");
            }
        }
    }
    this.setRenderToBackBuffer = function()
    {
        m_gl.bindFramebuffer(m_gl.FRAMEBUFFER,null);
        this.renderBegin();
        //trace("----Back");
    }
    this.readPixels = function(px, py, width, height, format, type, pixels)
    {
        m_gl.readPixels(px, py, width, height, format, type, pixels);
        trace("RendererBase::readPixels(),m_gl: "+m_gl);
    }
    this.update = function()
    {
        if (this.camera != null)
        {
            this.camera.update();
            ShaderProgram.Reset();
        }
    }
    this.destroy =function()
    {
    }
};
/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/
let RenderSYS_DRAWTIMES = 0;
function ___Uniform()
{
    this.use = function(gl)
    {
    }
    this.upload = function(gl)
    {
    }
    this.next = null;
};
//
function ___Tex()
{
    this.use = function(gl)
    {
    }
    this.upload = function(gl)
    {
    }
    this.getNumTextures = function(){return 0;};
};
// ready repeat use
function ___RUnit()
{
    this.tex = null;
    this.mesh = null;
    this.vbuf = null;
    this.uniform = null;
    this.cullFaceMode = 0;
	this.blendMode = 0
    this.depthTestType = 0;
    this.renderState = 0;
    //
    this.enabled = true;
    this.status = 1;
    //
    this.reset = function()
    {
        this.tex = null;
        this.mesh = null;
        this.vbuf = null;
        if(this.uniform != null)
        {
            this.uniform.destroy();
            this.uniform = null;
        }
        this.cullFaceMode = 0;
	    this.blendMode = 0
        this.depthTestType = 0;
        this.renderState = 0;
        //
        this.enabled = true;
        this.status = 1;
    }
}
function ___Clasp()
{
    this.ro = null;
    this.unit = null;
    this.roI = 0;
    this.unitI = 0;
    //
    //this.node = null;
    this.index = 0;
    //
    this.next = null;
    this.prev = null;
}
function ___ROIBuilder()
{
    //let m_iArr = new Uint8Array(4096);
    let m_oArr = [];
    //this.name = "AAA";
    this.getIndexByClasp = function(clasp)
    {
        let len = 4096;
        if(m_oArr.length < 1)
        {
            for(let j = 0; j < len; ++j) m_oArr.push(null);
        }
        for(let i = 0; i < len; ++i){
            if(m_oArr[i] == null)
            {
                //m_iArr[i] = 0xf;
                m_oArr[i] = clasp;
                //trace("getIndexByClasp m_oArr["+i+"]: "+m_oArr[i]+", clasp: "+clasp);
                //trace("m_oArr.length: "+m_oArr.length);
                return i;
            }
        }
        throwSysError("Too many render object!!!!");
        abort();
        return 0;
    }
    this.getClaspAt = function(pi)
    {
        //trace("m_oArr.length: "+m_oArr.length);
        //trace("getClaspAt m_oArr["+pi+"]: "+m_oArr[pi]);
        return m_oArr[pi];
    }
    this.clearIndex = function(pi)
    {
        //m_iArr[pi] = 0;
        m_oArr[pi] = null;
        //trace("clearIndex m_oArr["+pi+"]: "+m_oArr[pi]);
    }
}
//
function ___SysRState()
{
    this.renderState = -1;
}
let __rstSysRSt = new ___SysRState();

// 每一个node代表的是对应一个当前渲染方式的shader的集合
function ___RenderNode()
{
    this.program = null;
    this.shdp = null;
    //
    this.shdidns = "";
    //
    this.rState = null;
    let m_sign = true;
    let m_sharedUniform = null;
    let m_units = [];
    let m_unitsLen = 0;
    this.addRO = function(material,tex,mesh,camera,ro)
    {
        if(m_sharedUniform == null)
        {
            m_sharedUniform = material.createSharedUniform(camera);
        }
        //
        if(m_sharedUniform == null){m_sharedUniform = new ___Uniform();}
        // ready render cmds serialize
        let unit = new ___RUnit();
        unit.tex = tex;
        //
        unit.vbuf = mesh.vbuf;
        unit.uniform = material.createSelfUniform(ro);
        if(unit.uniform == null) unit.uniform = new ___Uniform();
        // change render state
        ro.update();
        //
        unit.cullFaceMode = ro.cullFaceMode;
	    unit.blendMode = ro.blendMode;
        unit.depthTestType = ro.depthTestType;
        unit.renderState = ro.renderState;
        //
        m_units.push( unit );
        m_unitsLen ++;
        // 在这个步骤来整理渲染数据的分类，相同的操作和数据尽量放在紧邻的位置,render cmds serialize
        return unit;
    }
    //
    this.use = function(gl)
    {
        //
        if(m_unitsLen < 1) 
        {
            //trace("this node nothing need draw.");
            return;
        }
        m_sign = true;
        
        let i = 0;
        let unit = null;
        // 下面这个循环中的代码可以做高度的优化，但是可读性未必会变好
        var prevb = null;
        var preTex = null;
        let puniform = null;
        for(; i < m_unitsLen; ++i)
        {
            unit = m_units[i];
            if(unit.enabled)
            {
                if(m_sign)
                {
                    // only use on time in a frame
                    gl.useProgram( this.program );
                    //trace("AA 0");
                    this.shdp.useTexLocation();
                    m_sharedUniform.use(gl);
                    puniform = m_sharedUniform.next;
                    while(puniform != null)
                    {
                        puniform.use(gl);
                        puniform = puniform.next;
                    }
                    m_sign = false;
                }
                //
                unit.uniform.use(gl);
                puniform = unit.uniform.next;
                while(puniform != null)
                {
                    puniform.use(gl);
                    puniform = puniform.next;
                }

                // 这一步可以优化: 如果多个vbuf(mesh)一样, 则只需使用一次, draw多次
                if(prevb != unit.vbuf)
                {
                    prevb = unit.vbuf;
                    prevb.use(this.shdp);
                }
                // 这一步可以优化: 如果多个tex一样, 则只需使用一次
                if(preTex != unit.tex)
                {
                    preTex = unit.tex;
                    preTex.texIndex = 0;
                    preTex.use(gl);
                    //trace("AA 1");
                    let nextTex = preTex.next;
                    let t = preTex.texTotal;
                    while(nextTex != null)
                    {
                        //trace(t);
                        nextTex.texIndex = t;
                        nextTex.use(gl);
                        t += nextTex.texTotal;
                        nextTex = nextTex.next;
                        if(nextTex == preTex)
                        {
                            throwSysError("___RenderNode::use(), nextTex == preTex, Error!");
                            return;
                        }
                    }
                }
                if(__rstSysRSt.renderState != unit.renderState)
                {
                    __rstSysRSt.renderState = unit.renderState;
                    //
                    //trace("unit.blendMode: "+unit.blendMode+",unit.depthTestType: "+unit.depthTestType);
                    this.rState.setCullFaceMode(unit.cullFaceMode);
                    this.rState.setBlendMode(unit.blendMode);
                    this.rState.setDepthTest(unit.depthTestType);
                }
                // 上述优化决定 draw 需要拆分独立开来
                //trace("AA 2");
                unit.vbuf.draw(gl);
                RenderSYS_DRAWTIMES++;
            }else
            {
                if(unit.status < 0)
                {
                    // ready remove, but can not destroy vbuf,tex,shader
                    m_units.splice(i,1);
                    i--;
                    m_unitsLen --;
                    unit.reset();
                    trace("remove a render unit object");
                }
            }
        }
    }
};
//  一个独立的渲染方式的集合
function ___RenderBlock()
{
    let m_nodes = [];
    let m_nodesTotal = 0;
    //
    let m_claspTotal = 0;
    //
    let m_claspBegin = null;
    let m_claspEnd = null;
    //
    let m_roiBuilder = new ___ROIBuilder();
    //
    this.rState = null;
    //
    let m_nodeDict = new Map();
    this.addRO = function(gl,camera,ro)
    {
        //
        //trace("add a ro to the RenderStack.");
        let material = ro.getMaterial();
        let tex = material.getTextureProxy();
        let mesh = ro.getMesh();
        //
        if(tex == null) tex = new ___Tex();
        // upload to GPU only this pos !!!!!
        // upload all(shader,tex,vb)
        let shdp = material.getShaderProgram();
        shdp.upload( gl );
        /////////////////////////////
        tex.upload( gl );
        let nextTex = tex.next;
        while(nextTex != null)
        {
            nextTex.upload(gl);
            nextTex = nextTex.next;
            if(nextTex == tex)
            {
                throwSysError("___RenderBlock::addRO(), nextTex == tex, Error!");
                break;
            }
        }
        //////////////////////////////
        mesh.vbuf.upload( gl );
        //
        let node = null;
        if(m_nodeDict.has(shdp.name))
        {
            node = m_nodeDict.get(shdp.name);
        }
        else
        {
            node = new ___RenderNode();
            node.rState = this.rState;
            node.shdp = shdp;
            node.program = shdp.getProgram();
            m_nodeDict.set(shdp.name,node);
            m_nodes.push( node );
            m_nodesTotal++;
            //
        }
        let unit = node.addRO(material,tex,mesh, camera,ro);
        let clasp = new ___Clasp();
        clasp.ro = ro;
        //clasp.roI = m_claspTotal;
        clasp.unit = unit;
        //clasp.unitI = m_claspTotal;
        ro.setRenderSign(m_roiBuilder.getIndexByClasp(clasp));

        //if(clasp.prev != null || clasp.next != null){trace("error!");abort()}
        if(m_claspBegin == null)
        {
            m_claspEnd = m_claspBegin = clasp;
        }
        else
        {
            if(m_claspEnd.prev != null)
            {
              m_claspEnd.next = clasp;
              clasp.prev = m_claspEnd;
              m_claspEnd = clasp;
            }
            else
            {
              m_claspBegin.next = clasp;
              clasp.prev = m_claspBegin;
              m_claspEnd = clasp;
            }
        }
        m_claspTotal ++;
    }
    this.removeRO = function(ro)
    {
        // need optimize!
        let nto = m_roiBuilder.getClaspAt(ro.getRenderSign());
        if(nto != null && nto.ro == ro)
        {
            // remove do...
            m_roiBuilder.clearIndex( nto.ro.getRenderSign() );
            nto.ro.setRenderSign( -1 );
            //
            nto.ro = null;
            nto.unit.enabled = false;
            nto.unit.status = -1;
            nto.unit = null;
            trace("remove a render render display object from The RenderStack.");
            if(nto != m_claspBegin)
            {
                nto.prev.next = nto.next;
                if(nto.next != null)
                {
                    nto.next.prev = nto.prev;
                    nto.next = null;
                }
                else
                {
                    m_claspEnd = nto.prev;
                }
                nto.prev = null;
            }
            else
            {
                m_claspBegin = nto.next;
                if(m_claspBegin != null)
                {
                    m_claspBegin.prev = null;
                }else
                {
                    m_claspEnd = null;
                }
                nto.next = null;
            }
            return true;
        }
        return false;
    }
    //
    this.update = function(camera)
    {
        let next = m_claspBegin;
        let co = null;
        let ro = null;
        while(next != null)
        {
            co = next;
            next = next.next;
            //
            ro = co.ro;
            ro.update();
            if(ro.visible)
            {
                // camera visiblity test
                co.unit.enabled = camera.visiTest(ro);
            }else{
                co.unit.enabled = ro.visible;
            }
        }
    }
    //
    this.use = function(gl)
    {
        let i = 0;
        let node = null;
        for(; i < m_nodesTotal; ++i)
        {
            node = m_nodes[i];
            node.use(gl);
        }
    }
};
/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/
//  this class check render models of a ro,if a model need construct ,to do
//  the end of check or construct, the ro is usable!
//
//
//
function _SCPage()
{
    //
    this.next = null;
    //
    this.__index = -1;

    let m_solidBlock = new ___RenderBlock();
    let m_alphaBlock = new ___RenderBlock();
    //
    let m_structureSc = new ___StructureScene();
    //
    let m_renderer = null;
    //
    this.rttEnabled = false;
    this.rttDisp = null;
    //
    this.setRenderParam = function(renderer)
    {
        m_renderer = renderer;
        m_solidBlock.rState = m_renderer.getRenderState();
        m_alphaBlock.rState = m_renderer.getRenderState();
    }
    this.addRDisp = function(disp)
    {
        if(disp != null && disp != undefined)
        {
            if(disp.getRenderSign() < 0)
            {
                if(!this.rttEnabled)m_structureSc.addRO(disp);
            }
        }
    }
    this.__addROTo = function(ro)
    {
        switch(ro.depthTestType)
        {
            case DepthTestType.RENDER_TRANSPARENT_SORT:
            case DepthTestType.RENDER_SKY:
            case DepthTestType.RENDER_NEXT_LAYER:
            m_alphaBlock.addRO(m_renderer.gl, m_renderer.camera, ro);
            break;
            default:
            m_solidBlock.addRO(m_renderer.gl, m_renderer.camera, ro);
        }
    }
    this.update = function(camera)
    {
        // 并非需要每一帧执行
        if(!this.rttEnabled)
        {
            m_structureSc.getFinishList(this);
            //
            m_solidBlock.update(camera);
            m_alphaBlock.update(camera);
        }
    }
    this.renderBegin = function(renderer)
    {
        if(this.rttEnabled)
        {
            if(this.rttDisp.renderBegin != null)
            {
                this.rttDisp.renderBegin(m_renderer);                
                m_renderer.__useFBO();
            }
        }
    }
    this.renderEnd= function()
    {
        if(this.rttEnabled)
        {
            if(this.rttDisp.renderEnd != null) this.rttDisp.renderEnd(m_renderer);
        }
    }
    this.use = function(gl)
    {
        if(this.rttEnabled)
        {
            //if(this.rttDisp.renderBegin != null) this.rttDisp.renderBegin(m_renderer);
            //m_solidBlock.use(gl);
            //m_alphaBlock.use(gl);
            //if(this.rttDisp.renderEnd != null) this.rttDisp.renderEnd(m_renderer);
        }else
        {
            //
            m_solidBlock.use(gl);
            m_alphaBlock.use(gl);
            //
        }
    }
    this.removeRO = function(disp)
    {
        let s = disp.getRenderSign();
        if(s != 999999)
        {
            let boo = m_alphaBlock.removeRO(disp);
            if(boo)
            {
                return true;
            }else{
                return m_solidBlock.removeRO(disp);
            }
        }else{
            return m_structureSc.removeRO(disp);
        }
    }
}
//  render ready step 1
function ___StructureScene()
{
    let m_waitList = [];
    let m_waitTotal = 0;
    //
    //let m_finishList = [];
    //let m_finishTotal = 0;
    this.initialize = function()
    {

    }
    // add a render display object
    this.addRO = function(ro)
    {
        ro.setRenderSign(999999);
        m_waitList.push( ro );
        m_waitTotal ++;
    }
    this.removeRO = function(ro)
    {
        // ...
        ro.setRenderSign(-1);
        return true;
    }
    let m_ro = null;
    let m_material = null;
    this.getFinishList = function(sc)
    {
        // need optimize
        // set max loop times;
        let tex = null;
        let shdp = null;
        for(let i = m_waitTotal - 1; i >= 0; --i)
        {
            m_ro = m_waitList[i];
            if(m_ro.getRenderSign() > -1)
            {
                m_material = m_ro.getMaterial();
                if(m_material != null && m_ro.getMesh() != null)
                {
                    shdp = m_material.getShaderProgram();
                    if(shdp != null)
                    {
                        //this.dataEnough
                        if(shdp.haveTexture())
                        {
                            tex = m_material.getTextureProxy();
                            if(tex != null && tex.dataEnough())
                            {
                                let nextTex = tex.next;
                                let ntboo = true;
                                while(nextTex != null)
                                {
                                    if(!nextTex.dataEnough())
                                    {
                                        ntboo = false;
                                        break;
                                    }
                                    nextTex = nextTex.next;
                                    if(nextTex == tex)
                                    {
                                        ntboo = false;
                                        throwSysError("RenderScene::getFinishList(), nextTex == tex, Error!");
                                        break;
                                    }
                                }
                                if(ntboo)
                                {
                                    m_waitList.splice(i,1);
                                    --m_waitTotal;
                                    sc.__addROTo(m_ro);
                                }
                            }
                        }
                        else
                        {
                            m_waitList.splice(i,1);
                            --m_waitTotal;
                            sc.__addROTo(m_ro);
                        }
                    }
                }
            }else
            {
                m_waitList.splice(i,1);
                m_waitTotal --;                
                m_ro.setRenderSign( -1 );
                trace("StructureScene remove a render display in waitList...");
            }
        }
    }
};

function RenderScene()
{
    //let structureSc = new ___StructureScene();
    // test end
    let m_renderer = new RendererBase();
    //
    this.canvas = null;
    this.gl = null;
    this.camera = null;
    this.cameraNear = 0.1;
    this.cameraFar = 1000.0;
    this.cameraFov = 45.0;
    this.initialize = function(glCanvasNS,posV3, lookAtPosV3, upV3)
    {
        //m_renderer = new RendererBase();
        if (!m_renderer)
        {
          throwSysError("webgl create error");
          abort();
        }
        if(posV3 == undefined)
        {
            posV3 = new Vector3D(500.0, 600.0, 500.0);
        }
        if(lookAtPosV3 == undefined)
        {
            lookAtPosV3 = new Vector3D(0.0, 0.0, 0.0);
        }
        if(upV3 == undefined)
        {
            upV3 = new Vector3D(0.0, 1.0, 0.0);
        }
        // glCanvasNS = "glcanvas"
        m_renderer.initialize(document,glCanvasNS);
        this.canvas = m_renderer.canvas;
        this.gl = m_renderer.gl;
        m_renderer.camera.perspectiveRH(degreeToRadian(this.cameraFov), Stage.stageWidth/Stage.stageHeight, this.cameraNear, this.cameraFar);
        m_renderer.camera.lookAtRH(posV3, lookAtPosV3, upV3);
        m_renderer.camera.update();
        this.camera = m_renderer.camera;
        //
        m_renderer.statusEnbled = false;
        m_renderer.bgColor.setRGB3fTo(0.0,0.0,0.0);
        //m_renderer.bgColor.a = 0.0;
    }
    
    this.getRenderer = function(){return m_renderer;}
    
    let m_scPageHead = null;
    let m_scPageTail = null;
    let m_scPagesArr = [];
    // add a render display object
    this.addRDisp = function(disp, sc_index)
    {
        if(disp != null && disp != undefined)
        {
            if(disp.getRenderSign() < 0)
            {
                //structureSc.addRO(disp);
                if(sc_index == undefined){
                    sc_index = -1;
                }
                let scPage = null;
                if(sc_index < 0)
                {
                    scPage = m_scPageTail;
                }else{
                    if(sc_index>=0 && sc_index < m_scPagesArr.length) scPage = m_scPagesArr[sc_index];
                }
                if(scPage != null && !scPage.rttEnabled)
                {
                    scPage.addRDisp(disp);
                    return scPage.__index;
                }else
                {
                    scPage = new _SCPage();
                    scPage.__index = m_scPagesArr.length;
                    m_scPagesArr.push(scPage);
                    scPage.setRenderParam( m_renderer );
                    if(m_scPageHead == null) {m_scPageTail = m_scPageHead = scPage;}
                    else{
                        m_scPageTail.next = scPage;
                        m_scPageTail = scPage;
                    }
                    scPage.addRDisp(disp);
                    trace("create curr scPage");                    
                    return scPage.__index;
                }
            }
        }
    }
    this.removeRDisp = function(disp)
    {
        if(disp != null && disp != undefined)
        {
            let s = disp.getRenderSign();
            if(s > -1)
            {
                let nextPage = m_scPageHead;
                let grid = null;
                let boo = false;
                while(nextPage != null)
                {
                    grid = nextPage;
                    nextPage = grid.next;
                    boo = grid.removeRO( disp );
                    if(boo){
                        break;
                    }
                }
            }
        }
    }
    this.addRTTDisp = function(rttdisp)
    {
        if(rttdisp != null && rttdisp != undefined)
        {
            if(rttdisp.getRenderSign() < 0)
            {
                trace("create curr RTT scPage");
                let scPage = new _SCPage();
                scPage.__index = m_scPagesArr.length;
                m_scPagesArr.push(scPage);
                scPage.rttEnabled = true;
                scPage.setRenderParam( m_renderer );
                if(m_scPageHead == null) {m_scPageTail = m_scPageHead = scPage;}
                else{
                    m_scPageTail.next = scPage;
                    m_scPageTail = scPage;
                }
                scPage.rttDisp = rttdisp;
                scPage.addRDisp(rttdisp);
                return scPage.__index;               
            }
        }
    }
    
    this.run = function()
    {
        // 并非需要每一帧执行
        //structureSc.getFinishList(this);
        //
        ///////////////////////////
        ///////////////////////////
        // 开始整理用于GPU渲染/计算所需的数据和控制逻辑(渲染数据标准化阶段)        
        ///////////////////////////
        ///////////////////////////
        m_renderer.update();
        m_renderer.showStatus();
        
        //trace("frame begin----------------------------------------");
        m_renderer.setClearALL();
        __rstSysRSt.renderState = -1;
        m_renderer.renderBegin();
        //
        RenderSYS_DRAWTIMES = 0;
        //
        let nextPage = m_scPageHead;
        let grid = null;
        let pageI = 0;
        while(nextPage != null)
        {
            grid = nextPage;
            nextPage = grid.next;
            if(nextPage != null && nextPage.rttEnabled) nextPage.renderBegin();
            // 整理可视化剔除分组优化, 动态合并拆分, 鼠标检测等工作        
            if(grid.rttEnabled)
            {
                //grid.update( this.camera );
                //// run to gpu
                //__rstSysRSt.renderState = -1;
                //grid.use( this.gl );
                grid.renderEnd();
            }else
            {
                grid.update( this.camera );
                // run to gpu
                __rstSysRSt.renderState = -1;
                grid.use( this.gl );
            }
            pageI ++;
        }
        //
        //trace("frame end ------------------------------------pageI: "+pageI);
        m_renderer.renderEnd();
        //
    }
};
/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/

function Canvas3DMaterial()
{
    MaterialBase.call(this);
    this.createSharedUniform = function(camera)
    {
        return null;
    }
    this.createSelfUniform = function(ro)
    {
        let oum = new ShaderObjectUniform();
        oum.types = [SHADER_VEC4,SHADER_VEC4];
        oum.dataSizeList = [1,1];
        oum.uniformSize = 3;
        oum.locations = [this.getUniformLocationAt(0),this.getUniformLocationAt(1)];
        //
        oum.dataList = [ro.paramArray,ro.mouseArray];
        return oum;
    }
};
Canvas3DMaterial.prototype = Object.create(MaterialBase.prototype);
Canvas3DMaterial.prototype.constructor = Canvas3DMaterial;
//gl_FragCoord.x
Canvas3DMaterial.shdCode = {
    uniqueName:"Canvas3DMaterial_shader",
    vshdCodeES2:
        "precision highp float;"
        +"attribute vec3 a_vs;"
        +"void main()"
        +"{"
        +"  gl_Position = vec4(a_vs,1.0);"
        +"}"
        ,
    vshdCodeES3:
        "#version 300 es\n"
        +"precision highp float;"
        +"layout(location = 0) in vec3 a_vs;"
        +"void main()"
        +"{"
        +"  gl_Position = vec4(a_vs,1.0);"
        +"}"
        ,
        
};
function CanvasAction()
{
    var m_target = null;

    this.bindTarget = function(tar)
    {  
        m_target = tar;
    }
    this.destroy = function()
    {  
        m_target = null;
    }
    let m_time = 0.0;
    this.update = function()
    {
        m_target.paramArray[0] = Stage.stageWidth;
        m_target.paramArray[1] = Stage.stageHeight;
        //
        if(m_target.paramArray[3] > 1.0)
        {
            if(m_target.mouseXY.x != Stage.mouseX)
            {
                m_target.mouseArray[0] = Stage.mouseX - m_target.mouseInitXY.x;
                m_target.mouseArray[2] += Stage.mouseX - m_target.mouseXY.x;
                m_target.mouseXY.x = Stage.mouseX;
            }
            if(m_target.mouseXY.y != Stage.mouseY)
            {
                m_target.mouseArray[1] = Stage.mouseY - m_target.mouseInitXY.y;
                m_target.mouseArray[3] += Stage.mouseY - m_target.mouseXY.y;
                m_target.mouseXY.y = Stage.mouseY;
            }
        }
        //
        m_target.paramArray[2] = m_time;
        m_time += 0.01;
    }
};
// parse glsl raw code text
function ResCodeMap()
{
    const TEXURLS = "texurls";
    //
    this.createTexByUrls = function(urls,samplerCubeBoo)
    {
        var tex = null;
        if(urls.length == 1)
        {
            tex = TextureProxy.Create(urls[0],TextureFormat.RGBA,TextureFormat.RGBA);
            tex.mipmapEnabled = true;
            tex.wrap_s = TextureConst.WRAP_REPEAT;
            tex.wrap_t = TextureConst.WRAP_REPEAT;
        }else if(samplerCubeBoo && urls.length == 6)
        {
            tex = new CubeTexturesProxy();
            tex.mipmapEnabled = true;
            tex.wrap_s = TextureConst.WRAP_REPEAT;
            tex.wrap_t = TextureConst.WRAP_REPEAT;
            tex.loadImgFromUrls(urls);
            //trace("create cube Texture");
        }else
        {
            tex = new MultTexturesProxy();
            tex.mipmapEnabled = true;
            tex.wrap_s = TextureConst.WRAP_REPEAT;
            tex.wrap_t = TextureConst.WRAP_REPEAT;
            tex.internalFormat = TextureFormat.RGBA;
            tex.srcFormat = TextureFormat.RGBA;
            tex.loadImgFromUrls(urls);
        }
        return tex;
    }
    this.sturctureParse = function(dataStr)
    {
        var regex = /\"+/g;
        dataStr = dataStr.replace(regex, '');
        regex = /\'/g;
        dataStr = dataStr.replace(regex, "");
        //
        let arr = dataStr.split("],");
        let subArr = null;
        let texDataArr = [];
        let j = 0, k = 0;
        let str = "";
        let texRes = null;
        for(let i = 0; i < arr.length; ++i)
        {
            if(arr[i].length > 16)
            {
                subArr = arr[i].split(":");
                j = subArr[1].indexOf("[");
                k = subArr[1].indexOf("]");
                //
                if(k>=0)str = subArr[1].slice(j+1,k);
                else str = subArr[1].slice(j+1);
                texRes = {type:subArr[0], urls:[]};
                subArr = str.split(",");
                texDataArr.push(texRes);
                j = 0;
                while(j < subArr.length)
                {
                    texRes.urls.push(subArr[j]);
                    ++j;
                }
            }            
        }
        let tex = null;
        let prevTex = null;
        let texHead = null;
        let urls = null;
        for(i = 0; i < texDataArr.length; ++i)
        {
            urls = texDataArr[i].urls;
            if(texDataArr[i].type.indexOf("texture2D") >= 0)
            {
                if(urls.length < 2)
                {
                    tex = TextureProxy.Create(urls[0],TextureFormat.RGBA,TextureFormat.RGBA);
                    tex.mipmapEnabled = true;
                    tex.wrap_s = TextureConst.WRAP_REPEAT;
                    tex.wrap_t = TextureConst.WRAP_REPEAT;
                    if(texHead == null) texHead = tex;
                    else prevTex.next = tex;
                    prevTex = tex;
                    trace("single tex");
                }else
                {
                    tex = new MultTexturesProxy();
                    tex.mipmapEnabled = true;
                    tex.wrap_s = TextureConst.WRAP_REPEAT;
                    tex.wrap_t = TextureConst.WRAP_REPEAT;
                    tex.internalFormat = TextureFormat.RGBA;
                    tex.srcFormat = TextureFormat.RGBA;
                    tex.loadImgFromUrls(urls);
                    if(texHead == null) texHead = tex;
                    else prevTex.next = tex;
                    prevTex = tex;
                    trace("mult tex");
                }
            }else if(texDataArr[i].type.indexOf("textureCube") >= 0)
            {
                tex = new CubeTexturesProxy();
                tex.mipmapEnabled = true;
                tex.wrap_s = TextureConst.WRAP_REPEAT;
                tex.wrap_t = TextureConst.WRAP_REPEAT;
                tex.loadImgFromUrls(urls);
                if(texHead == null) texHead = tex;
                else prevTex.next = tex;
                prevTex = tex;
                trace("cube tex");
            }
        }
        return texHead;
    }
    this.parseRes = function(configStr, samplerCubeBoo)
    {
        let arr = configStr.split("\n");
        let len = arr.length;
        let i = 0, j = 0;
        let str = "";
        configStr = "";
        // remove comment string
        for(i = 0; i < len; ++i)
        {
            str = arr[i];
            j = str.indexOf("//");
            if(j > 0)
            {
                configStr += str.slice(0,j);
            }else if(j < 0)
            {
                configStr += str;
            }
        }
        // test "{" and "}"
        
        var regex = /\s+/g;
        configStr = configStr.replace(regex, '');
        regex = /[\r\n]/g;
        configStr = configStr.replace(regex, '');
        //
        i = configStr.indexOf("{");
        j = configStr.indexOf("}");
        if((j - i) > 10)
        {
            // have {texture2D:[...],texture3D:[...]} structure
            return this.sturctureParse(configStr.slice(i+1,j));
        }
        //trace(codeStr);
        //trace(configStr);
        arr = configStr.split("=");
        //trace(arr[0].length);
        let vstr = (arr[0]+"").toLowerCase();
        //trace(vstr.indexOf("texurls"));
        
        let urls = [];
        if(vstr.indexOf(TEXURLS) < 0)
        {
            urls = ["colorPalette.jpg"];
        }else{
            configStr = arr[1].slice(1,arr[1].length - 1);
            //trace(configStr);
            arr = configStr.split(",");
            //trace(arr);
            len = arr.length;
            for(i = 0; i < len; ++i)
            {
                str = arr[i];
                if(str.length > 3)urls.push(arr[i].slice(1,arr[i].length - 1));
            }
        }
        //m_config
        return this.createTexByUrls( urls, samplerCubeBoo );        
    }
    this.parse = function(rawStr)
    {
        let ia = rawStr.indexOf("//##config");
        let ver = 2;
        if(ia < 0)
        {
            // remove comment lines
            let arr = rawStr.split("\n");
            let len = arr.length;
            let i = 0, j = 0;
            let str = "";
            rawStr = "";
            // remove comment string
            for(i = 0; i < len; ++i)
            {
                str = arr[i];
                j = str.indexOf("//");
                if(j > 0)
                {
                    rawStr += str.slice(0,j) + "\n";
                }else if(j < 0)
                {
                    rawStr += str + "\n";
                }
            }
            //
            ia = rawStr.indexOf("#version ") >= 0?1:0;
            ia += rawStr.indexOf(" 300 ")>=0?1:0;
            ia += rawStr.indexOf(" es")>=0?1:0;
            ver = ia>2?3:2;
            trace("GLSLVersion: GLSL ES"+ver);
            if(ver == 3)
            {
                var regex = /#version /g;
                rawStr = "#version 300 es\n"+rawStr.replace(regex, '//#version ');
            }
            if(rawStr.indexOf("uniform sampler2D") > 0)
            {
                return {glslVer:ver,code:rawStr,tex:this.createTexByUrls(["colorPalette.jpg"], false)};
            }else
            {
                return {glslVer:ver,code:rawStr,tex:null};
            }
        }
        let ib = rawStr.indexOf("//##end");
        let configStr = rawStr.slice(ia + 10, ib);
        let codeStr = rawStr.slice(0,ia) + rawStr.slice(ib+7);
        //
        let vtex = null;
        let samplerCubeBoo = codeStr.indexOf(" samplerCube ") > 2;
        if(codeStr.indexOf("uniform sampler2D") > 0 || samplerCubeBoo)
        {
            // create texture
            vtex = this.parseRes( configStr,samplerCubeBoo );
        }

        // remove comment lines
        let arr = codeStr.split("\n");
        let len = arr.length;
        let i = 0, j = 0;
        let str = "";
        codeStr = "";
        // remove comment string
        for(i = 0; i < len; ++i)
        {
            str = arr[i];
            j = str.indexOf("//");
            if(j > 0)
            {
                codeStr += str.slice(0,j) + "\n";
            }else if(j < 0)
            {
                codeStr += str + "\n";
            }
        }
        //
        ia = codeStr.indexOf("#version ") >= 0?1:0;
        ia += codeStr.indexOf(" 300 ")>=0?1:0;
        ia += codeStr.indexOf(" es")>=0?1:0;
        ver = ia>2?3:2;
        trace("GLSLVersion: gLSL ES"+ver);
        if(ver == 3)
        {
            var regex = /#version /g;
            codeStr = "#version 300 es\n"+codeStr.replace(regex, '//#version ');
            //trace("codeStr: \n"+codeStr);
        }
        //
        return {glslVer:ver,code:codeStr,tex:vtex};
    }
    this.getShowCodeStr = function(codeStr)
    {
        let arr = codeStr.split("\n");
        let len = arr.length;
        let i = 0, j = 0;
        let str = "";          
        var isES3 = codeStr.indexOf("#version 300 es") == 0;
        if(codeStr.indexOf("vily313@126.com") > 0) i = isES3?6:5;
        codeStr = "";
        var regex = /[\r\n]/g;
        var regexSpace = /\s+/g;
        for(; i < len; ++i)
        {
            str = arr[i];
            str = str.replace(regex, '');
            if(str.length < 4 && str.indexOf("{") < 0 && str.indexOf("}") < 0){str = str.replace(regexSpace, '');}
            if(str.length > 0)
            {
              codeStr += "\t"+str + "\n";
            }
        }
        codeStr += "\t/***************************************************************************/";
        if(isES3)
        {
          codeStr =  "\t#version 300 es\n"+ codeStr;
        }
        return codeStr;
    }
}
function Canvas3D()
{
    DispObj3D.call(this);
    //
    this.color = new Color(0.05,0.2,0.4,1.0);
    this.paramArray = [Stage.stageWidth,Stage.stageHeight,0.0,0.0];
    this.mouseArray = [0.0,0.0,0.0,0.0];
    this.posList = [
        0.4,0.0,0.0,    0.25,
        -0.4,0.0,0.0,    0.25,
        0.0,0.4,0.0,    0.25
    ];
    //
    this.mouseXY = {x:0.0,y:0.0};
    this.mouseInitXY = {x:0.0,y:0.0};
    this.mouseDown = function()
    {
        this.paramArray[3] = 2.0;
        //trace("...mouseDown..");
        this.mouseInitXY.x = this.mouseXY.x = Stage.mouseX;
        this.mouseInitXY.y = this.mouseXY.y = Stage.mouseY;
    }
    
    this.mouseUp = function()
    {
        this.paramArray[3] = 0.0;
        this.mouseInitXY.x = this.mouseXY.x = Stage.mouseX;
        this.mouseInitXY.y = this.mouseXY.y = Stage.mouseY;
        this.mouseArray[0] = 0.0;
        this.mouseArray[1] = 0.0;
        //trace("...mouseUp..");
    }
    this.initializeByShdCode = function(startX,startY,pwidth,pheight,pShdCode)
    {
        var material = this.getMaterial();
        if(material == null)
        {
            material = new Canvas3DMaterial();
            material.initialize(pShdCode,["u_param","u_mouse"],["a_vs"]);
            this.setMaterial(material);
        }
        //
        if(this.getMesh() == null)
        {
            let mesh = new RectPlaneMesh();
            mesh.flipVerticalUV = this.flipVerticalUV;
            //
            mesh.initialize(startX,startY, pwidth, pheight);            
            this.setMesh(mesh);
        }
        //
        if(m_config.glslVer == 2)
        {
            setVersionToGL1();
        }else if(m_config.glslVer == 3)
        {
            setVersionToGL2();
        }
        //
        material.setTextureProxy(m_config.tex);
    }
    //
    let m_startX = 0.0;
    let m_startY = 0.0;
    let m_width = 0.0;
    let m_height = 0.0;
    let m_self = this;
    let m_config = null;
    this.initializeByFCodeUrl = function(startX,startY,pwidth,pheight,fCodeUrl)
    {
        m_startX = startX;
        m_startY = startY;
        m_width = pwidth;
        m_height = pheight;
        //
        var client = new XMLHttpRequest();
        client.open('GET', fCodeUrl);
        client.onload = function() {
            //trace("client.responseText:"+client.responseText);
            if(client.responseText == null || client.responseText.indexOf("Error code 404")>=0)
            {
                alert("GLSL code file is IOError!");
                return;
            }
            let parser = new ResCodeMap();
            m_config = parser.parse(client.responseText);
            let shdObj = null;
            if(m_config.glslVer == 2)
            {
                shdObj = {
                    uniqueName:"vilyGLSL2_"+INPUT_FNSTR,
                    vshdCode:Canvas3DMaterial.shdCode.vshdCodeES2,
                    fshdCode:m_config.code
                };
            }else if(m_config.glslVer == 3)
            {
                shdObj = {
                    uniqueName:"vilyGLSL3_"+INPUT_FNSTR,
                    vshdCode:Canvas3DMaterial.shdCode.vshdCodeES3,
                    fshdCode:m_config.code
                };
            }
            if(___showGlslCode != undefined)___showGlslCode( parser.getShowCodeStr(client.responseText) );
            m_self.initializeByShdCode(m_startX, m_startY,m_width, m_height, shdObj);
        }
        client.send();
    }
};
//
function VoxSc3D()
{
    let m_rsc = new RenderScene();
    let m_self = this;
    let m_glCanvasNS = "";
    let m_initRenderer = true;
    let m_running = true;
    let m_statusEnbled = true;
    this.initialize = function(glCanvasNS)
    {
        m_glCanvasNS = glCanvasNS;
        this.testSample();
        //
        m_statusEnbled = FPSShowEnabled;
        if(RenderModule != undefined) RenderModule = this;
    };
    let m_demoMap = new Map();
    let m_canvasT = null;
    this.testSample = function()
    {
        let actT = new CanvasAction();
        m_canvasT = new Canvas3D();
        //
        let url = INPUT_BASE_DIR + INPUT_FNSTR;
        m_canvasT.initializeByFCodeUrl(-1.0,-1.0, 2.0,2.0, url);
        m_canvasT.setAction( actT );
        //m_canvasT.blendMode = RenderBlendMode.TRANSPARENT;
        m_rsc.addRDisp(m_canvasT);
        //
        m_demoMap.set(url,m_canvasT);
        //
        Stage.addEventListener(MOUSE_DOWN, this.mouseDownListen);
        Stage.addEventListener(MOUSE_UP, this.mouseUpListen);
        //
        trace(">>>:"+Math.sin(degreeToRadian(45.0)));
    }
    this.mouseDownListen = function()
    {
        m_canvasT.mouseDown();
    }
    this.mouseUpListen = function()
    {
        m_canvasT.mouseUp();
    }
    this.pause = function()
    {
        m_running = false;
    }
    this.play = function()
    {
        m_running = true;
    }

    this.createANewByName = function(fsns)
    {
        if(m_canvasT != null)
        {
            m_canvasT.visible = false;
        }
        
        INPUT_FNSTR = fsns;
        let url = INPUT_BASE_DIR + INPUT_FNSTR;
        if(m_demoMap.has(url))
        {
            m_canvasT = m_demoMap.get(url);
            m_canvasT.visible = true;
            trace("############ play repeat!!!");        
            return;
        }
        let actT = new CanvasAction();
        m_canvasT = new Canvas3D();
        //
        //trace("load url: "+url);
        m_canvasT.initializeByFCodeUrl(-1.0,-1.0, 2.0,2.0, url);
        m_canvasT.setAction( actT );
        //m_canvasT.blendMode = RenderBlendMode.TRANSPARENT;
        m_rsc.addRDisp(m_canvasT);
        //
        m_demoMap.set(url,m_canvasT);
    }
    this.playNewGlslDemoByName = function(newns)
    {
        m_running = true;
        this.createANewByName(newns);
    }
    this.isRunning = function(){return m_running;};
    this.runCall = null;
    this.run = function()
    {
        if(m_running)
        {
            if(m_initRenderer)
            {
                if(m_canvasT.getMaterial() != null)
                {
                    m_rsc.initialize(m_glCanvasNS,new Vector3D(0,0,600));                    
                    m_rsc.getRenderer().statusEnbled = m_statusEnbled;
                    m_initRenderer = false;
                }
            }else
            {
                m_rsc.run();
                //m_rsc.getRenderer().statusInfo = ">" + RenderSYS_DRAWTIMES;
            }
            if(this.runCall != null)
            {
                this.runCall(m_rsc);
            }
            if(Module__runCall != null)Module__runCall(m_rsc);
        }
    };
    this.setStatusEnbled = function(boo)
    {
        m_statusEnbled = boo;
        m_rsc.getRenderer().statusEnbled = m_statusEnbled;
    }
};
function main()
{
  
  console.log("--------------------------------Main--- init ------------------------------------");
  
  var sc = new VoxSc3D();
  sc.initialize("glcanvas");
  function mainLoop(now)
  {
    if(SYS_NO_ERROR)
    {
      sc.run();
      requestAnimationFrame(mainLoop);
    }
    else
    {
      trace("SYS_ERROR.Sys Stop!!!");
    }
  }
  requestAnimationFrame(mainLoop);

  console.log("--------------------------------Main--- end ------------------------------------"); 
};
main();