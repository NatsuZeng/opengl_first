﻿// come from: https://www.shadertoy.com/view/4lXGRB

//##config
{
textureCube:[
"./cubeTex/siege_ft.jpg",
"./cubeTex/siege_bk.jpg",
"./cubeTex/siege_up.jpg",
"./cubeTex/siege_dn.jpg",
"./cubeTex/siege_rt.jpg",
"./cubeTex/siege_lf.jpg"
]
}
//##end

precision highp float;
uniform samplerCube u_sampler0;
uniform vec4 u_param;
void main() {
    vec4 p = vec4(gl_FragCoord.xy,0.,1.)/u_param.xyxy-.5, d=p, t, c;
    p.x += u_param.z;
    //p.z -= u_param.z * 0.2;
    vec4 f = vec4(0.0);
    for(float i=0.9; i>0.0; i-=.02)
    {
        t = abs(mod(p, 8.)-4.);
        c = textureCube(u_sampler0, t.zxy * 0.1);
        float x = -log(exp(-t.y) + exp(-length(t.xz)))-c.x;
        f = mix(c*i*i, vec4(0,1,0,2), p.z*.01);
        if(x<.01) break;
        p -= d*x;
     }
     gl_FragColor = 1.5 * f + 0.2 * abs(cos(t.z + u_param.z) * vec4(1.0,0.5,0.5,1.0) * 0.5 * t.z * t.x);
}