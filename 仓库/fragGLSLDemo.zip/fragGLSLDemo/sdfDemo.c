﻿/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/
precision highp float;
uniform sampler2D uSampler;
uniform vec4 u_param;
uniform vec4 u_posList[3];
const int MAX_MARCHING_STEPS = 128;
const float MIN_DIST = 0.0;
const float MAX_DIST = 100.0;
const float EPSILON = 0.0001;
//float randomX(float x){
//    return fract(sin(x)*1e4);
//}
// tA and tB, priority of The invisible Value.
vec2 intersectSDF(vec2 tA, vec2 tB) {
    if(tA.x > tB.x) return tA;
    return tB;
}
vec2 unionSDF(vec2 tA, vec2 tB) {
    if(tA.x < tB.x) return tA;
    return tB;
}
vec2 differenceSDF(vec2 tA, vec2 tB) {
    tB.x = -tB.x;
    if(tA.x > tB.x) return tA;
    return tB;
}
// Repetition
vec3 repetitionSDF(vec3 p, vec3 c)
{
	return mod(p, c) - 0.5 * c;
}
 
// Twist
vec3 twistXZSDF(vec3 p, float k1, float k2)
{
	float c = cos(k1 * p.y + k2);
	float s = sin(k1 * p.y + k2);
	mat2 m = mat2(c, -s, s, c);
	return vec3(m * p.xz, p.y);
}
//vec2 sphereCloudRingSDF(in vec3 samplePoint, in vec3 pos, float radius,float color) {
//      float f_x = abs(samplePoint.y) * randomX(samplePoint.y * 0.1 + 3.14159 * 40.0);
//      f_x = fract(f_x);
//      return vec2((length(samplePoint - pos) - radius) * f_x * 0.6, color * f_x);
//}
vec2 sphereHalfYDownSDF(in vec3 samplePoint, in vec3 pos, float radius,float color) {
    float f = samplePoint.y - pos.y;
    if(f > EPSILON){
        return vec2(f, color);
    }else{
        return vec2(length(samplePoint - pos) - radius, color);
    };
}
vec2 sphereHalfYUpSDF(in vec3 samplePoint, in vec3 pos, float radius,float color) {
    float f = samplePoint.y - pos.y;
    if(f < -EPSILON){
        return vec2(-f, color);
    }else{
        return vec2(length(samplePoint - pos) - radius, color);
    };
}
vec2 sphereYCirclePlaneSDF(in vec3 samplePoint, in vec3 pos, float radius,float color) {
      float f = abs(samplePoint.y - pos.y);
      if(f > EPSILON)return vec2(f, color);
      return vec2((length(samplePoint - pos) - radius), color);
}
//vec2 sphereYCircleRingSDF(in vec3 samplePoint, in vec3 pos, vec3 param) {
//      float f = abs(samplePoint.y - pos.y);
//      if(f > EPSILON) return vec2(f, param.y);
//      f = distance(pos, vec3(samplePoint.x,0.0,samplePoint.z));
//      if(f < (param.x * param.z)) return vec2(EPSILON + EPSILON, param.y);
//      return vec2((length(samplePoint - pos) - param.x), param.y);
//}
// param.x: radius,param.y:color,param.z: radius scale factor(0.1~1.0)
vec2 sphereYDrumSDF(in vec3 samplePoint, in vec3 pos, vec3 param) {
      float f = abs(samplePoint.y - pos.y);
      if(f > (param.x * param.z + EPSILON))return vec2((f - param.x * param.z), param.y);
      return vec2((length(samplePoint - pos) - param.x), param.y);
}
//vec2 cubePipeSDF(vec3 p, vec3 pos, float color, in vec3 size, vec3 innerSize) {
//    pos = abs(p - pos);
//    vec3 d = pos - size;
//    float insideDistance = min(max(d.x, max(d.y, d.z)), 0.0);
//    float outsideDistance = length(max(d, 0.0));
//    d = pos - innerSize;
//    pos.x = min(max(d.x, max(d.y, d.z)), 0.0);
//    pos.y = length(max(d, 0.0));
//    return vec2(max(insideDistance + outsideDistance, -pos.x - pos.y), color);
//}

void rotateEuler(float radX,float radY,float radZ, inout vec3 pos) {    
    // rot y
    float c = cos(radY);
    float s = sin(radY);
    mat3 m3 = mat3(
        vec3(c, 0, s),
        vec3(0, 1, 0),
        vec3(-s, 0, c)
    );
    pos = m3 * pos;
    // rot x
    c = cos(radX);
    s = sin(radX);
    m3[0] = vec3(1, 0, 0);
    m3[1] = vec3(0, c, -s);
    m3[2] = vec3(0, s, c);
    pos = m3 * pos;
    // rot z
    c = cos(radZ);
    s = sin(radZ);
    m3[0] = vec3(c, -s, 0);
    m3[1] = vec3(s, c, 0);
    m3[2] = vec3(0, 0, 1);
    pos = m3 * pos;
}

vec2 sphereSDF(in vec3 pv, in vec3 pos, float radius,float color) {
      return vec2(length(pv - pos) - radius, color);
}
vec2 sphereFadeYSDF(in vec3 pv, in vec3 pos, float radius,float color, float fract) {
    vec3 d = abs(pv - pos);
    d.y *= fract;
    return vec2(length(d) - radius, color);
}
vec2 sphereFadeXZSDF(in vec3 pv, in vec3 pos, float radius,float color, float fract) {
    vec3 d = abs(pv - pos);
    d.xz *= fract;
    return vec2(length(d) - radius, color);
}
vec2 torusSDF( vec3 p, vec3 pos, vec2 t, float color)
{
    p = p - pos;
    return vec2(length( vec2(length(p.xz)-t.x,p.y) )-t.y, color);
}
vec2 cylinderZSDF(vec3 p,in vec3 pos, float h, float r, float color) {
    float inOutRadius = length(p.xy - pos.xy) - r;
    float inOutHeight = abs(p.z - pos.z) - 0.5 * h;
    float insideDistance = min(max(inOutRadius, inOutHeight), 0.0);
    float outsideDistance = length(max(vec2(inOutRadius, inOutHeight), 0.0));
    return vec2(insideDistance + outsideDistance, color);
}
vec2 cylinderYSDF(vec3 p,in vec3 pos, float h, float r, float color) {
    float inOutRadius = length(p.xz - pos.xz) - r;
    float inOutHeight = abs(p.y - pos.y) - h;
    float insideDistance = min(max(inOutRadius, inOutHeight), 0.0);
    float outsideDistance = length(max(vec2(inOutRadius, inOutHeight), 0.0));
    return vec2(insideDistance + outsideDistance, color);
}
vec2 cylinderSDF( vec3 p, vec3 pos, vec2 h, float color)
{
    p = p - pos;
    vec2 d = abs(vec2(length(p.xz),p.y)) - h;
    return vec2(min(max(d.x,d.y),0.0) + length(max(d,0.0)), color);
}
vec2 sphereFadePartYUpSDF(in vec3 pv, in vec3 pos, float radius,vec3 factor,float color) {
    vec3 d = vec3((pv.xz - pos.xz) * factor.x, (pv.y - pos.y) * factor.y);
    return vec2(max(length(d) - radius, -(pv.y + factor.z)), color);
}
vec2 sphereFadePartYDownSDF(in vec3 pv, in vec3 pos, float radius,vec3 factor,float color) {
    vec3 d = vec3((pv.xz - pos.xz) * factor.x, (pv.y - pos.y) * factor.y);
    return vec2(max(length(d) - radius, pv.y + factor.z), color);    
}
vec2 sphereSinkYSDF(in vec3 pv, in vec3 pos, float radius,vec3 factor,float color) {
    vec3 d = vec3(abs(pv.xz - pos.xz) * factor.x, abs(pv.y - pos.y) * factor.y);
    d.y += factor.z;
    return vec2(length(d) - radius, color);
}
vec2 cubeSDF(vec3 p, vec3 pos, in vec3 size, float color) {    
    vec3 d = abs(p - pos) - size;
    float insideDistance = min(max(d.x, max(d.y, d.z)), 0.0);
    float outsideDistance = length(max(d, 0.0));
    return vec2(insideDistance + outsideDistance, color);
}
float boxSDF( vec3 p, vec3 b )
{
    vec3 d = abs(p) - b;
    return min(max(d.x,max(d.y,d.z)),0.0) + length(max(d,0.0));
}
float box2dSDF( vec2 p, vec2 b )
{
    vec2 d = abs(p) - b;
    return min(max(d.x,d.y),0.0) + length(max(d,0.0));
}
vec2 cubeCrossSDF( in vec3 p, vec3 pos, float base, float inf, float color )
{
    p = p - pos;
    float da = boxSDF(p.xyz,vec3(inf,base,base));
    float db = boxSDF(p.yzx,vec3(base,inf,base));
    float dc = boxSDF(p.zxy,vec3(base,base,inf));
    return vec2(min(da,min(db,dc)), color);
}
vec2 cubeCross2SDF( in vec3 p, in vec3 pos,float base, float inf, float color )
{
    p = p - pos;
    float da = box2dSDF(p.xy,vec2(base));
    float db = box2dSDF(p.yz,vec2(base));
    float dc = box2dSDF(p.zx,vec2(base));
    return vec2(min(da,min(db,dc)), color);
}
vec2 sdYPlane( vec3 p, float dy, float color )
{
    //p.xz *= 2.0;
    bool boo = fract(p.x * 2.0) > 0.5 ^^ fract(p.z * 2.0) > 0.5;
    float k = 1.0;
    if(boo){
        k = 1.0;
    }else{
        k = 0.6;
    }
    return vec2(p.y + dy, color * k);
}
vec2 sceneSDF(vec3 pv) {
    //
    //vec3 pivotPoint = vec3(0.0, 0.0, 0.0);
    //vec3 pos = vec3(-2.2,1.0,0.0);
    vec3 vpos = pv;
    //rotateEuler(u_param.z * 0.4,0.0,u_param.z * 0.2,vpos);
    //vec2 obj = sphereFadePartYUpSDF(vpos, vec3(0.0, -1.05, 0.0), 1.5, vec3(0.5,1.0,0.1),0.3);
    //vec2 obj = sphereSinkYSDF(vpos, vec3(0.0, 0.0, 0.0), 1.0, vec3(1.0,0.6,0.5),0.3);
    //vec2 obj = cylinderSDF(vpos, vec3(0.0, 0.0, 0.0), vec2(1.0,0.6),0.3);
    //vec2 obj = cubeCross2SDF(vpos, vec3(0.0, 0.0, 0.0), 0.1, 1.0,0.3);
    //vec2 obj2 = cubeSDF(vpos, vec3(0.0, 1.0, 0.0), vec3(2.0,1.0,2.0),0.4);
    //obj2 = torusSDF(vpos, vec3(0.0, 0.30, 0.0), vec2(0.7,0.05),0.35);
    //obj = differenceSDF(obj, obj2);
    //obj = differenceSDF(obj, obj2);
    //sphereYDrumSDF
    //vec2 obj = sdYPlane(vpos,1.6,0.3);
    
    vec2 obj = sdYPlane(vpos,0.0,0.3);
    vec2 obj2 = cubeSDF(vpos, vec3(0.0, 1.0, 0.0), vec3(0.7,0.3,0.9),0.4);
    obj = unionSDF(obj,obj2);
    obj2 = torusSDF(vpos, vec3(0.0, 0.30, 0.5), vec2(0.7,0.1),0.4);
    obj = unionSDF(obj,obj2);
    obj2 = cubeSDF(vpos, vec3(1.5, 0.5, 0.3), vec3(0.5,1.5,0.4),0.4);
    //vec2 obj3 = cubeSDF(vpos, vec3(1.5, 0.5, 0.3), vec3(0.5,1.5,0.9),0.4);
    ////obj = unionSDF(obj,obj2);    
    //obj2 = sphereSDF(vpos, vec3(1.5, 2.2, 1.2), 1.2,0.4);
    //obj2 = differenceSDF(obj3,obj2);
    obj = unionSDF(obj,obj2);

    obj2 = cubeSDF(vpos, vec3(-0.1, 1.3, -0.2), vec3(0.3,0.6,0.3),0.5);
    obj = unionSDF(obj,obj2);
    obj2 = cubeSDF(vpos, vec3(0.1, 1.7, 0.0), vec3(0.2,0.3,0.2),0.5);
    obj = differenceSDF(obj,obj2);
    obj2 = cubeSDF(vpos, vec3(-0.3, 1.8, -0.4), vec3(0.3,0.2,0.3),0.5);
    obj = differenceSDF(obj,obj2);
    obj2 = sphereSDF(vpos, vec3(0.1, 1.3, 0.5), 0.2,0.54);
    obj = unionSDF(obj,obj2);
    obj2 = sphereSDF(vpos, vec3(-0.2, 1.3, 0.5), 0.3,0.54);
    obj = unionSDF(obj,obj2);
    return obj;
}
vec2 shortestDistanceToSurface( in vec3 ro, in vec3 rd, float start, float end )
{
    float tmin = start;
    float tmax = end;
    // bounding volume
    float tp1 = (0.0-ro.y)/rd.y; if( tp1>0.0 ) tmax = min( tmax, tp1 );
    float tp2 = (2.1-ro.y)/rd.y; if( tp2>0.0 ) { if( ro.y>2.1 ) tmin = max( tmin, tp2 );
                                                 else           tmax = min( tmax, tp2 ); }
    float t = tmin;
    float m = -1.0;
    for( int i=0; i<64; i++ )
    {
	    //float precis = 0.0004*t;
	    vec2 res = sceneSDF( ro+rd*t );
        //if( res.x<precis || t>tmax ) break;
        if( res.x<EPSILON || t>tmax ) break;
        t += res.x;
	    m = res.y;
    }
    if( t>tmax ) m=-1.0;
    return vec2( t, m );
}
vec2 shortestDistanceToSurface2(vec3 eye, vec3 marchingDirection, float start, float end) {
    float depth = start;
    for (int i = 0; i < MAX_MARCHING_STEPS; i++) {
        //float precis = 0.0006*depth;
        vec2 tv = sceneSDF(eye + depth * marchingDirection);
        if (tv.x < EPSILON) {
        //if (tv.x < precis) {
            tv.x = depth;
            return tv;
        }
        depth += tv.x;
        if (depth >= end) {
            tv.x = end;
            return tv;
        }
    }
    return vec2(end, 0.0);
}
//http://www.iquilezles.org/www/articles/rmshadows/rmshadows.htm
float shadow( in vec3 ro, in vec3 rd,float start, float end)
{
    float t = start;
    for (int i = 0; i < MAX_MARCHING_STEPS; i++)
    {
        float h = sceneSDF(ro + rd*t).x;
        if( h<EPSILON )
            return 0.0;
        t += h;
    }
    return 1.0;
}
//http://www.iquilezles.org/www/articles/rmshadows/rmshadows.htm
//float softshadow( in vec3 ro, in vec3 rd, float mint, float maxt, float k )
//{
//    float res = 1.0;
//    for( float t=mint; t < maxt; )
//    {
//        float h = sceneSDF(ro + rd*t).x;
//        if( h<0.001 )
//            return 0.0;
//        res = min( res, k*h/t );
//        t += h;
//    }
//    return res;
//}
float softshadow( in vec3 ro, in vec3 rd, in float mint, in float tmax, float k )
{
	float res = 1.0;
    
    float t = mint;
    for( int i=0; i<20; i++ )
    {
		float h = sceneSDF( ro + rd*t ).x;
        res = min( res, k*h/t );
        t += clamp( h, 0.01, 0.10 );
        if( res<0.005 || t>tmax ) break;
    }
    return clamp( res, 0.0, 1.0 );
}
float softshadow2( in vec3 ro, in vec3 rd, float mint, float maxt, float k )
{
    float res = 1.0;
    float ph = 1e20;
    float t = mint;
    //for( float t=mint; t < maxt; )
    for( int i=0; i<32; i++ )
    {
        float h = sceneSDF(ro + rd*t).x;        
        float y = h*h/(2.0*ph);
        float d = sqrt(h*h-y*y);
        res = min( res, k*d/max(0.0,t-y) );
        ph = h;
        t += h;
        if( t>maxt )break;
        if( h<0.001 )return 0.0;
    }
    return res;
}
float calcAO( in vec3 pos, in vec3 nor )
{
	float occ = 0.0;
    float sca = 1.0;
    for( int i=0; i<5; i++ )
    {
        //float hr = 0.01 + 0.12*float(i)/4.0;
        float hr = 0.01 + 0.1*float(i)/4.0;
        vec3 aopos =  nor * hr + pos;
        float dd = sceneSDF( aopos ).x;
        occ += -(dd-hr)*sca;
        sca *= 0.90;
    }
    return clamp( 1.0 - 3.0*occ, 0.0, 1.0 );    
}

vec3 estimateNormal( in vec3 pos )
{
    vec3 eps = vec3(0.005,0.0,0.0);
	return normalize( vec3(
           sceneSDF(pos+eps.xyy).x - sceneSDF(pos-eps.xyy).x,
           sceneSDF(pos+eps.yxy).x - sceneSDF(pos-eps.yxy).x,
           sceneSDF(pos+eps.yyx).x - sceneSDF(pos-eps.yyx).x ) );
}

vec3 estimateNormal3( in vec3 pos )
{
    vec2 e = vec2(1.0,-1.0)*0.5773*0.0005;
    return normalize( e.xyy*sceneSDF( pos + e.xyy ).x + 
                      e.yyx*sceneSDF( pos + e.yyx ).x + 
                      e.yxy*sceneSDF( pos + e.yxy ).x + 
                      e.xxx*sceneSDF( pos + e.xxx ).x );
}
vec3 estimateNormal2(vec3 p) {
    return normalize(vec3(
        sceneSDF(vec3(p.x + EPSILON, p.y, p.z)).x - sceneSDF(vec3(p.x - EPSILON, p.y, p.z)).x,
        sceneSDF(vec3(p.x, p.y + EPSILON, p.z)).x - sceneSDF(vec3(p.x, p.y - EPSILON, p.z)).x,
        sceneSDF(vec3(p.x, p.y, p.z + EPSILON)).x - sceneSDF(vec3(p.x, p.y, p.z - EPSILON)).x
    ));
}
vec3 phongContribForLight(vec3 k_d, vec3 k_s, float alpha, vec3 p, vec3 eye, vec3 lightPos, vec3 lightIntensity, in vec3 N) {
    //vec3 N = estimateNormal(p);
    vec3 L = normalize(lightPos - p);
    vec3 V = normalize(eye - p);
    vec3 R = normalize(reflect(-L, N));
    float dotLN = dot(L, N);
    float dotRV = dot(R, V);    
    if (dotLN < 0.0) {
        return vec3(0.0, 0.0, 0.0);
    }    
    if (dotRV < 0.0) {
        return lightIntensity * (k_d * dotLN);
    }
    return lightIntensity * (k_d * dotLN + k_s * pow(dotRV, alpha));
}
vec3 phongIllumination(float iTime, vec3 k_a, vec3 k_d, vec3 k_s, float alpha, vec3 p, vec3 eye, in vec3 N) {
    const vec3 ambientLight = 0.5 * vec3(1.0, 1.0, 1.0);
    vec3 color = ambientLight * k_a;    
    //vec3 light1Pos = vec3(4.0 * sin(iTime),
    //                      2.0,
    //                      4.0 * cos(iTime));
    vec3 light1Pos = vec3(-3.0,5.0,3.0);
    vec3 light1Intensity = vec3(0.4, 0.4, 0.4);
    //vec3 N = estimateNormal(p);
    color += phongContribForLight(k_d, k_s, alpha, p, eye,
                                  light1Pos,
                                  light1Intensity, N);    
    //vec3 light2Pos = vec3(2.0 * sin(0.37 * iTime),
    //                      2.0 * cos(0.37 * iTime),
    //                      2.0);
    vec3 light2Pos = vec3(3.0,5.0,-3.0);

    vec3 light2Intensity = vec3(0.4, 0.4, 0.4);
    color += phongContribForLight(k_d, k_s, alpha, p, eye,
                                  light2Pos,
                                  light2Intensity, N);    
    return color;
}

mat3 viewMatrix3(vec3 eye, vec3 center, vec3 up) {
    vec3 f = normalize(center - eye);
    vec3 s = normalize(cross(f, up));
    vec3 u = cross(s, f);
    return mat3(s, u, -f);
}
//https://www.shadertoy.com/view/XtjSDK
vec4 texCube( sampler2D sam, in vec3 p, in vec3 n, in float k )
{
	vec4 x = texture2D( sam, p.yz );
	vec4 y = texture2D( sam, p.zx );
	vec4 z = texture2D( sam, p.xy );
    vec3 w = pow( abs(n), vec3(k) );
	return (x*w.x + y*w.y + z*w.z) / (w.x+w.y+w.z);
}
vec3 rayDirection(float fieldOfView, vec2 size, vec2 fragCoord) {
    vec2 xy = fragCoord - size / 2.0;
    float z = size.y / tan(radians(fieldOfView) / 2.0);
    return normalize(vec3(xy, -z));
    //vec2 p = (-size.xy + 2.0*gl_FragCoord.xy)/size.y;
    //return normalize(vec3(p.xy,-2.0));
}
void main()
{
    vec2 stageSize = u_param.xy;
    float iTime = u_param.z;
    vec3 dir = rayDirection(45.0, stageSize.xy, gl_FragCoord.xy);
    //vec3 eye = vec3(7.0, 8.0, 7.0);
    vec3 eye = vec3(5.0, 6.0, 5.0);
    //eye = vec3(8.0, 5.0 * sin(0.2 * iTime), 7.0);
    float rad = iTime * 0.3;
    //if(rad > 0.1)rad = 0.1;
    vec2 tEyeV = vec2(eye.x * cos(rad) - eye.y * sin(rad), eye.x * sin(rad) + eye.y * cos(rad));
    eye.xz = tEyeV.xy;
    //mat4 viewToWorld = viewMatrix(eye, vec3(0.0, 0.0, 0.0), vec3(0.0, 1.0, 0.0));
    mat3 viewToWorld = viewMatrix3(eye, vec3(0.0, 0.0, 0.0), vec3(0.0, 1.0, 0.0));
    //dir = (viewToWorld * vec4(dir, 0.0)).xyz;
    dir = viewToWorld * dir;
    vec2 tv = shortestDistanceToSurface(eye, dir, MIN_DIST, MAX_DIST);
    vec4 outColor = u_posList[0];
    //if (tv.x > (MAX_DIST - EPSILON)) {
    if (tv.y <= -0.5) {
        //outColor = vec4(vec3(0.4 + 0.2 * cos(dir.y * 5.0),0.4 + 0.3 * cos(dir.x * 5.0), 0.4 + 0.3 * cos(dir.z * 5.0))  * 0.6, 1.0);
        outColor = vec4(vec3(0.5,0.0,0.0) * 0.6, 1.0);
    }else{
        vec3 p = eye + tv.x * dir;
        vec3 N = estimateNormal(p);
        vec3 sfDir = normalize(vec3(1.0,1.0,1.0));
        //float sf = shadow(p, sfDir,0.01, 3.0);
        //float sf = softshadow(p, sfDir * 1.2,0.01, 2.0, 8.0) * 0.6 + 0.4;
        float sf = softshadow(p, sfDir,0.02, 2.5, 8.0) * 0.6 + 0.4;
        float af = calcAO(p,N) * 0.2 + 0.8;
        //sf *= af;
        vec3 K_a = vec3(0.2, 0.2, 0.2);
        vec3 K_d = vec3(0.7, 0.2, 0.2);
        vec3 K_s = vec3(1.0, 1.0, 1.0);
        float shininess = 10.0;
        outColor = vec4(
            (texture2D(uSampler, vec2(tv.y,0.5)).rgb * 0.5
            //texCube(uSampler, p, N, 0.5).xyz
            + sf * 0.7 * phongIllumination(iTime, K_a, K_d, K_s, shininess, p, eye, N)) * af
            ,1.0);
        //outColor = vec4(vec3(af)
        //    ,1.0);
    }
    gl_FragColor = outColor;
}