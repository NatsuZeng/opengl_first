﻿/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2020 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/
precision mediump float;
uniform sampler2D u_sampler0;
uniform vec4 u_param;
//
void main()
{
    vec2 coord = gl_FragCoord.xy/u_param.xy;
    coord.y = 1.0 - coord.y;
    vec3 outColor = texture2D(u_sampler0,coord).rgb;
    gl_FragColor = vec4(outColor,1.0);
}


//##config
{
texture2D:[
    "./glsles2.jpg"
    ]
}
//##end