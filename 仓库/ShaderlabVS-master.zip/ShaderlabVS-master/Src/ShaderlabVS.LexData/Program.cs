﻿using ShaderlabVS.Lexer;

namespace ShaderlabVS.LexData
{
    class Program
    {
        static void Main(string[] args)
        {
            Scanner.GenerateTableData();
        }
    }
}
